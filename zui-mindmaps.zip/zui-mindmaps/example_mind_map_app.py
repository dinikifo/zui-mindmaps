from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QAction, QColor, QImage, QKeySequence, QMouseEvent, QPainter
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QInputDialog,
    QLineEdit,
    QMainWindow,
    QMessageBox,
)

from zui_qt import ZCamera, ZCanvas, ZEventHandler, ZKey, ZPointer, ZTheme, Zui
from zui_qt.mindmap import CommandStack, MindMapDocument, MindMapLayoutEngine, MindMapScene
from zui_qt.mindmap_inspector import MindMapInspectorDock
from zui_qt.scripting import ScriptEngine, ExecState


PANEL_W = 214
PALETTE = [
    "#7aa2ff",
    "#75c77e",
    "#ffba59",
    "#f0847d",
    "#8c76ff",
    "#ff8fd1",
    "#58c8d6",
    "#7b8594",
    "#4c9aff",
    "#4caf6e",
    "#e6a23c",
    "#d66a61",
]


class MindMapCanvas(ZCanvas):
    def __init__(self, zui: Zui, owner: "MindMapWindow") -> None:
        super().__init__(zui)
        self.owner = owner

    def mouseDoubleClickEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        super().mouseDoubleClickEvent(event)
        self.owner.begin_inline_rename_at(event.position().x(), event.position().y())


class MindMapHandler(ZEventHandler):
    def __init__(self, window: "MindMapWindow") -> None:
        self.window = window
        self.dragging_id: str | None = None
        self.drag_before_state: str | None = None
        self.drag_before_selection: str | None = None
        self.drag_last_world = QPointF(0.0, 0.0)
        self.moved = False

    def mouse_pressed(self, event: ZPointer) -> None:
        win = self.window
        cam = win.camera
        win.commit_inline_rename()
        if not cam.over_viewport(event.x, event.y):
            return
        if event.is_middle() or bool(event.modifiers & Qt.KeyboardModifier.ControlModifier):
            cam.begin_pan(event.x, event.y)
            return
        world = cam.screen_to_world(event.x, event.y)
        picked = win.scene.pick_node(world)
        win.scene.hovered_id = picked
        if event.button == Qt.MouseButton.LeftButton:
            if picked is None:
                win.select_node(None)
                return
            if win.collapse_hit_test(picked, world):
                win.toggle_collapse(picked)
                return
            if win.run_pill_hit_test(picked, world):
                win.run_node(picked)
                return
            win.select_node(picked)
            self.dragging_id = picked
            self.drag_before_state = win.doc.to_json()
            self.drag_before_selection = win.selected_id
            self.drag_last_world = world
            self.moved = False

    def mouse_dragged(self, event: ZPointer) -> None:
        win = self.window
        cam = win.camera
        if cam.panning:
            cam.update_pan(event.x, event.y)
            win.refresh_editor_geometry()
            return
        if self.dragging_id is None:
            return
        world = cam.screen_to_world(event.x, event.y)
        dx = world.x() - self.drag_last_world.x()
        dy = world.y() - self.drag_last_world.y()
        if abs(dx) > 0.0001 or abs(dy) > 0.0001:
            win.doc.offset_subtree(self.dragging_id, dx, dy)
            self.drag_last_world = world
            self.moved = True
            win.scene.sync()
        if event.modifiers & Qt.KeyboardModifier.ShiftModifier:
            candidate = win.scene.nearest_node(world, exclude=[self.dragging_id, *win.doc.descendants(self.dragging_id)])
            if candidate is not None and not win.doc.is_ancestor(self.dragging_id, candidate):
                candidate_rect = win.scene.node_rect(candidate)
                if (candidate_rect.center().x() - world.x()) ** 2 + (candidate_rect.center().y() - world.y()) ** 2 < 30000.0:
                    win.scene.drop_target_id = candidate
                else:
                    win.scene.drop_target_id = None
            else:
                win.scene.drop_target_id = None
        else:
            win.scene.drop_target_id = None

    def mouse_released(self, event: ZPointer) -> None:
        win = self.window
        cam = win.camera
        if cam.panning:
            cam.end_pan()
            return
        if self.dragging_id is None:
            return
        if self.moved:
            target = win.scene.drop_target_id
            if target is not None and target != self.dragging_id and not win.doc.is_ancestor(self.dragging_id, target):
                win.doc.reparent(self.dragging_id, target)
            after_state = win.doc.to_json()
            if self.drag_before_state is not None:
                name = "Reparent topic" if target is not None else "Move topic"
                win.commands.push_transition(
                    name,
                    before_state=self.drag_before_state,
                    after_state=after_state,
                    before_selection=self.drag_before_selection,
                    after_selection=win.selected_id,
                )
                if target is not None:
                    win.statusBar().showMessage("Reparented topic", 2400)
        self.dragging_id = None
        self.drag_before_state = None
        self.drag_before_selection = None
        self.drag_last_world = QPointF(0.0, 0.0)
        self.moved = False
        win.scene.drop_target_id = None
        win.sync_scene_views()

    def mouse_moved(self, event: ZPointer) -> None:
        win = self.window
        if not win.camera.over_viewport(event.x, event.y):
            win.scene.hovered_id = None
            return
        world = win.camera.screen_to_world(event.x, event.y)
        win.scene.hovered_id = win.scene.pick_node(world)
        win.inspector.set_hovered(win.scene.hovered_id)
        win.update_status(event.x, event.y)

    def mouse_wheel(self, delta: float, event: ZPointer | None = None) -> None:
        if event is None:
            return
        self.window.camera.on_mouse_wheel(delta, event.x, event.y)
        self.window.refresh_editor_geometry()
        self.window.update_status(event.x, event.y)

    def key_pressed(self, event: ZKey) -> None:
        win = self.window
        if win.title_editor.isVisible():
            if event.key == Qt.Key.Key_Escape:
                win.cancel_inline_rename()
            return
        if event.is_command_key() and event.key == Qt.Key.Key_Z:
            win.undo()
            return
        if event.is_command_key() and event.key == Qt.Key.Key_Y:
            win.redo()
            return
        if event.is_command_key() and event.key == Qt.Key.Key_S:
            win.save_document()
            return
        if event.is_command_key() and event.key == Qt.Key.Key_O:
            win.open_document()
            return
        if event.is_command_key() and event.key == Qt.Key.Key_N:
            win.new_document()
            return
        if event.is_command_key() and event.key == Qt.Key.Key_L:
            win.auto_layout()
            return
        if event.key == Qt.Key.Key_Tab:
            win.add_child()
            return
        if event.key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            if event.is_shift():
                win.add_sibling()
            else:
                win.begin_inline_rename()
            return
        if event.key == Qt.Key.Key_Delete or event.key == Qt.Key.Key_Backspace:
            win.delete_selected()
            return
        if event.key == Qt.Key.Key_F2:
            win.begin_inline_rename()
            return
        if event.key == Qt.Key.Key_Space:
            win.toggle_collapse()
            return
        if event.key == Qt.Key.Key_BracketLeft:
            win.promote_selected()
            return
        if event.key == Qt.Key.Key_BracketRight:
            win.demote_selected()
            return
        if event.key == Qt.Key.Key_0:
            win.fit_document()
            return
        if event.key == Qt.Key.Key_Equal:
            win.camera.zoom_at(win.width() / 2.0, win.height() / 2.0, 1.2)
            win.refresh_editor_geometry()
            return
        if event.key == Qt.Key.Key_Minus:
            win.camera.zoom_at(win.width() / 2.0, win.height() / 2.0, 1.0 / 1.2)
            win.refresh_editor_geometry()
            return
        if event.key in (Qt.Key.Key_Left, Qt.Key.Key_Right, Qt.Key.Key_Up, Qt.Key.Key_Down):
            win.navigate_selection(event.key)
            return
        if event.key == Qt.Key.Key_N and not event.is_command_key():
            win.edit_note()
            return
        if event.key == Qt.Key.Key_R and not event.is_command_key() and not event.is_shift():
            win.run_node()
            return
        if event.key == Qt.Key.Key_R and event.is_shift() and not event.is_command_key():
            win.run_subtree()
            return
        if event.key == Qt.Key.Key_R and event.is_command_key():
            win.run_all()
            return


class MindMapWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("ZUI Qt Mind Map")
        self.resize(1280, 780)

        self.zui = Zui(ZTheme.light())
        self.canvas = MindMapCanvas(self.zui, self)
        self.setCentralWidget(self.canvas)

        self.doc = MindMapDocument()
        self.scene = MindMapScene(self.doc)
        self.layout_engine = MindMapLayoutEngine()
        self.selected_id: str | None = self.doc.root_id
        self.current_path: Path | None = None

        self.camera = ZCamera(PANEL_W + 12, 12, self.width() - PANEL_W - 24, self.height() - 24)
        self.camera.set_zoom_limits(0.08, 3.0)
        self.zui.context.camera = self.camera

        self.commands = CommandStack(self.doc.to_json, self.restore_document)
        self.script_engine = ScriptEngine(self.doc)
        self.handler = MindMapHandler(self)
        self.zui.set_canvas_handler(self.handler)

        self.title_editor = QLineEdit(self.canvas)
        self.title_editor.hide()
        self.title_editor.returnPressed.connect(self.commit_inline_rename)
        self.title_editor.editingFinished.connect(self._maybe_finish_inline_rename)
        self._ignore_editing_finished = False

        self._build_scene()
        self._build_menu()

        self.inspector = MindMapInspectorDock(self)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.inspector)
        self.inspector.bind(self.doc, selected_id=self.selected_id)
        self.inspector.visibilityChanged.connect(self.inspector_action.setChecked)

        self.canvas.set_world_renderer(self.draw_world)
        self.canvas.set_continuous(True)  # needed for cursor blink and live labels
        self.fit_document()
        self.sync_scene_views()
        self.statusBar().showMessage("Ready")

    def resizeEvent(self, event) -> None:  # type: ignore[override]
        super().resizeEvent(event)
        self.camera.set_viewport(PANEL_W + 12, 12, self.width() - PANEL_W - 36, self.height() - 32)
        self.refresh_editor_geometry()

    def _build_menu(self) -> None:
        file_menu = self.menuBar().addMenu("&File")
        new_action = QAction("New", self)
        new_action.setShortcut(QKeySequence.StandardKey.New)
        new_action.triggered.connect(self.new_document)
        open_action = QAction("Open…", self)
        open_action.setShortcut(QKeySequence.StandardKey.Open)
        open_action.triggered.connect(self.open_document)
        save_action = QAction("Save…", self)
        save_action.setShortcut(QKeySequence.StandardKey.Save)
        save_action.triggered.connect(self.save_document)
        export_action = QAction("Export PNG…", self)
        export_action.triggered.connect(self.export_png)
        file_menu.addActions([new_action, open_action, save_action, export_action])

        edit_menu = self.menuBar().addMenu("&Edit")
        undo_action = QAction("Undo", self)
        undo_action.setShortcut(QKeySequence.StandardKey.Undo)
        undo_action.triggered.connect(self.undo)
        redo_action = QAction("Redo", self)
        redo_action.setShortcut(QKeySequence.StandardKey.Redo)
        redo_action.triggered.connect(self.redo)
        rename_action = QAction("Rename", self)
        rename_action.setShortcut(QKeySequence(Qt.Key.Key_F2))
        rename_action.triggered.connect(self.begin_inline_rename)
        note_action = QAction("Edit Note", self)
        note_action.setShortcut(QKeySequence("N"))
        note_action.triggered.connect(self.edit_note)
        edit_menu.addActions([undo_action, redo_action, rename_action, note_action])

        node_menu = self.menuBar().addMenu("&Node")
        add_child_action = QAction("Add Child", self)
        add_child_action.setShortcut(QKeySequence(Qt.Key.Key_Tab))
        add_child_action.triggered.connect(self.add_child)
        add_sibling_action = QAction("Add Sibling", self)
        add_sibling_action.setShortcut("Shift+Return")
        add_sibling_action.triggered.connect(self.add_sibling)
        delete_action = QAction("Delete", self)
        delete_action.setShortcut(QKeySequence(Qt.Key.Key_Delete))
        delete_action.triggered.connect(self.delete_selected)
        collapse_action = QAction("Collapse / Expand", self)
        collapse_action.setShortcut(QKeySequence(Qt.Key.Key_Space))
        collapse_action.triggered.connect(self.toggle_collapse)
        layout_action = QAction("Auto Layout", self)
        layout_action.setShortcut("Ctrl+L")
        layout_action.triggered.connect(self.auto_layout)
        node_menu.addActions([add_child_action, add_sibling_action, delete_action, collapse_action, layout_action])

        view_menu = self.menuBar().addMenu("&View")
        fit_action = QAction("Fit Document", self)
        fit_action.setShortcut(QKeySequence("0"))
        fit_action.triggered.connect(self.fit_document)
        self.inspector_action = QAction("Show Inspector", self, checkable=True, checked=True)
        self.inspector_action.toggled.connect(self._toggle_inspector)
        view_menu.addActions([fit_action, self.inspector_action])

        script_menu = self.menuBar().addMenu("&Script")
        run_node_action = QAction("Run Node", self)
        run_node_action.setShortcut(QKeySequence("R"))
        run_node_action.triggered.connect(self.run_node)
        run_subtree_action = QAction("Run Subtree", self)
        run_subtree_action.setShortcut(QKeySequence("Shift+R"))
        run_subtree_action.triggered.connect(self.run_subtree)
        run_all_action = QAction("Run All", self)
        run_all_action.setShortcut(QKeySequence("Ctrl+R"))
        run_all_action.triggered.connect(self.run_all)
        show_output_action = QAction("Show Output…", self)
        show_output_action.triggered.connect(self.show_exec_output)
        clear_status_action = QAction("Clear Statuses", self)
        clear_status_action.triggered.connect(self.clear_exec_statuses)
        script_menu.addActions([run_node_action, run_subtree_action, run_all_action, show_output_action, clear_status_action])

    def _toggle_inspector(self, visible: bool) -> None:
        self.inspector.setVisible(visible)

    def _build_scene(self) -> None:
        z = self.zui
        actions = z.window(8, 12, PANEL_W - 16, 278, "Actions")
        actions.add(z.label(8, 6, 180, 18, lambda: f"Selected: {self.selected_title()}"))
        actions.add(z.button(8, 30, 180, 24, "Add Child (Tab)", self.add_child))
        actions.add(z.button(8, 58, 180, 24, "Add Sibling (Shift+Enter)", self.add_sibling))
        actions.add(z.button(8, 86, 180, 24, "Rename (F2)", self.begin_inline_rename))
        actions.add(z.button(8, 114, 180, 24, "Edit Note (N)", self.edit_note))
        actions.add(z.button(8, 142, 86, 24, "Collapse", self.toggle_collapse))
        actions.add(z.button(102, 142, 86, 24, "Delete", self.delete_selected))
        actions.add(z.button(8, 176, 86, 24, "Undo", self.undo))
        actions.add(z.button(102, 176, 86, 24, "Redo", self.redo))
        actions.add(z.button(8, 210, 86, 24, "Layout", self.auto_layout))
        actions.add(z.button(102, 210, 86, 24, "Fit", self.fit_document))
        actions.add(z.label(8, 244, 180, 20, lambda: "Shift-drag onto another topic to reparent"))
        z.add(actions)

        colors = z.window(8, 304, PANEL_W - 16, 150, "Style")
        colors.add(z.label(8, 6, 180, 18, "Apply color to selected topic"))
        colors.add(z.palette_grid(8, 30, 180, 84, [QColor(c) for c in PALETTE], 4, self.apply_color))
        colors.add(z.button(8, 116, 86, 24, "Left Branch", lambda: self.set_branch_side("left")))
        colors.add(z.button(102, 116, 86, 24, "Right Branch", lambda: self.set_branch_side("right")))
        z.add(colors)

        doc = z.window(8, 468, PANEL_W - 16, 182, "Document")
        doc.add(z.button(8, 8, 180, 24, "New", self.new_document))
        doc.add(z.button(8, 36, 180, 24, "Open JSON", self.open_document))
        doc.add(z.button(8, 64, 180, 24, "Save JSON", self.save_document))
        doc.add(z.button(8, 92, 180, 24, "Export PNG", self.export_png))
        doc.add(z.label(8, 124, 180, 18, lambda: f"Nodes: {len(self.doc.nodes)} | Depth: {self.document_depth()}"))
        doc.add(z.label(8, 148, 180, 18, lambda: self.current_path.name if self.current_path else "Untitled mind map"))
        z.add(doc)

        script = z.window(8, 664, PANEL_W - 16, 170, "Scripting")
        script.add(z.button(8, 8, 180, 24, "Run Node (R)", self.run_node))
        script.add(z.button(8, 36, 180, 24, "Run Subtree (Shift+R)", self.run_subtree))
        script.add(z.button(8, 64, 180, 24, "Run All (Ctrl+R)", self.run_all))
        script.add(z.button(8, 92, 86, 24, "Output", self.show_exec_output))
        script.add(z.button(102, 92, 86, 24, "Clear", self.clear_exec_statuses))
        script.add(z.label(8, 124, 180, 18, lambda: self._exec_summary_text()))
        z.add(script)

    def restore_document(self, state: str, selection: str | None) -> None:
        self.doc = MindMapDocument.from_json(state)
        self.scene.set_document(self.doc)
        self.selected_id = selection if selection in self.doc.nodes else self.doc.root_id
        self.scene.selected_id = self.selected_id
        self.script_engine = ScriptEngine(self.doc)
        self.inspector.bind(self.doc, selected_id=self.selected_id, hovered_id=self.scene.hovered_id)
        self.sync_scene_views()

    def sync_scene_views(self) -> None:
        self.scene.selected_id = self.selected_id
        self.scene.sync()
        self.inspector.bind(self.doc, selected_id=self.selected_id, hovered_id=self.scene.hovered_id)
        self.refresh_editor_geometry()
        self.canvas.update()

    def _exec_summary_text(self) -> str:
        s = self.script_engine.summary()
        ok = s.get("success", 0)
        err = s.get("error", 0)
        skip = s.get("skipped", 0)
        if ok + err + skip == 0:
            return "No executions yet"
        parts = []
        if ok:
            parts.append(f"{ok} ok")
        if err:
            parts.append(f"{err} err")
        if skip:
            parts.append(f"{skip} skip")
        return " | ".join(parts)

    def selected_title(self) -> str:
        if self.selected_id and self.selected_id in self.doc.nodes:
            return self.doc.node(self.selected_id).title
        return "None"

    def document_depth(self) -> int:
        def depth(node_id: str | None) -> int:
            if node_id is None:
                return 0
            node = self.doc.node(node_id)
            if node.collapsed or not node.children:
                return 1
            return 1 + max(depth(child) for child in node.children)

        return depth(self.doc.root_id)

    def select_node(self, node_id: str | None) -> None:
        self.selected_id = node_id if node_id in self.doc.nodes else None
        self.scene.selected_id = self.selected_id
        self.inspector.set_selected(self.selected_id)
        self.refresh_editor_geometry()
        self.canvas.update()

    def selected_node(self):
        if self.selected_id is None or self.selected_id not in self.doc.nodes:
            return None
        return self.doc.node(self.selected_id)

    def update_status(self, sx: float, sy: float) -> None:
        world = self.camera.screen_to_world(sx, sy)
        node = self.selected_node()
        node_label = node.title if node is not None else "None"
        self.statusBar().showMessage(
            f"Selected: {node_label} | Zoom: {self.camera.zoom * 100:.0f}% | World: ({world.x():.0f}, {world.y():.0f})"
        )

    def collapse_hit_test(self, node_id: str, world: QPointF) -> bool:
        rect = self.scene.node_rect(node_id)
        pill = QRectF(rect.right() - 18.0, rect.top() + 8.0, 12.0, 12.0)
        return self.doc.node(node_id).children != [] and pill.contains(world)

    def run_pill_hit_test(self, node_id: str, world: QPointF) -> bool:
        run_rect = self.scene.run_pill_rect(node_id)
        return run_rect is not None and run_rect.contains(world)

    # ── Script execution ──────────────────────────────────────────

    def _sync_exec_statuses(self) -> None:
        """Push ScriptEngine statuses into the scene for rendering."""
        self.scene.clear_exec_statuses()
        for node_id in self.doc.nodes:
            st = self.script_engine.status(node_id)
            if st.state != ExecState.IDLE:
                self.scene.set_exec_status(node_id, st.state.value)
        self.canvas.update()

    def run_node(self, node_id: str | None = None) -> None:
        target = node_id or self.selected_id
        if target is None:
            return
        status = self.script_engine.run_node(target)
        self._sync_exec_statuses()
        if status.state == ExecState.SUCCESS:
            msg = f"Ran '{self.doc.node(target).title}' ({status.duration_ms:.0f}ms)"
            if status.stdout.strip():
                msg += f" — {status.stdout.strip()[:60]}"
            self.statusBar().showMessage(msg, 4000)
        elif status.state == ExecState.ERROR:
            self.statusBar().showMessage(f"Error in '{self.doc.node(target).title}': {status.error}", 6000)
        elif status.state == ExecState.SKIPPED:
            self.statusBar().showMessage(f"'{self.doc.node(target).title}' — no code to run", 2000)

    def run_subtree(self, node_id: str | None = None) -> None:
        target = node_id or self.selected_id
        if target is None:
            return
        results = self.script_engine.run_subtree(target)
        self._sync_exec_statuses()
        n_ok = sum(1 for s in results.values() if s.state == ExecState.SUCCESS)
        n_err = sum(1 for s in results.values() if s.state == ExecState.ERROR)
        n_skip = sum(1 for s in results.values() if s.state == ExecState.SKIPPED)
        self.statusBar().showMessage(f"Subtree: {n_ok} passed, {n_err} errors, {n_skip} skipped", 4000)

    def run_all(self) -> None:
        self.script_engine.reset_context()
        results = self.script_engine.run_all()
        self._sync_exec_statuses()
        n_ok = sum(1 for s in results.values() if s.state == ExecState.SUCCESS)
        n_err = sum(1 for s in results.values() if s.state == ExecState.ERROR)
        n_skip = sum(1 for s in results.values() if s.state == ExecState.SKIPPED)
        self.statusBar().showMessage(f"Run all: {n_ok} passed, {n_err} errors, {n_skip} skipped", 4000)

    def clear_exec_statuses(self) -> None:
        self.script_engine.clear_status()
        self.scene.clear_exec_statuses()
        self.canvas.update()
        self.statusBar().showMessage("Execution statuses cleared", 2000)

    def show_exec_output(self) -> None:
        target = self.selected_id
        if target is None:
            return
        status = self.script_engine.status(target)
        title = self.doc.node(target).title if self.doc.has(target) else target
        text = f"Status: {status.state.value}\n"
        if status.duration_ms > 0:
            text += f"Duration: {status.duration_ms:.1f}ms\n"
        if status.error:
            text += f"\nError:\n{status.error}\n"
        if status.stdout:
            text += f"\nOutput:\n{status.stdout}"
        if status.result is not None:
            text += f"\nResult: {status.result!r}"
        if not status.stdout and not status.error and status.state == ExecState.IDLE:
            text = "No execution recorded for this node."
        QMessageBox.information(self, f"Output — {title}", text)

    def apply_command(self, name: str, mutate) -> bool:
        changed = self.commands.apply(name, mutate, before_selection=self.selected_id, after_selection_getter=lambda: self.selected_id)
        if changed:
            self.sync_scene_views()
        return changed

    def add_child(self) -> None:
        parent_id = self.selected_id or self.doc.root_id
        if parent_id is None:
            return
        new_id_holder: dict[str, str] = {}

        def mutate() -> None:
            new_id_holder["id"] = self.doc.add_child(parent_id, "New Topic")
            self.selected_id = new_id_holder["id"]

        if self.apply_command("Add child", mutate):
            self.begin_inline_rename()

    def add_sibling(self) -> None:
        base_id = self.selected_id or self.doc.root_id
        if base_id is None:
            return
        new_id_holder: dict[str, str] = {}

        def mutate() -> None:
            new_id_holder["id"] = self.doc.add_sibling(base_id, "New Topic")
            self.selected_id = new_id_holder["id"]

        if self.apply_command("Add sibling", mutate):
            self.begin_inline_rename()

    def delete_selected(self) -> None:
        if self.selected_id is None:
            return
        doomed = self.selected_id
        if doomed == self.doc.root_id:
            if QMessageBox.question(self, "Reset map", "Deleting the root will reset the document. Continue?") != QMessageBox.StandardButton.Yes:
                return

        def mutate() -> None:
            parent_id = self.doc.parent_id(doomed)
            self.doc.remove_subtree(doomed)
            self.selected_id = parent_id if parent_id in self.doc.nodes else self.doc.root_id

        self.apply_command("Delete topic", mutate)

    def toggle_collapse(self, node_id: str | None = None) -> None:
        target = node_id or self.selected_id
        if target is None or target not in self.doc.nodes:
            return
        if not self.doc.node(target).children:
            return

        def mutate() -> None:
            self.doc.toggle_collapsed(target)
            self.selected_id = target

        self.apply_command("Toggle collapse", mutate)

    def auto_layout(self) -> None:
        def mutate() -> None:
            self.layout_engine.layout(self.doc, root_center=QPointF(0.0, 0.0))

        if self.apply_command("Auto layout", mutate):
            self.fit_document()

    def fit_document(self) -> None:
        bounds = self.doc.bounds().adjusted(-70.0, -60.0, 70.0, 60.0)
        self.camera.fit_rect(bounds.x(), bounds.y(), bounds.width(), bounds.height(), 24.0)
        self.refresh_editor_geometry()
        self.canvas.update()

    def begin_inline_rename_at(self, sx: float, sy: float) -> None:
        if not self.camera.over_viewport(sx, sy):
            return
        world = self.camera.screen_to_world(sx, sy)
        node_id = self.scene.pick_node(world)
        if node_id is None:
            return
        self.select_node(node_id)
        self.begin_inline_rename()

    def begin_inline_rename(self) -> None:
        node = self.selected_node()
        if node is None:
            return
        self.title_editor.setText(node.title)
        self.title_editor.show()
        self.refresh_editor_geometry()
        self._ignore_editing_finished = False
        self.title_editor.setFocus(Qt.FocusReason.OtherFocusReason)
        self.title_editor.selectAll()

    def refresh_editor_geometry(self) -> None:
        if not self.title_editor.isVisible() or self.selected_id is None or self.selected_id not in self.doc.nodes:
            return
        rect = self.scene.node_rect(self.selected_id)
        top_left = self.camera.world_to_screen(rect.left(), rect.top())
        bottom_right = self.camera.world_to_screen(rect.right(), rect.bottom())
        x = int(top_left.x() + 8)
        y = int(top_left.y() + 8)
        w = max(80, int(bottom_right.x() - top_left.x()) - 16)
        h = max(24, int(bottom_right.y() - top_left.y()) - 16)
        self.title_editor.setGeometry(x, y, w, h)
        self.title_editor.raise_()

    def commit_inline_rename(self) -> None:
        if not self.title_editor.isVisible() or self.selected_id is None:
            return
        new_title = self.title_editor.text().strip() or "Untitled"
        old_title = self.doc.node(self.selected_id).title
        self._ignore_editing_finished = True
        self.title_editor.hide()
        if new_title != old_title:
            target = self.selected_id
            self.apply_command("Rename topic", lambda: self.doc.set_title(target, new_title))
        else:
            self.canvas.update()
        self.canvas.setFocus(Qt.FocusReason.OtherFocusReason)
        self._ignore_editing_finished = False

    def _maybe_finish_inline_rename(self) -> None:
        if self._ignore_editing_finished:
            return
        self.commit_inline_rename()

    def cancel_inline_rename(self) -> None:
        self._ignore_editing_finished = True
        self.title_editor.hide()
        self.canvas.setFocus(Qt.FocusReason.OtherFocusReason)
        self._ignore_editing_finished = False

    def edit_note(self) -> None:
        node = self.selected_node()
        if node is None:
            return
        text, ok = QInputDialog.getMultiLineText(self, "Edit note", f"Note for {node.title}", node.note)
        if not ok:
            return
        target = node.id
        self.apply_command("Edit note", lambda: self.doc.set_note(target, text))

    def apply_color(self, color: QColor) -> None:
        node = self.selected_node()
        if node is None:
            return
        target = node.id
        value = color.name(QColor.NameFormat.HexRgb)
        self.apply_command("Change color", lambda: self.doc.set_color(target, value))

    def set_branch_side(self, side: str) -> None:
        node = self.selected_node()
        if node is None or node.id == self.doc.root_id:
            return
        target = node.id

        def mutate() -> None:
            self.doc.node(target).branch_side = side
            self.doc._inherit_branch_side(target, side)  # intentional internal reuse

        self.apply_command("Set branch side", mutate)

    def promote_selected(self) -> None:
        node = self.selected_node()
        if node is None or node.parent_id is None:
            return
        parent_id = node.parent_id
        grand_id = self.doc.parent_id(parent_id)
        if grand_id is None:
            return

        def mutate() -> None:
            self.doc.reparent(node.id, grand_id)

        self.apply_command("Promote topic", mutate)

    def demote_selected(self) -> None:
        node = self.selected_node()
        if node is None:
            return
        parent_id = node.parent_id
        if parent_id is None:
            return
        siblings = self.doc.child_ids(parent_id)
        idx = siblings.index(node.id)
        if idx <= 0:
            return
        new_parent_id = siblings[idx - 1]

        def mutate() -> None:
            self.doc.reparent(node.id, new_parent_id)

        self.apply_command("Demote topic", mutate)

    def navigate_selection(self, key: int) -> None:
        if self.selected_id is None:
            self.select_node(self.doc.root_id)
            return
        current = self.doc.node(self.selected_id)
        candidate: str | None = None
        if key == Qt.Key.Key_Left:
            if current.branch_side == "right" and current.children and not current.collapsed:
                candidate = current.children[0]
            else:
                candidate = current.parent_id
        elif key == Qt.Key.Key_Right:
            if current.branch_side == "left" and current.children and not current.collapsed:
                candidate = current.children[0]
            else:
                candidate = current.parent_id if current.branch_side == "left" else (current.children[0] if current.children and not current.collapsed else current.parent_id)
        elif key == Qt.Key.Key_Up:
            parent_id = current.parent_id
            if parent_id is not None:
                siblings = self.doc.child_ids(parent_id)
                idx = siblings.index(current.id)
                if idx > 0:
                    candidate = siblings[idx - 1]
                else:
                    candidate = parent_id
        elif key == Qt.Key.Key_Down:
            if current.children and not current.collapsed:
                candidate = current.children[0]
            else:
                parent_id = current.parent_id
                if parent_id is not None:
                    siblings = self.doc.child_ids(parent_id)
                    idx = siblings.index(current.id)
                    if idx < len(siblings) - 1:
                        candidate = siblings[idx + 1]
        if candidate in self.doc.nodes:
            self.select_node(candidate)
            self.center_on_node(candidate)

    def center_on_node(self, node_id: str) -> None:
        rect = self.scene.node_rect(node_id).adjusted(-100.0, -80.0, 100.0, 80.0)
        self.camera.fit_rect(rect.x(), rect.y(), rect.width(), rect.height(), min(self.camera.vw, self.camera.vh) * 0.12)
        self.canvas.update()

    def new_document(self) -> None:
        self.commit_inline_rename()
        self.doc = MindMapDocument()
        self.layout_engine.layout(self.doc, root_center=QPointF(0.0, 0.0))
        self.scene.set_document(self.doc)
        self.selected_id = self.doc.root_id
        self.commands.clear()
        self.script_engine = ScriptEngine(self.doc)
        self.current_path = None
        self.fit_document()
        self.sync_scene_views()

    def open_document(self) -> None:
        self.commit_inline_rename()
        path, _ = QFileDialog.getOpenFileName(self, "Open mind map", str(Path.cwd()), "Mind Map (*.json)")
        if not path:
            return
        try:
            text = Path(path).read_text(encoding="utf-8")
            self.doc = MindMapDocument.from_json(text)
        except Exception as exc:  # pragma: no cover - runtime UI path
            QMessageBox.critical(self, "Open failed", str(exc))
            return
        self.scene.set_document(self.doc)
        self.selected_id = self.doc.root_id
        self.commands.clear()
        self.current_path = Path(path)
        self.fit_document()
        self.sync_scene_views()

    def save_document(self) -> None:
        self.commit_inline_rename()
        initial = str(self.current_path) if self.current_path else str(Path.cwd() / "mind_map.json")
        path, _ = QFileDialog.getSaveFileName(self, "Save mind map", initial, "Mind Map (*.json)")
        if not path:
            return
        out = Path(path)
        if out.suffix.lower() != ".json":
            out = out.with_suffix(".json")
        out.write_text(self.doc.to_json(), encoding="utf-8")
        self.current_path = out
        self.statusBar().showMessage(f"Saved {out.name}", 2400)
        self.sync_scene_views()

    def export_png(self) -> None:
        initial = str((self.current_path or Path.cwd() / "mind_map").with_suffix(".png"))
        path, _ = QFileDialog.getSaveFileName(self, "Export PNG", initial, "PNG Image (*.png)")
        if not path:
            return
        out = Path(path)
        if out.suffix.lower() != ".png":
            out = out.with_suffix(".png")
        bounds = self.doc.bounds().adjusted(-80.0, -80.0, 80.0, 80.0)
        image = QImage(int(bounds.width()), int(bounds.height()), QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(Qt.GlobalColor.white)
        painter = QPainter(image)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        temp_camera = ZCamera(0.0, 0.0, bounds.width(), bounds.height())
        temp_camera.fit_rect(bounds.x(), bounds.y(), bounds.width(), bounds.height(), 20.0)
        self.scene.draw(painter, temp_camera, self.zui.theme)
        painter.end()
        image.save(str(out), "PNG")
        self.statusBar().showMessage(f"Exported {out.name}", 2400)

    def undo(self) -> None:
        name = self.commands.undo()
        if name is not None:
            self.statusBar().showMessage(f"Undid: {name}", 2000)
            self.fit_document()

    def redo(self) -> None:
        name = self.commands.redo()
        if name is not None:
            self.statusBar().showMessage(f"Redid: {name}", 2000)
            self.fit_document()

    def draw_world(self, painter: QPainter, canvas: ZCanvas) -> None:
        self.scene.draw(painter, self.camera, self.zui.theme)


def main() -> int:
    app = QApplication(sys.argv)
    window = MindMapWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
