"""Scrollable container for ZUI.

ZScrollView clips its content to its bounds and allows vertical (and
optionally horizontal) scrolling via mouse wheel or programmatic control.

The *content* is a single child node (typically a ZVBox or ZHBox) whose
size may exceed the viewport.  The scroll view translates the content
so only the visible portion is drawn.

Usage
-----
    content = ZVBox(0, 0, 200, 0, spacing=4, padding=8)
    # ... add many children to content ...
    content.do_layout()

    scroll = ZScrollView(8, 8, 200, 400)
    scroll.set_content(content)
"""

from __future__ import annotations

from typing import Optional

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPen

from .core import ZContext, ZNode
from .events import ZPointer


class ZScrollView(ZNode):
    """A viewport that clips and scrolls a single content node."""

    SCROLLBAR_WIDTH = 6.0
    SCROLL_SPEED = 32.0

    def __init__(self, x: float, y: float, w: float, h: float) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self._content: Optional[ZNode] = None
        self._scroll_y = 0.0
        self._scroll_x = 0.0
        self._allow_horizontal = False
        self._show_scrollbar = True
        self._scrollbar_dragging = False
        self._drag_start_y = 0.0
        self._drag_start_scroll = 0.0

    @property
    def scroll_y(self) -> float:
        return self._scroll_y

    @scroll_y.setter
    def scroll_y(self, value: float) -> None:
        self._scroll_y = self._clamp_scroll_y(value)
        self._sync_content_position()

    @property
    def scroll_x(self) -> float:
        return self._scroll_x

    @scroll_x.setter
    def scroll_x(self, value: float) -> None:
        self._scroll_x = self._clamp_scroll_x(value)
        self._sync_content_position()

    def set_content(self, node: ZNode) -> None:
        """Set the scrollable content node (replaces any previous content)."""
        if self._content is not None:
            self.remove_child(self._content)
        self._content = node
        if node is not None:
            self.add_child(node)
            node.x = 0.0
            node.y = 0.0
        self._scroll_y = 0.0
        self._scroll_x = 0.0

    def content(self) -> Optional[ZNode]:
        return self._content

    def set_allow_horizontal(self, allow: bool) -> None:
        self._allow_horizontal = allow

    def scroll_to_top(self) -> None:
        self._scroll_y = 0.0

    def scroll_to_bottom(self) -> None:
        self._scroll_y = self._max_scroll_y()

    def scroll_to_reveal(self, child_y: float, child_h: float) -> None:
        """Scroll the minimum amount needed to make a child region visible."""
        if child_y < self._scroll_y:
            self._scroll_y = child_y
        elif child_y + child_h > self._scroll_y + self.h:
            self._scroll_y = child_y + child_h - self.h
        self._scroll_y = self._clamp_scroll_y(self._scroll_y)

    # ------------------------------------------------------------------
    # Content metrics
    # ------------------------------------------------------------------

    def _content_h(self) -> float:
        return self._content.h if self._content else 0.0

    def _content_w(self) -> float:
        return self._content.w if self._content else 0.0

    def _max_scroll_y(self) -> float:
        return max(0.0, self._content_h() - self.h)

    def _max_scroll_x(self) -> float:
        return max(0.0, self._content_w() - self.w)

    def _clamp_scroll_y(self, v: float) -> float:
        return max(0.0, min(v, self._max_scroll_y()))

    def _clamp_scroll_x(self, v: float) -> float:
        return max(0.0, min(v, self._max_scroll_x()))

    def _needs_scrollbar_y(self) -> bool:
        return self._content_h() > self.h + 1.0

    # ------------------------------------------------------------------
    # Scrollbar geometry
    # ------------------------------------------------------------------

    def _scrollbar_track_rect(self) -> QRectF:
        bar_w = self.SCROLLBAR_WIDTH
        return QRectF(self.w - bar_w - 2.0, 2.0, bar_w, self.h - 4.0)

    def _scrollbar_thumb_rect(self) -> QRectF:
        track = self._scrollbar_track_rect()
        content_h = max(1.0, self._content_h())
        ratio = min(1.0, self.h / content_h)
        thumb_h = max(20.0, track.height() * ratio)
        scroll_ratio = self._scroll_y / max(1.0, self._max_scroll_y()) if self._max_scroll_y() > 0 else 0.0
        thumb_y = track.y() + scroll_ratio * (track.height() - thumb_h)
        return QRectF(track.x(), thumb_y, track.width(), thumb_h)

    def _sync_content_position(self) -> None:
        """Keep the content node's position synced with the scroll offset
        so the scene graph's coordinate transforms match what's drawn."""
        if self._content is not None:
            self._content.x = -self._scroll_x
            self._content.y = -self._scroll_y

    # ------------------------------------------------------------------
    # Drawing
    # ------------------------------------------------------------------

    def draw(self, painter: QPainter, ctx: ZContext) -> None:
        if not self.visible:
            return
        self._sync_content_position()
        painter.save()
        painter.translate(self.x, self.y)
        painter.scale(self.sx, self.sy)
        self.draw_self(painter, ctx)

        # Clip to viewport
        painter.setClipRect(QRectF(0.0, 0.0, self.w, self.h), Qt.ClipOperation.IntersectClip)

        # Content draws at its own (x,y) which is (-scroll_x, -scroll_y)
        if self._content is not None:
            self._content.draw(painter, ctx)

        # Draw scrollbar on top
        if self._show_scrollbar and self._needs_scrollbar_y():
            self._draw_scrollbar(painter, ctx)

        painter.restore()

    def _draw_scrollbar(self, painter: QPainter, ctx: ZContext) -> None:
        track = self._scrollbar_track_rect()
        thumb = self._scrollbar_thumb_rect()

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(0, 0, 0, 15))
        painter.drawRoundedRect(track, 3.0, 3.0)

        alpha = 80 if self._scrollbar_dragging else 50
        painter.setBrush(QColor(0, 0, 0, alpha))
        painter.drawRoundedRect(thumb, 3.0, 3.0)

    def clips_pointer_to_bounds(self) -> bool:
        return True

    def hit(self, screen_x: float, screen_y: float) -> bool:
        """Hit-test against the viewport bounds (not scrolled content)."""
        gx, gy, gsx, gsy = self.global_transform()
        sx = gsx if gsx else 1.0
        sy = gsy if gsy else 1.0
        lx = (screen_x - gx) / sx
        ly = (screen_y - gy) / sy
        return 0.0 <= lx <= self.w and 0.0 <= ly <= self.h

    # ------------------------------------------------------------------
    # Input — scroll wheel + scrollbar drag
    # ------------------------------------------------------------------

    def mouse_pressed(self, event: ZPointer) -> bool:
        if not self.hit(event.x, event.y):
            return False

        # Check scrollbar thumb hit (in viewport-local coords, not scrolled)
        gx, gy, gsx, gsy = self.global_transform()
        sx = gsx if gsx else 1.0
        sy = gsy if gsy else 1.0
        viewport_lx = (event.x - gx) / sx
        viewport_ly = (event.y - gy) / sy

        if self._needs_scrollbar_y() and self._show_scrollbar:
            thumb = self._scrollbar_thumb_rect()
            if thumb.contains(viewport_lx, viewport_ly):
                self._scrollbar_dragging = True
                self._drag_start_y = viewport_ly
                self._drag_start_scroll = self._scroll_y
                return True

        # Let children handle it — content position is synced with scroll
        # so the dispatcher's pick_deepest finds children at their visual positions
        return False

    def mouse_dragged(self, event: ZPointer) -> bool:
        if self._scrollbar_dragging:
            gx, gy, gsx, gsy = self.global_transform()
            sy = gsy if gsy else 1.0
            viewport_ly = (event.y - gy) / sy
            dy = viewport_ly - self._drag_start_y
            track = self._scrollbar_track_rect()
            thumb = self._scrollbar_thumb_rect()
            scrollable_track = track.height() - thumb.height()
            if scrollable_track > 0.0:
                scroll_delta = dy / scrollable_track * self._max_scroll_y()
                self._scroll_y = self._clamp_scroll_y(self._drag_start_scroll + scroll_delta)
                self._sync_content_position()
            return True
        return False

    def mouse_released(self, event: ZPointer) -> bool:
        if self._scrollbar_dragging:
            self._scrollbar_dragging = False
            return True
        return False

    def mouse_wheel(self, delta: float, event: ZPointer | None = None) -> bool:
        if delta > 0:
            self._scroll_y = self._clamp_scroll_y(self._scroll_y - self.SCROLL_SPEED)
        else:
            self._scroll_y = self._clamp_scroll_y(self._scroll_y + self.SCROLL_SPEED)
        self._sync_content_position()
        return True
