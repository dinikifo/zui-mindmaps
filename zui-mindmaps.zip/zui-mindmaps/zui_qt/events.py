from __future__ import annotations

from dataclasses import dataclass

from PySide6.QtCore import Qt


@dataclass(slots=True)
class ZPointer:
    x: float
    y: float
    button: Qt.MouseButton = Qt.MouseButton.NoButton
    buttons: Qt.MouseButton = Qt.MouseButton.NoButton
    modifiers: Qt.KeyboardModifier = Qt.KeyboardModifier.NoModifier
    delta_y: float = 0.0

    def is_left(self) -> bool:
        return self.button == Qt.MouseButton.LeftButton

    def is_middle(self) -> bool:
        return self.button == Qt.MouseButton.MiddleButton

    def is_right(self) -> bool:
        return self.button == Qt.MouseButton.RightButton


@dataclass(slots=True)
class ZKey:
    key: int
    text: str
    modifiers: Qt.KeyboardModifier = Qt.KeyboardModifier.NoModifier

    def is_command_key(self) -> bool:
        return bool(
            self.modifiers & Qt.KeyboardModifier.ControlModifier
            or self.modifiers & Qt.KeyboardModifier.MetaModifier
        )

    def is_shift(self) -> bool:
        return bool(self.modifiers & Qt.KeyboardModifier.ShiftModifier)


class ZEventHandler:
    def mouse_pressed(self, event: ZPointer) -> None:
        pass

    def mouse_dragged(self, event: ZPointer) -> None:
        pass

    def mouse_released(self, event: ZPointer) -> None:
        pass

    def mouse_moved(self, event: ZPointer) -> None:
        pass

    def mouse_wheel(self, delta: float, event: ZPointer | None = None) -> None:
        pass

    def key_pressed(self, event: ZKey) -> None:
        pass

    def key_typed(self, event: ZKey) -> None:
        pass
