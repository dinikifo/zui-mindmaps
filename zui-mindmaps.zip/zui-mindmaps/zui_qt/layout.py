"""Automatic layout containers for ZUI.

ZVBox and ZHBox automatically position their children in a vertical or
horizontal stack.  They support padding, spacing, and per-child stretch
factors / fixed sizes.  Children that are themselves layout containers
will be recursively measured and arranged.

ZSpacer is a weightless invisible node that absorbs remaining space
inside a layout box, pushing siblings apart.

Usage
-----
    vbox = ZVBox(8, 8, 200, 0, spacing=6, padding=8)
    vbox.add(z.label(0, 0, 0, 18, "Title"))
    vbox.add(z.button(0, 0, 0, 28, "Click me", on_click))
    vbox.add(ZSpacer())                     # pushes next item to bottom
    vbox.add(z.label(0, 0, 0, 14, "Footer"))
    vbox.do_layout()                        # auto-computes positions & sizes

Children are added with ``add(child, stretch=0, fixed_cross=None)``.

- In a VBox, the *main axis* is vertical (Y) and the *cross axis* is
  horizontal (X).  In an HBox it is the reverse.
- ``stretch=0`` means the child keeps its own main-axis size (``h`` for
  VBox, ``w`` for HBox).  A positive value makes the child expand to
  fill remaining space proportionally.
- ``fixed_cross`` overrides the cross-axis size instead of stretching to
  fill the container width.
- A child whose main-axis size is 0 and stretch is 0 will be measured
  via ``preferred_size()`` if it implements one (nested layout
  containers do), otherwise it gets 0 height and will be invisible.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QPainter

from .core import ZContext, ZNode


@dataclass(slots=True)
class _LayoutSlot:
    child: ZNode
    stretch: float = 0.0
    fixed_cross: Optional[float] = None


class ZLayoutBase(ZNode):
    """Abstract base for VBox/HBox.  Do not instantiate directly."""

    def __init__(
        self,
        x: float,
        y: float,
        w: float,
        h: float,
        *,
        spacing: float = 4.0,
        padding: float = 0.0,
        clips: bool = True,
    ) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.spacing = spacing
        self.padding = padding
        self.clips = clips
        self._slots: list[_LayoutSlot] = []
        self._auto_h = h == 0.0  # auto-compute height from content?
        self._auto_w = w == 0.0

    # ------------------------------------------------------------------
    # Axis abstraction — overridden in VBox / HBox
    # ------------------------------------------------------------------

    def _main(self, node: ZNode) -> float:
        """Return the child's main-axis size."""
        raise NotImplementedError

    def _cross(self, node: ZNode) -> float:
        """Return the child's cross-axis size."""
        raise NotImplementedError

    def _set_main(self, node: ZNode, value: float) -> None:
        raise NotImplementedError

    def _set_cross(self, node: ZNode, value: float) -> None:
        raise NotImplementedError

    def _set_main_pos(self, node: ZNode, value: float) -> None:
        raise NotImplementedError

    def _set_cross_pos(self, node: ZNode, value: float) -> None:
        raise NotImplementedError

    def _container_main(self) -> float:
        raise NotImplementedError

    def _container_cross(self) -> float:
        raise NotImplementedError

    def _set_container_main(self, value: float) -> None:
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def add(self, child: ZNode, *, stretch: float = 0.0, fixed_cross: Optional[float] = None) -> ZNode:
        """Add *child* to this layout box and return it."""
        self.add_child(child)
        self._slots.append(_LayoutSlot(child, stretch, fixed_cross))
        return child

    def remove(self, child: ZNode) -> None:  # type: ignore[override]
        self.remove_child(child)
        self._slots = [s for s in self._slots if s.child is not child]

    def clear(self) -> None:
        self.clear_children()
        self._slots.clear()

    def preferred_size(self) -> tuple[float, float]:
        """Return (width, height) that tightly fits all children."""
        self._ensure_nested_preferred()
        main_total = self.padding * 2.0
        cross_max = 0.0
        for idx, slot in enumerate(self._slots):
            if not slot.child.visible:
                continue
            m = self._main(slot.child)
            c = self._cross(slot.child) if slot.fixed_cross is None else slot.fixed_cross
            main_total += m
            if idx > 0:
                main_total += self.spacing
            cross_max = max(cross_max, c)
        cross_total = cross_max + self.padding * 2.0
        return self._to_wh(main_total, cross_total)

    def do_layout(self) -> None:
        """Compute positions and sizes for all children.  Call after
        adding/removing children or after the container size changes."""
        self._ensure_nested_preferred()
        available_main = self._container_main() - self.padding * 2.0
        available_cross = self._container_cross() - self.padding * 2.0

        # Measure fixed children and total stretch
        visible_slots = [s for s in self._slots if s.child.visible]
        gap_total = self.spacing * max(0, len(visible_slots) - 1)
        fixed_total = 0.0
        stretch_total = 0.0
        for slot in visible_slots:
            if slot.stretch > 0.0:
                stretch_total += slot.stretch
            else:
                fixed_total += self._main(slot.child)

        remaining = max(0.0, available_main - fixed_total - gap_total)

        # Auto-size the container if requested
        if self._is_auto_main():
            content_main = fixed_total + gap_total + self.padding * 2.0
            if stretch_total > 0.0:
                content_main += remaining  # keep what stretchables need
            self._set_container_main(content_main)
            available_main = content_main - self.padding * 2.0
            remaining = max(0.0, available_main - fixed_total - gap_total)

        # Place children
        cursor = self.padding
        for slot in visible_slots:
            self._set_main_pos(slot.child, cursor)

            # Main-axis size
            if slot.stretch > 0.0 and stretch_total > 0.0:
                size = remaining * (slot.stretch / stretch_total)
                self._set_main(slot.child, size)
            # else: keep child's own main-axis size

            # Cross-axis size & position
            if slot.fixed_cross is not None:
                self._set_cross(slot.child, slot.fixed_cross)
                self._set_cross_pos(slot.child, self.padding)
            else:
                self._set_cross(slot.child, max(0.0, available_cross))
                self._set_cross_pos(slot.child, self.padding)

            cursor += self._main(slot.child) + self.spacing

        # Recurse into nested layouts
        for slot in visible_slots:
            if isinstance(slot.child, ZLayoutBase):
                slot.child.do_layout()

    # ------------------------------------------------------------------
    # Drawing — delegates to ZContainer-like clipping
    # ------------------------------------------------------------------

    def draw(self, painter: QPainter, ctx: ZContext) -> None:
        if not self.visible:
            return
        painter.save()
        painter.translate(self.x, self.y)
        painter.scale(self.sx, self.sy)
        self.draw_self(painter, ctx)
        if self.clips:
            painter.setClipRect(QRectF(0.0, 0.0, self.w, self.h), Qt.ClipOperation.IntersectClip)
        for child in list(self.children):
            child.draw(painter, ctx)
        painter.restore()

    def clips_pointer_to_bounds(self) -> bool:
        return self.clips

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _is_auto_main(self) -> bool:
        raise NotImplementedError

    def _to_wh(self, main: float, cross: float) -> tuple[float, float]:
        raise NotImplementedError

    def _ensure_nested_preferred(self) -> None:
        """For children that are layout containers with auto-sizing,
        compute their preferred size before we measure them."""
        for slot in self._slots:
            if isinstance(slot.child, ZLayoutBase):
                pw, ph = slot.child.preferred_size()
                if slot.child._auto_w:
                    slot.child.w = pw
                if slot.child._auto_h:
                    slot.child.h = ph


class ZVBox(ZLayoutBase):
    """Vertical layout: children stack top to bottom."""

    def _main(self, node: ZNode) -> float:
        return node.h

    def _cross(self, node: ZNode) -> float:
        return node.w

    def _set_main(self, node: ZNode, value: float) -> None:
        node.h = value

    def _set_cross(self, node: ZNode, value: float) -> None:
        node.w = value

    def _set_main_pos(self, node: ZNode, value: float) -> None:
        node.y = value

    def _set_cross_pos(self, node: ZNode, value: float) -> None:
        node.x = value

    def _container_main(self) -> float:
        return self.h

    def _container_cross(self) -> float:
        return self.w

    def _set_container_main(self, value: float) -> None:
        self.h = value

    def _is_auto_main(self) -> bool:
        return self._auto_h

    def _to_wh(self, main: float, cross: float) -> tuple[float, float]:
        return (cross, main)


class ZHBox(ZLayoutBase):
    """Horizontal layout: children stack left to right."""

    def _main(self, node: ZNode) -> float:
        return node.w

    def _cross(self, node: ZNode) -> float:
        return node.h

    def _set_main(self, node: ZNode, value: float) -> None:
        node.w = value

    def _set_cross(self, node: ZNode, value: float) -> None:
        node.h = value

    def _set_main_pos(self, node: ZNode, value: float) -> None:
        node.x = value

    def _set_cross_pos(self, node: ZNode, value: float) -> None:
        node.y = value

    def _container_main(self) -> float:
        return self.w

    def _container_cross(self) -> float:
        return self.h

    def _set_container_main(self, value: float) -> None:
        self.w = value

    def _is_auto_main(self) -> bool:
        return self._auto_w

    def _to_wh(self, main: float, cross: float) -> tuple[float, float]:
        return (main, cross)


class ZSpacer(ZNode):
    """An invisible node that absorbs remaining space in a layout box.

    Use ``layout.add(ZSpacer(), stretch=1)`` to push subsequent children
    to the end of the container.
    """

    def __init__(self) -> None:
        super().__init__()
        self.visible = True  # must be visible to participate in layout
        self.w = 0.0
        self.h = 0.0

    def draw(self, painter: QPainter, ctx: ZContext) -> None:
        pass  # invisible

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        pass

    def hit(self, screen_x: float, screen_y: float) -> bool:
        return False  # non-interactive
