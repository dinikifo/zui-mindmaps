from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass, field
from typing import Callable, Iterable, Optional

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QFontMetricsF, QPainter, QPainterPath, QPen, QTextOption

from .camera import ZCamera
from .theme import ZTheme


DEFAULT_NODE_W = 170.0
DEFAULT_NODE_H = 54.0
NODE_HPAD = 16.0
NODE_VPAD = 10.0
MAX_NODE_W = 280.0
MIN_NODE_W = 110.0
MIN_NODE_H = 42.0
CHILD_GAP_Y = 18.0
SIBLING_GAP_Y = 14.0
BRANCH_GAP_X = 100.0
ROOT_BRANCH_OFFSET = 120.0


@dataclass(slots=True)
class TopicNodeData:
    id: str
    title: str
    x: float = 0.0
    y: float = 0.0
    width: float = DEFAULT_NODE_W
    height: float = DEFAULT_NODE_H
    color: str = "#7aa2ff"
    note: str = ""
    parent_id: str | None = None
    children: list[str] = field(default_factory=list)
    collapsed: bool = False
    branch_side: str = "auto"  # auto, left, right

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "TopicNodeData":
        payload = dict(data)
        payload.setdefault("children", [])
        payload.setdefault("note", "")
        payload.setdefault("branch_side", "auto")
        return cls(**payload)


class MindMapDocument:
    def __init__(self) -> None:
        self.nodes: dict[str, TopicNodeData] = {}
        self.root_id: str | None = None
        self.reset_default()

    def reset_default(self) -> str:
        self.nodes.clear()
        root = self._new_node(
            title="Central Topic",
            x=0.0,
            y=0.0,
            color="#7aa2ff",
            branch_side="auto",
        )
        self.nodes[root.id] = root
        self.root_id = root.id
        ideas = self.add_child(root.id, "Ideas", color="#7aa2ff")
        planning = self.add_child(root.id, "Planning", color="#75c77e")
        research = self.add_child(root.id, "Research", color="#ffba59")
        tasks = self.add_child(root.id, "Tasks", color="#f0847d")
        self.add_child(ideas, "Sketch user flow")
        self.add_child(ideas, "Collect references")
        self.add_child(planning, "Roadmap")
        self.add_child(planning, "Milestones")
        self.add_child(research, "Competitors")
        self.add_child(tasks, "Ship prototype")
        self.add_child(tasks, "Review feedback")
        for idx, node_id in enumerate(self.child_ids(root.id)):
            self.node(node_id).branch_side = "left" if idx % 2 else "right"
        return root.id

    def _new_id(self) -> str:
        return uuid.uuid4().hex[:8]

    def _new_node(
        self,
        title: str,
        *,
        x: float = 0.0,
        y: float = 0.0,
        color: str = "#7aa2ff",
        parent_id: str | None = None,
        branch_side: str = "auto",
    ) -> TopicNodeData:
        return TopicNodeData(
            id=self._new_id(),
            title=title,
            x=x,
            y=y,
            color=color,
            parent_id=parent_id,
            branch_side=branch_side,
        )

    def node(self, node_id: str) -> TopicNodeData:
        return self.nodes[node_id]

    def root(self) -> TopicNodeData:
        if self.root_id is None:
            raise KeyError("Document has no root node")
        return self.nodes[self.root_id]

    def has(self, node_id: str | None) -> bool:
        return node_id is not None and node_id in self.nodes

    def child_ids(self, node_id: str) -> list[str]:
        return list(self.node(node_id).children)

    def parent_id(self, node_id: str) -> str | None:
        return self.node(node_id).parent_id

    def descendants(self, node_id: str) -> list[str]:
        out: list[str] = []
        stack = list(self.node(node_id).children)
        while stack:
            cur = stack.pop()
            out.append(cur)
            stack.extend(reversed(self.node(cur).children))
        return out

    def siblings(self, node_id: str) -> list[str]:
        parent_id = self.parent_id(node_id)
        if parent_id is None:
            return []
        return [cid for cid in self.node(parent_id).children if cid != node_id]

    def is_ancestor(self, possible_ancestor: str, node_id: str) -> bool:
        cur = self.parent_id(node_id)
        while cur is not None:
            if cur == possible_ancestor:
                return True
            cur = self.parent_id(cur)
        return False

    def add_child(self, parent_id: str, title: str, *, color: str | None = None) -> str:
        parent = self.node(parent_id)
        branch_side = parent.branch_side
        if parent_id == self.root_id:
            left_count = sum(1 for cid in parent.children if self.node(cid).branch_side == "left")
            right_count = sum(1 for cid in parent.children if self.node(cid).branch_side == "right")
            branch_side = "left" if left_count > right_count else "right"
        child = self._new_node(
            title=title,
            x=parent.x + (ROOT_BRANCH_OFFSET if branch_side != "left" else -ROOT_BRANCH_OFFSET),
            y=parent.y + 72.0,
            color=color or parent.color,
            parent_id=parent_id,
            branch_side=branch_side,
        )
        self.nodes[child.id] = child
        parent.children.append(child.id)
        return child.id

    def add_sibling(self, node_id: str, title: str) -> str:
        parent_id = self.parent_id(node_id)
        if parent_id is None:
            return self.add_child(node_id, title)
        return self.add_child(parent_id, title, color=self.node(node_id).color)

    def remove_subtree(self, node_id: str) -> None:
        if node_id == self.root_id:
            self.reset_default()
            return
        doomed = [node_id, *self.descendants(node_id)]
        parent_id = self.parent_id(node_id)
        if parent_id is not None:
            parent = self.node(parent_id)
            parent.children = [cid for cid in parent.children if cid != node_id]
        for doomed_id in reversed(doomed):
            self.nodes.pop(doomed_id, None)

    def reparent(self, node_id: str, new_parent_id: str, *, index: int | None = None) -> bool:
        if node_id == self.root_id or node_id == new_parent_id:
            return False
        if self.is_ancestor(node_id, new_parent_id):
            return False
        old_parent_id = self.parent_id(node_id)
        if old_parent_id == new_parent_id:
            return True
        if old_parent_id is not None:
            old_parent = self.node(old_parent_id)
            old_parent.children = [cid for cid in old_parent.children if cid != node_id]
        new_parent = self.node(new_parent_id)
        if index is None:
            new_parent.children.append(node_id)
        else:
            new_parent.children.insert(max(0, min(index, len(new_parent.children))), node_id)
        node = self.node(node_id)
        node.parent_id = new_parent_id
        node.branch_side = new_parent.branch_side if new_parent_id != self.root_id else node.branch_side
        self._inherit_branch_side(node_id, node.branch_side)
        return True

    def _inherit_branch_side(self, node_id: str, side: str) -> None:
        for child_id in self.node(node_id).children:
            child = self.node(child_id)
            child.branch_side = side
            self._inherit_branch_side(child_id, side)

    def set_title(self, node_id: str, title: str) -> None:
        self.node(node_id).title = title.strip() or "Untitled"

    def set_note(self, node_id: str, note: str) -> None:
        self.node(node_id).note = note

    def set_color(self, node_id: str, color: str) -> None:
        self.node(node_id).color = color

    def set_position(self, node_id: str, x: float, y: float) -> None:
        node = self.node(node_id)
        node.x = x
        node.y = y

    def offset_subtree(self, node_id: str, dx: float, dy: float) -> None:
        ids = [node_id, *self.descendants(node_id)]
        for cur_id in ids:
            node = self.node(cur_id)
            node.x += dx
            node.y += dy

    def set_collapsed(self, node_id: str, collapsed: bool) -> None:
        self.node(node_id).collapsed = collapsed

    def toggle_collapsed(self, node_id: str) -> None:
        node = self.node(node_id)
        node.collapsed = not node.collapsed

    def visible_node_ids(self) -> list[str]:
        root_id = self.root_id
        if root_id is None:
            return []
        out: list[str] = []

        def walk(node_id: str) -> None:
            out.append(node_id)
            node = self.node(node_id)
            if node.collapsed:
                return
            for child_id in node.children:
                walk(child_id)

        walk(root_id)
        return out

    def bounds(self) -> QRectF:
        ids = self.visible_node_ids()
        if not ids:
            return QRectF(-100.0, -100.0, 200.0, 200.0)
        left = min(self.node(i).x for i in ids)
        right = max(self.node(i).x + self.node(i).width for i in ids)
        top = min(self.node(i).y for i in ids)
        bottom = max(self.node(i).y + self.node(i).height for i in ids)
        return QRectF(left, top, max(1.0, right - left), max(1.0, bottom - top))

    def to_dict(self) -> dict:
        return {
            "root_id": self.root_id,
            "nodes": [self.nodes[node_id].to_dict() for node_id in self.nodes],
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, sort_keys=True)

    @classmethod
    def from_dict(cls, data: dict) -> "MindMapDocument":
        doc = cls.__new__(cls)
        doc.nodes = {}
        doc.root_id = data.get("root_id")
        for node_payload in data.get("nodes", []):
            node = TopicNodeData.from_dict(node_payload)
            doc.nodes[node.id] = node
        if doc.root_id is None and doc.nodes:
            doc.root_id = next(iter(doc.nodes))
        if doc.root_id is None or doc.root_id not in doc.nodes:
            MindMapDocument.__init__(doc)
        return doc

    @classmethod
    def from_json(cls, text: str) -> "MindMapDocument":
        return cls.from_dict(json.loads(text))


class SnapshotCommand:
    def __init__(
        self,
        name: str,
        before_state: str,
        after_state: str,
        before_selection: str | None,
        after_selection: str | None,
    ) -> None:
        self.name = name
        self.before_state = before_state
        self.after_state = after_state
        self.before_selection = before_selection
        self.after_selection = after_selection


class CommandStack:
    def __init__(self, get_state: Callable[[], str], restore: Callable[[str, str | None], None]) -> None:
        self._get_state = get_state
        self._restore = restore
        self.undo_stack: list[SnapshotCommand] = []
        self.redo_stack: list[SnapshotCommand] = []

    def push_transition(
        self,
        name: str,
        *,
        before_state: str,
        after_state: str,
        before_selection: str | None,
        after_selection: str | None,
    ) -> bool:
        if after_state == before_state and after_selection == before_selection:
            return False
        self.undo_stack.append(SnapshotCommand(name, before_state, after_state, before_selection, after_selection))
        self.redo_stack.clear()
        return True

    def apply(
        self,
        name: str,
        mutate: Callable[[], None],
        *,
        before_selection: str | None,
        after_selection_getter: Callable[[], str | None],
    ) -> bool:
        before_state = self._get_state()
        mutate()
        after_state = self._get_state()
        after_selection = after_selection_getter()
        return self.push_transition(
            name,
            before_state=before_state,
            after_state=after_state,
            before_selection=before_selection,
            after_selection=after_selection,
        )

    def undo(self) -> str | None:
        if not self.undo_stack:
            return None
        cmd = self.undo_stack.pop()
        self.redo_stack.append(cmd)
        self._restore(cmd.before_state, cmd.before_selection)
        return cmd.name

    def redo(self) -> str | None:
        if not self.redo_stack:
            return None
        cmd = self.redo_stack.pop()
        self.undo_stack.append(cmd)
        self._restore(cmd.after_state, cmd.after_selection)
        return cmd.name

    def clear(self) -> None:
        self.undo_stack.clear()
        self.redo_stack.clear()


class MindMapLayoutEngine:
    def __init__(self, h_gap: float = BRANCH_GAP_X, v_gap: float = SIBLING_GAP_Y) -> None:
        self.h_gap = h_gap
        self.v_gap = v_gap

    def layout(self, doc: MindMapDocument, *, root_center: QPointF = QPointF(0.0, 0.0)) -> None:
        if doc.root_id is None:
            return
        root = doc.root()
        root.x = root_center.x() - root.width / 2.0
        root.y = root_center.y() - root.height / 2.0

        left_children = [cid for cid in root.children if doc.node(cid).branch_side == "left"]
        right_children = [cid for cid in root.children if doc.node(cid).branch_side != "left"]

        self._layout_side(doc, root.id, left_children, direction=-1)
        self._layout_side(doc, root.id, right_children, direction=1)

    def _measure_subtree(self, doc: MindMapDocument, node_id: str) -> float:
        node = doc.node(node_id)
        if node.collapsed or not node.children:
            return node.height
        total = 0.0
        for idx, child_id in enumerate(node.children):
            total += self._measure_subtree(doc, child_id)
            if idx < len(node.children) - 1:
                total += self.v_gap
        return max(node.height, total)

    def _layout_side(self, doc: MindMapDocument, parent_id: str, children: list[str], *, direction: int) -> None:
        if not children:
            return
        parent = doc.node(parent_id)
        heights = [self._measure_subtree(doc, cid) for cid in children]
        total_h = sum(heights) + self.v_gap * max(0, len(children) - 1)
        cursor_y = parent.y + parent.height / 2.0 - total_h / 2.0
        anchor_x = parent.x + (parent.width + ROOT_BRANCH_OFFSET if direction > 0 else -ROOT_BRANCH_OFFSET)

        for child_id, child_h in zip(children, heights):
            child = doc.node(child_id)
            child.x = anchor_x if direction > 0 else anchor_x - child.width
            child.y = cursor_y + child_h / 2.0 - child.height / 2.0
            child.branch_side = "right" if direction > 0 else "left"
            self._inherit_side(doc, child_id, child.branch_side)
            if not child.collapsed and child.children:
                branch_anchor_x = child.x + (child.width + self.h_gap if direction > 0 else -self.h_gap)
                self._layout_subtree(doc, child_id, direction=direction, next_anchor_x=branch_anchor_x)
            cursor_y += child_h + self.v_gap

    def _layout_subtree(self, doc: MindMapDocument, parent_id: str, *, direction: int, next_anchor_x: float) -> None:
        parent = doc.node(parent_id)
        children = list(parent.children)
        if not children or parent.collapsed:
            return
        heights = [self._measure_subtree(doc, cid) for cid in children]
        total_h = sum(heights) + self.v_gap * max(0, len(children) - 1)
        cursor_y = parent.y + parent.height / 2.0 - total_h / 2.0
        for child_id, child_h in zip(children, heights):
            child = doc.node(child_id)
            child.x = next_anchor_x if direction > 0 else next_anchor_x - child.width
            child.y = cursor_y + child_h / 2.0 - child.height / 2.0
            child.branch_side = "right" if direction > 0 else "left"
            self._inherit_side(doc, child_id, child.branch_side)
            if not child.collapsed and child.children:
                anchor_x = child.x + (child.width + self.h_gap if direction > 0 else -self.h_gap)
                self._layout_subtree(doc, child_id, direction=direction, next_anchor_x=anchor_x)
            cursor_y += child_h + self.v_gap

    def _inherit_side(self, doc: MindMapDocument, node_id: str, side: str) -> None:
        for child_id in doc.node(node_id).children:
            child = doc.node(child_id)
            child.branch_side = side
            self._inherit_side(doc, child_id, side)


class TopicNodeView:
    def __init__(self, node: TopicNodeData) -> None:
        self.node_id = node.id
        self.rect = QRectF(node.x, node.y, node.width, node.height)

    def sync(self, node: TopicNodeData) -> None:
        self.rect = QRectF(node.x, node.y, node.width, node.height)

    def contains(self, world: QPointF) -> bool:
        return self.rect.contains(world)


class MindMapScene:
    def __init__(self, doc: MindMapDocument) -> None:
        self.doc = doc
        self.views: dict[str, TopicNodeView] = {}
        self.selected_id: str | None = doc.root_id
        self.hovered_id: str | None = None
        self.drop_target_id: str | None = None
        self._node_exec_statuses: dict[str, str] = {}  # node_id → "success"|"error"|"skipped"|"running"
        self.sync()

    def set_document(self, doc: MindMapDocument) -> None:
        self.doc = doc
        if self.selected_id not in doc.nodes:
            self.selected_id = doc.root_id
        self.hovered_id = None
        self.drop_target_id = None
        self._node_exec_statuses.clear()
        self.sync()

    def set_exec_status(self, node_id: str, state: str) -> None:
        """Set execution status for a node: 'success', 'error', 'skipped', 'running', or '' to clear."""
        if state:
            self._node_exec_statuses[node_id] = state
        else:
            self._node_exec_statuses.pop(node_id, None)

    def clear_exec_statuses(self) -> None:
        self._node_exec_statuses.clear()

    def run_pill_rect(self, node_id: str) -> QRectF | None:
        """Return the run-button pill rect for a node, or None if the node has no code."""
        if not self.doc.has(node_id):
            return None
        node = self.doc.node(node_id)
        if not node.note or not node.note.strip():
            return None
        view = self.views.get(node_id)
        if view is None:
            return None
        rect = view.rect
        return QRectF(rect.right() - 28.0, rect.bottom() - 20.0, 22.0, 14.0)

    def sync(self, painter: QPainter | None = None) -> None:
        metrics = QFontMetricsF(painter.font()) if painter is not None else None
        self.views.clear()
        for node_id, node in self.doc.nodes.items():
            self._measure_node(node, metrics)
            self.views[node_id] = TopicNodeView(node)

    def _measure_node(self, node: TopicNodeData, metrics: QFontMetricsF | None) -> None:
        if metrics is None:
            title_len = max(8, len(node.title))
            node.width = max(MIN_NODE_W, min(MAX_NODE_W, 70.0 + title_len * 6.8))
            lines = max(1, (title_len // 18) + 1)
            node.height = max(MIN_NODE_H, 24.0 + lines * 16.0)
            return
        text_width = max(60.0, min(MAX_NODE_W - NODE_HPAD * 2.0, metrics.horizontalAdvance(node.title) + 12.0))
        node.width = max(MIN_NODE_W, min(MAX_NODE_W, text_width + NODE_HPAD * 2.0))
        text_rect = metrics.boundingRect(QRectF(0.0, 0.0, node.width - NODE_HPAD * 2.0, 1000.0), int(Qt.TextFlag.TextWordWrap), node.title)
        note_extra = 14.0 if node.note else 0.0
        node.height = max(MIN_NODE_H, text_rect.height() + NODE_VPAD * 2.0 + note_extra)

    def pick_node(self, world: QPointF) -> str | None:
        visible = self.doc.visible_node_ids()
        for node_id in reversed(visible):
            view = self.views.get(node_id)
            if view is not None and view.contains(world):
                return node_id
        return None

    def node_rect(self, node_id: str) -> QRectF:
        return QRectF(self.views[node_id].rect)

    def visible_bounds(self) -> QRectF:
        return self.doc.bounds()

    def draw(self, painter: QPainter, camera: ZCamera, theme: ZTheme) -> None:
        self.sync(painter)
        painter.save()
        painter.setClipRect(camera.viewport_rect())
        self._draw_background(painter, camera)
        camera.apply_to_painter(painter)
        self._draw_connections(painter, theme, camera.zoom)
        self._draw_nodes(painter, theme, camera.zoom)
        camera.restore_painter(painter)
        painter.restore()

    def _draw_background(self, painter: QPainter, camera: ZCamera) -> None:
        viewport = camera.viewport_rect()
        painter.save()
        painter.fillRect(viewport, QColor(250, 250, 252))
        bounds = self.doc.bounds().adjusted(-240.0, -240.0, 240.0, 240.0)
        top_left = camera.world_to_screen(bounds.left(), bounds.top())
        bottom_right = camera.world_to_screen(bounds.right(), bounds.bottom())
        painter.setPen(QPen(QColor(232, 234, 238), 1.0))
        grid = max(24.0, 80.0 * camera.zoom)
        x = top_left.x() - (top_left.x() % grid)
        while x < bottom_right.x():
            painter.drawLine(int(x), int(top_left.y()), int(x), int(bottom_right.y()))
            x += grid
        y = top_left.y() - (top_left.y() % grid)
        while y < bottom_right.y():
            painter.drawLine(int(top_left.x()), int(y), int(bottom_right.x()), int(y))
            y += grid
        painter.restore()

    def _draw_connections(self, painter: QPainter, theme: ZTheme, zoom: float) -> None:
        for node_id in self.doc.visible_node_ids():
            node = self.doc.node(node_id)
            if node.parent_id is None:
                continue
            parent = self.doc.node(node.parent_id)
            if parent.collapsed:
                continue
            path = self._connection_path(parent, node)
            is_drop = node.parent_id == self.drop_target_id or node_id == self.drop_target_id
            pen = QPen(QColor(node.color), max(1.4 / zoom, 2.0 if is_drop else 1.8 / zoom))
            painter.setPen(pen)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawPath(path)

    def _connection_path(self, parent: TopicNodeData, child: TopicNodeData) -> QPainterPath:
        if child.branch_side == "left":
            start = QPointF(parent.x, parent.y + parent.height / 2.0)
            end = QPointF(child.x + child.width, child.y + child.height / 2.0)
        else:
            start = QPointF(parent.x + parent.width, parent.y + parent.height / 2.0)
            end = QPointF(child.x, child.y + child.height / 2.0)
        dx = (end.x() - start.x()) * 0.45
        path = QPainterPath(start)
        path.cubicTo(
            QPointF(start.x() + dx, start.y()),
            QPointF(end.x() - dx, end.y()),
            end,
        )
        return path

    def _draw_nodes(self, painter: QPainter, theme: ZTheme, zoom: float) -> None:
        option = QTextOption()
        option.setWrapMode(QTextOption.WrapMode.WordWrap)
        for node_id in self.doc.visible_node_ids():
            node = self.doc.node(node_id)
            rect = self.node_rect(node_id)
            fill = QColor(node.color)
            border = fill.darker(130)
            painter.save()
            shadow_pen = QPen(QColor(0, 0, 0, 28), max(2.0 / zoom, 1.0))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(0, 0, 0, 20))
            painter.drawRoundedRect(rect.adjusted(2.0 / zoom, 3.0 / zoom, 2.0 / zoom, 3.0 / zoom), 12.0 / zoom, 12.0 / zoom)
            painter.setPen(QPen(border, 1.2 / zoom))
            painter.setBrush(fill)
            painter.drawRoundedRect(rect, 12.0 / zoom, 12.0 / zoom)

            if node_id == self.selected_id:
                painter.setPen(QPen(theme.accent, 3.0 / zoom))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawRoundedRect(rect.adjusted(-3.0 / zoom, -3.0 / zoom, 3.0 / zoom, 3.0 / zoom), 15.0 / zoom, 15.0 / zoom)
            elif node_id == self.hovered_id:
                painter.setPen(QPen(QColor(40, 40, 40, 160), 2.0 / zoom, Qt.PenStyle.DashLine))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawRoundedRect(rect.adjusted(-2.0 / zoom, -2.0 / zoom, 2.0 / zoom, 2.0 / zoom), 14.0 / zoom, 14.0 / zoom)

            if node_id == self.drop_target_id:
                painter.setPen(QPen(QColor("#18a957"), 3.0 / zoom, Qt.PenStyle.DashLine))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawRoundedRect(rect.adjusted(-6.0 / zoom, -6.0 / zoom, 6.0 / zoom, 6.0 / zoom), 18.0 / zoom, 18.0 / zoom)

            painter.setPen(Qt.GlobalColor.white)
            text_rect = rect.adjusted(NODE_HPAD, NODE_VPAD, -NODE_HPAD, -NODE_VPAD - (12.0 if node.note else 0.0))
            painter.drawText(text_rect, node.title, option)

            if node.note:
                painter.setPen(QColor(255, 255, 255, 210))
                note_rect = QRectF(rect.left() + NODE_HPAD, rect.bottom() - 20.0, 20.0, 14.0)
                painter.drawText(note_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, "📝")

                # Run pill — bottom right, only when note has content
                run_pill = self.run_pill_rect(node_id)
                if run_pill is not None:
                    painter.setPen(Qt.PenStyle.NoPen)
                    painter.setBrush(QColor(255, 255, 255, 210))
                    painter.drawRoundedRect(run_pill, 7.0, 7.0)
                    painter.setPen(QColor(30, 120, 30))
                    font = painter.font()
                    old_size = font.pointSizeF()
                    font.setPointSizeF(max(5.5, 7.0 / max(0.3, zoom)))
                    painter.setFont(font)
                    painter.drawText(run_pill, Qt.AlignmentFlag.AlignCenter, "▶")
                    font.setPointSizeF(old_size)
                    painter.setFont(font)

            if node.children:
                sign = "+" if node.collapsed else "–"
                pill = QRectF(rect.right() - 18.0, rect.top() + 8.0, 12.0, 12.0)
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QColor(255, 255, 255, 220))
                painter.drawEllipse(pill)
                painter.setPen(QColor(50, 50, 50))
                painter.drawText(pill, Qt.AlignmentFlag.AlignCenter, sign)

            # Execution status dot — top-left corner
            exec_status = self._node_exec_statuses.get(node_id)
            if exec_status is not None:
                dot_r = 5.0
                dot_cx = rect.left() + 8.0
                dot_cy = rect.top() + 8.0
                if exec_status == "success":
                    painter.setPen(Qt.PenStyle.NoPen)
                    painter.setBrush(QColor(40, 200, 80))
                    painter.drawEllipse(QPointF(dot_cx, dot_cy), dot_r, dot_r)
                elif exec_status == "error":
                    painter.setPen(Qt.PenStyle.NoPen)
                    painter.setBrush(QColor(220, 60, 50))
                    painter.drawEllipse(QPointF(dot_cx, dot_cy), dot_r, dot_r)
                elif exec_status == "skipped":
                    painter.setPen(QPen(QColor(180, 180, 180), 1.0))
                    painter.setBrush(QColor(220, 220, 220, 120))
                    painter.drawEllipse(QPointF(dot_cx, dot_cy), dot_r, dot_r)
                elif exec_status == "running":
                    painter.setPen(Qt.PenStyle.NoPen)
                    painter.setBrush(QColor(255, 180, 40))
                    painter.drawEllipse(QPointF(dot_cx, dot_cy), dot_r, dot_r)

            painter.restore()

    def nearest_node(self, world: QPointF, *, exclude: Iterable[str] = ()) -> str | None:
        excluded = set(exclude)
        best_id: str | None = None
        best_dist = float("inf")
        for node_id in self.doc.visible_node_ids():
            if node_id in excluded:
                continue
            rect = self.node_rect(node_id)
            center = rect.center()
            dist = (center.x() - world.x()) ** 2 + (center.y() - world.y()) ** 2
            if dist < best_dist:
                best_dist = dist
                best_id = node_id
        return best_id
