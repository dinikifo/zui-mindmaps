"""Interprocess communication bridge for ZUI.

ZBridge connects a ZUI application to one or more external processes via
a simple JSON-line protocol.  The ZUI side emits **triggers** (user
actions, state changes) and receives **commands** (mutations to the UI).

Protocol
--------
Each message is a single JSON line (newline-delimited):

    {"topic": "node.clicked", "payload": {"id": "abc", "x": 120}}

- **topic**: dot-separated string identifying the message type.
- **payload**: arbitrary JSON-serialisable dict.

Built-in topics (ZUI → external):
    ui.ready              — bridge connected and UI is live
    ui.trigger.*          — a named trigger fired from user action
    ui.error              — an inbound handler raised an exception
    ui.call.result        — return value from a ui.call invocation

Built-in topics (external → ZUI):
    ui.set_property       — set a node property (id, prop, value)
    ui.call               — invoke a registered callable by name
    ui.status             — set status bar text
    ui.theme              — switch theme (light/dark)

Custom topics are freely defined by the application.

Transports
----------
- ``connect_tcp(host, port)`` — TCP socket
- ``connect_unix(path)``      — Unix domain socket
- ``connect_stdio()``         — stdin/stdout (for subprocess pipes)
- ``connect_process(cmd)``    — launch a subprocess and pipe to it

All transports are non-blocking and integrated with the Qt event loop.

Usage
-----
    bridge = ZBridge(zui)

    # Register triggers: when a button is clicked, emit a message
    bridge.trigger(my_button, "clicked", topic="compute.start")

    # Register handlers: when external process sends a command
    @bridge.on("result.ready")
    def on_result(payload):
        my_label._text = payload["text"]

    # Connect
    bridge.connect_tcp("localhost", 9876)
    # or: bridge.connect_process(["python", "my_solver.py"])
"""

from __future__ import annotations

import json
import subprocess
import sys
from typing import Any, Callable, Optional

from PySide6.QtCore import QIODevice, QObject, QProcess, QTimer, Signal, Slot
from PySide6.QtNetwork import QTcpSocket, QLocalSocket

from .core import ZNode, Zui


class _Transport(QObject):
    """Abstract base for a transport that reads/writes JSON lines."""

    message_received = Signal(dict)

    def send(self, msg: dict) -> None:
        raise NotImplementedError

    def close(self) -> None:
        raise NotImplementedError

    @property
    def connected(self) -> bool:
        raise NotImplementedError

    def _handle_line(self, line: str) -> None:
        line = line.strip()
        if not line:
            return
        try:
            msg = json.loads(line)
            if isinstance(msg, dict):
                self.message_received.emit(msg)
        except json.JSONDecodeError:
            pass  # silently drop malformed lines


class _TcpTransport(_Transport):
    def __init__(self, host: str, port: int, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._socket = QTcpSocket(self)
        self._buffer = b""
        self._socket.readyRead.connect(self._on_data)
        self._socket.connectToHost(host, port)

    def send(self, msg: dict) -> None:
        if self._socket.state() == QTcpSocket.SocketState.ConnectedState:
            data = json.dumps(msg, separators=(",", ":")) + "\n"
            self._socket.write(data.encode("utf-8"))
            self._socket.flush()

    def close(self) -> None:
        self._socket.disconnectFromHost()

    @property
    def connected(self) -> bool:
        return self._socket.state() == QTcpSocket.SocketState.ConnectedState

    def _on_data(self) -> None:
        self._buffer += bytes(self._socket.readAll())
        while b"\n" in self._buffer:
            line, self._buffer = self._buffer.split(b"\n", 1)
            self._handle_line(line.decode("utf-8", errors="replace"))


class _UnixTransport(_Transport):
    def __init__(self, path: str, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._socket = QLocalSocket(self)
        self._buffer = b""
        self._socket.readyRead.connect(self._on_data)
        self._socket.connectToServer(path)

    def send(self, msg: dict) -> None:
        if self._socket.state() == QLocalSocket.LocalSocketState.ConnectedState:
            data = json.dumps(msg, separators=(",", ":")) + "\n"
            self._socket.write(data.encode("utf-8"))
            self._socket.flush()

    def close(self) -> None:
        self._socket.disconnectFromServer()

    @property
    def connected(self) -> bool:
        return self._socket.state() == QLocalSocket.LocalSocketState.ConnectedState

    def _on_data(self) -> None:
        self._buffer += bytes(self._socket.readAll())
        while b"\n" in self._buffer:
            line, self._buffer = self._buffer.split(b"\n", 1)
            self._handle_line(line.decode("utf-8", errors="replace"))


class _ProcessTransport(_Transport):
    def __init__(self, command: list[str], parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._proc = QProcess(self)
        self._buffer = b""
        self._proc.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        self._proc.readyReadStandardOutput.connect(self._on_stdout)
        self._proc.start(command[0], command[1:])

    def send(self, msg: dict) -> None:
        if self._proc.state() == QProcess.ProcessState.Running:
            data = json.dumps(msg, separators=(",", ":")) + "\n"
            self._proc.write(data.encode("utf-8"))

    def close(self) -> None:
        if self._proc.state() == QProcess.ProcessState.Running:
            self._proc.terminate()
            self._proc.waitForFinished(2000)

    @property
    def connected(self) -> bool:
        return self._proc.state() == QProcess.ProcessState.Running

    def _on_stdout(self) -> None:
        self._buffer += bytes(self._proc.readAllStandardOutput())
        while b"\n" in self._buffer:
            line, self._buffer = self._buffer.split(b"\n", 1)
            self._handle_line(line.decode("utf-8", errors="replace"))


class _StdioTransport(_Transport):
    """Reads from stdin, writes to stdout.  Useful when the ZUI app
    itself is launched as a subprocess by an orchestrator."""

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._alive = True
        # Poll stdin via a timer since QSocketNotifier on stdin is
        # platform-fragile.  16ms keeps it responsive.
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._poll_stdin)
        self._timer.start(16)
        self._buffer = ""

    def send(self, msg: dict) -> None:
        if self._alive:
            line = json.dumps(msg, separators=(",", ":")) + "\n"
            sys.stdout.write(line)
            sys.stdout.flush()

    def close(self) -> None:
        self._alive = False
        self._timer.stop()

    @property
    def connected(self) -> bool:
        return self._alive

    def _poll_stdin(self) -> None:
        import select

        try:
            while select.select([sys.stdin], [], [], 0)[0]:
                line = sys.stdin.readline()
                if not line:
                    self._alive = False
                    self._timer.stop()
                    return
                self._handle_line(line)
        except Exception:
            pass


# ── Trigger descriptor ────────────────────────────────────────────

class _TriggerBinding:
    """Binds a ZNode event to a bridge message."""

    __slots__ = ("node", "event_name", "topic", "payload_fn", "bridge")

    def __init__(
        self,
        node: ZNode,
        event_name: str,
        topic: str,
        payload_fn: Callable[[], dict] | None,
        bridge: "ZBridge",
    ) -> None:
        self.node = node
        self.event_name = event_name
        self.topic = topic
        self.payload_fn = payload_fn
        self.bridge = bridge

    def fire(self, **extra: Any) -> None:
        payload: dict[str, Any] = {"node_id": self.node.id}
        if self.payload_fn is not None:
            payload.update(self.payload_fn())
        payload.update(extra)
        self.bridge.emit(self.topic, payload)


# ── Main bridge ───────────────────────────────────────────────────

class ZBridge(QObject):
    """Bidirectional IPC bridge between ZUI and external processes."""

    # Qt signal emitted for every inbound message (for debugging / logging)
    inbound = Signal(str, dict)   # topic, payload
    outbound = Signal(str, dict)  # topic, payload
    connected_changed = Signal(bool)

    def __init__(self, zui: Zui, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._zui = zui
        self._transport: Optional[_Transport] = None
        self._handlers: dict[str, list[Callable[[dict], None]]] = {}
        self._triggers: list[_TriggerBinding] = []
        self._callables: dict[str, Callable] = {}
        self._nodes_by_id: dict[str, ZNode] = {}

        # Register built-in command handlers
        self.on("ui.set_property")(self._cmd_set_property)
        self.on("ui.call")(self._cmd_call)
        self.on("ui.status")(self._cmd_status)
        self.on("ui.theme")(self._cmd_theme)

    # ── Connection ────────────────────────────────────────────────

    def connect_tcp(self, host: str = "localhost", port: int = 9876) -> None:
        self._set_transport(_TcpTransport(host, port, self))

    def connect_unix(self, path: str) -> None:
        self._set_transport(_UnixTransport(path, self))

    def connect_process(self, command: list[str]) -> None:
        self._set_transport(_ProcessTransport(command, self))

    def connect_stdio(self) -> None:
        self._set_transport(_StdioTransport(self))

    def disconnect(self) -> None:
        if self._transport is not None:
            self._transport.close()
            self._transport = None
            self.connected_changed.emit(False)

    @property
    def is_connected(self) -> bool:
        return self._transport is not None and self._transport.connected

    def _set_transport(self, transport: _Transport) -> None:
        if self._transport is not None:
            self._transport.close()
        self._transport = transport
        transport.message_received.connect(self._dispatch_inbound)
        # Defer readiness check — async transports may not be connected yet
        QTimer.singleShot(100, self._check_and_announce_ready)

    def _check_and_announce_ready(self) -> None:
        if self._transport is not None and self._transport.connected:
            self.connected_changed.emit(True)
            self.emit("ui.ready", {})
        elif self._transport is not None:
            # Not connected yet — retry once more
            QTimer.singleShot(500, self._retry_announce_ready)

    def _retry_announce_ready(self) -> None:
        if self._transport is not None and self._transport.connected:
            self.connected_changed.emit(True)
            self.emit("ui.ready", {})

    # ── Outbound: emit messages ───────────────────────────────────

    def emit(self, topic: str, payload: dict | None = None) -> None:
        """Send a message to the external process."""
        payload = payload or {}
        msg = {"topic": topic, "payload": payload}
        if self._transport is not None:
            self._transport.send(msg)
        self.outbound.emit(topic, payload)

    # ── Inbound: receive messages ─────────────────────────────────

    def on(self, topic: str) -> Callable:
        """Decorator to register a handler for an inbound topic.

            @bridge.on("result.ready")
            def handle(payload):
                ...
        """
        def decorator(fn: Callable[[dict], None]) -> Callable[[dict], None]:
            self._handlers.setdefault(topic, []).append(fn)
            return fn
        return decorator

    def off(self, topic: str, fn: Callable | None = None) -> None:
        """Remove handler(s) for a topic."""
        if fn is None:
            self._handlers.pop(topic, None)
        elif topic in self._handlers:
            self._handlers[topic] = [h for h in self._handlers[topic] if h is not fn]

    @Slot(dict)
    def _dispatch_inbound(self, msg: dict) -> None:
        topic = msg.get("topic", "")
        payload = msg.get("payload", {})
        self.inbound.emit(topic, payload)
        for handler in self._handlers.get(topic, []):
            try:
                handler(payload)
            except Exception as exc:
                self.emit("ui.error", {"topic": topic, "error": str(exc)})
        # Wildcard handlers
        for handler in self._handlers.get("*", []):
            try:
                handler({"topic": topic, "payload": payload})
            except Exception:
                pass

    # ── Triggers: bind ZNode events → outbound messages ───────────

    def trigger(
        self,
        node: ZNode,
        event: str,
        *,
        topic: str | None = None,
        payload: Callable[[], dict] | None = None,
    ) -> _TriggerBinding:
        """Bind a node event to an outbound message.

        Supported events:
            "clicked"       — fires when a ZButton is clicked
            "value_changed" — fires when ZTextField/ZStepper value changes
            "selected"      — fires when the node receives focus

        ``topic`` defaults to "ui.trigger.<event>".
        ``payload`` is an optional callable returning extra dict fields.
        """
        resolved_topic = topic or f"ui.trigger.{event}"
        binding = _TriggerBinding(node, event, resolved_topic, payload, self)
        self._triggers.append(binding)
        self._install_trigger(binding)
        return binding

    def _install_trigger(self, binding: _TriggerBinding) -> None:
        """Monkey-patch the node to fire the trigger on the right event."""
        node = binding.node
        event = binding.event_name

        if event == "clicked":
            # Works for ZButton: wrap on_click
            original = getattr(node, "on_click", None)

            def wrapped_click() -> None:
                if original is not None:
                    original()
                binding.fire()

            node.on_click = wrapped_click  # type: ignore[attr-defined]

        elif event == "value_changed":
            # Works for ZStepper: wrap on_change
            original_change = getattr(node, "on_change", None)

            def wrapped_change(value: Any) -> None:
                if original_change is not None:
                    original_change(value)
                binding.fire(value=value)

            node.on_change = wrapped_change  # type: ignore[attr-defined]

            # Works for ZTextField: wrap setter
            original_setter = getattr(node, "setter", None)
            if original_setter is not None:
                def wrapped_setter(text: str) -> None:
                    original_setter(text)
                    binding.fire(value=text)
                node.setter = wrapped_setter  # type: ignore[attr-defined]

        elif event == "selected":
            original_focus = node.on_focus

            def wrapped_focus() -> None:
                original_focus()
                binding.fire()

            node.on_focus = wrapped_focus  # type: ignore[attr-defined]

    # ── Node registry ─────────────────────────────────────────────

    def register_node(self, node_id: str, node: ZNode) -> None:
        """Register a node by id so the external process can address it."""
        node.id = node_id
        self._nodes_by_id[node_id] = node

    def register_callable(self, name: str, fn: Callable) -> None:
        """Register a callable that the external process can invoke."""
        self._callables[name] = fn

    def node(self, node_id: str) -> ZNode | None:
        return self._nodes_by_id.get(node_id)

    # ── Built-in command handlers ─────────────────────────────────

    def _cmd_set_property(self, payload: dict) -> None:
        """Set a property on a registered node.

        payload: {id: str, prop: str, value: any}

        Supported props:
            visible, enabled, x, y, w, h, caption, text, value, color
        """
        node = self._nodes_by_id.get(payload.get("id", ""))
        if node is None:
            return
        prop = payload.get("prop", "")
        value = payload.get("value")

        if prop == "visible":
            node.visible = bool(value)
        elif prop == "enabled":
            node.enabled = bool(value)
        elif prop in ("x", "y", "w", "h"):
            setattr(node, prop, float(value))
        elif prop == "caption" and hasattr(node, "caption"):
            node.caption = str(value)
        elif prop == "text" and hasattr(node, "_text"):
            node._text = str(value)
        elif prop == "value" and hasattr(node, "set_value"):
            node.set_value(float(value))
        elif prop == "color" and hasattr(node, "style"):
            from PySide6.QtGui import QColor
            node.style.fill = QColor(str(value))

    def _cmd_call(self, payload: dict) -> None:
        """Invoke a registered callable.

        payload: {name: str, args: list, kwargs: dict}
        """
        name = payload.get("name", "")
        fn = self._callables.get(name)
        if fn is None:
            self.emit("ui.error", {"error": f"Unknown callable: {name}"})
            return
        args = payload.get("args", [])
        kwargs = payload.get("kwargs", {})
        result = fn(*args, **kwargs)
        if result is not None:
            self.emit("ui.call.result", {"name": name, "result": result})

    def _cmd_status(self, payload: dict) -> None:
        """Set status bar text.  The app must connect this to its status bar."""
        # This is a no-op at the bridge level — apps connect via:
        #   bridge.on("ui.status")(lambda p: window.statusBar().showMessage(p["text"]))
        pass

    def _cmd_theme(self, payload: dict) -> None:
        """Switch theme.

        payload: {theme: "light" | "dark"}
        """
        from .theme import ZTheme
        name = payload.get("theme", "light")
        if name == "dark":
            self._zui.context.theme = ZTheme.dark()
        else:
            self._zui.context.theme = ZTheme.light()
