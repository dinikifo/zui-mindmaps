from __future__ import annotations

from dataclasses import dataclass

from PySide6.QtCore import QPointF, QRectF
from PySide6.QtGui import QPainter


@dataclass(slots=True)
class ZCamera:
    vx: float
    vy: float
    vw: float
    vh: float
    pan_x: float = 0.0
    pan_y: float = 0.0
    zoom: float = 1.0
    min_zoom: float = 0.05
    max_zoom: float = 32.0
    panning: bool = False
    pan_start_x: float = 0.0
    pan_start_y: float = 0.0
    pan_origin_x: float = 0.0
    pan_origin_y: float = 0.0

    def set_viewport(self, vx: float, vy: float, vw: float, vh: float) -> None:
        self.vx, self.vy, self.vw, self.vh = vx, vy, vw, vh

    def viewport_rect(self) -> QRectF:
        return QRectF(self.vx, self.vy, self.vw, self.vh)

    def set_zoom_limits(self, min_zoom: float, max_zoom: float) -> None:
        self.min_zoom = min(min_zoom, max_zoom)
        self.max_zoom = max(min_zoom, max_zoom)
        self.zoom = max(self.min_zoom, min(self.zoom, self.max_zoom))

    def world_to_screen(self, wx: float, wy: float) -> QPointF:
        return QPointF(wx * self.zoom + self.pan_x + self.vx, wy * self.zoom + self.pan_y + self.vy)

    def screen_to_world(self, sx: float, sy: float) -> QPointF:
        return QPointF((sx - self.vx - self.pan_x) / self.zoom, (sy - self.vy - self.pan_y) / self.zoom)

    def over_viewport(self, sx: float, sy: float) -> bool:
        return self.vx <= sx < self.vx + self.vw and self.vy <= sy < self.vy + self.vh

    def apply_to_painter(self, painter: QPainter) -> None:
        painter.save()
        painter.translate(self.vx + self.pan_x, self.vy + self.pan_y)
        painter.scale(self.zoom, self.zoom)

    def restore_painter(self, painter: QPainter) -> None:
        painter.restore()

    def zoom_at(self, screen_px: float, screen_py: float, factor: float) -> None:
        new_zoom = max(self.min_zoom, min(self.zoom * factor, self.max_zoom))
        ratio = new_zoom / self.zoom if self.zoom else 1.0
        self.pan_x = screen_px - self.vx - ratio * (screen_px - self.vx - self.pan_x)
        self.pan_y = screen_py - self.vy - ratio * (screen_py - self.vy - self.pan_y)
        self.zoom = new_zoom

    def on_mouse_wheel(self, delta: float, screen_px: float, screen_py: float) -> None:
        if not self.over_viewport(screen_px, screen_py):
            return
        factor = 1.1 if delta < 0 else 1.0 / 1.1
        self.zoom_at(screen_px, screen_py, factor)

    def fit_world(self, world_w: float, world_h: float, padding: float) -> None:
        scale_x = max(0.0001, (self.vw - padding * 2) / max(1.0, world_w))
        scale_y = max(0.0001, (self.vh - padding * 2) / max(1.0, world_h))
        self.zoom = max(self.min_zoom, min(min(scale_x, scale_y), self.max_zoom))
        self.pan_x = (self.vw - world_w * self.zoom) / 2.0
        self.pan_y = (self.vh - world_h * self.zoom) / 2.0

    def fit_rect(self, world_x: float, world_y: float, world_w: float, world_h: float, padding: float) -> None:
        scale_x = max(0.0001, (self.vw - padding * 2) / max(1.0, world_w))
        scale_y = max(0.0001, (self.vh - padding * 2) / max(1.0, world_h))
        self.zoom = max(self.min_zoom, min(min(scale_x, scale_y), self.max_zoom))
        self.pan_x = -world_x * self.zoom + (self.vw - world_w * self.zoom) / 2.0
        self.pan_y = -world_y * self.zoom + (self.vh - world_h * self.zoom) / 2.0

    def reset(self, world_w: float, world_h: float) -> None:
        self.zoom = 1.0
        self.pan_x = (self.vw - world_w) / 2.0
        self.pan_y = (self.vh - world_h) / 2.0

    def begin_pan(self, screen_px: float, screen_py: float) -> None:
        self.panning = True
        self.pan_start_x = screen_px
        self.pan_start_y = screen_py
        self.pan_origin_x = self.pan_x
        self.pan_origin_y = self.pan_y

    def update_pan(self, screen_px: float, screen_py: float) -> None:
        if not self.panning:
            return
        self.pan_x = self.pan_origin_x + (screen_px - self.pan_start_x)
        self.pan_y = self.pan_origin_y + (screen_py - self.pan_start_y)

    def end_pan(self) -> None:
        self.panning = False
