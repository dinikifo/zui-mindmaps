"""Node scripting engine for executable mind maps.

Executes Python code stored in TopicNodeData.note fields.  Each node's
code runs in a shared namespace with access to the document model, the
current node, and a shared context dict for inter-node data flow.

Execution status is tracked per-node so the renderer can show green/red
indicators.

Usage
-----
    engine = ScriptEngine(doc)

    # Run a single node
    engine.run_node(node_id)

    # Run a subtree (parent-first depth-first)
    engine.run_subtree(node_id)

    # Run all nodes from root
    engine.run_all()

    # Check results
    status = engine.status(node_id)
    # status.state is "idle" | "success" | "error" | "running"
    # status.result is the return value or None
    # status.error is the exception message or None
    # status.duration_ms is wall-clock time
"""

from __future__ import annotations

import io
import sys
import time
import traceback
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional

from .mindmap import MindMapDocument


class ExecState(str, Enum):
    IDLE = "idle"
    RUNNING = "running"
    SUCCESS = "success"
    ERROR = "error"
    SKIPPED = "skipped"


@dataclass
class NodeExecStatus:
    state: ExecState = ExecState.IDLE
    result: Any = None
    error: str | None = None
    stdout: str = ""
    duration_ms: float = 0.0


@dataclass
class ScriptContext:
    """The object passed to executing code as local variables.

    Code in a node's note can access:
        doc       — the MindMapDocument
        node      — the current TopicNodeData
        parent    — parent TopicNodeData or None
        children  — list of child TopicNodeData
        ctx       — shared dict (persists across nodes in a run)
        bridge    — the ZBridge instance if connected, else None
        print     — captured print (output goes to node status)
    """
    doc: MindMapDocument
    node: Any  # TopicNodeData
    parent: Any  # TopicNodeData | None
    children: list  # list[TopicNodeData]
    ctx: dict
    bridge: Any  # ZBridge | None
    output: io.StringIO


class ScriptEngine:
    """Executes Python code stored in mind-map node notes.

    **Security**: Execution is unsandboxed ``exec()`` in the host process.
    The ``enabled`` flag defaults to ``True`` for local use.  Set
    ``enabled=False`` before loading untrusted documents, or gate it
    behind a user confirmation.
    """

    def __init__(self, doc: MindMapDocument, *, bridge: Any = None, enabled: bool = True) -> None:
        self.doc = doc
        self.bridge = bridge
        self.enabled = enabled
        self._statuses: dict[str, NodeExecStatus] = {}
        self._shared_ctx: dict[str, Any] = {}
        self._on_status_changed: list[Callable[[str, NodeExecStatus], None]] = []
        self._builtins: dict | None = None

    # ── Status ────────────────────────────────────────────────────

    def status(self, node_id: str) -> NodeExecStatus:
        return self._statuses.get(node_id, NodeExecStatus())

    def clear_status(self, node_id: str | None = None) -> None:
        if node_id is None:
            self._statuses.clear()
        else:
            self._statuses.pop(node_id, None)
        self._fire_status_changed(node_id or "", NodeExecStatus())

    def on_status_changed(self, callback: Callable[[str, NodeExecStatus], None]) -> None:
        self._on_status_changed.append(callback)

    def _fire_status_changed(self, node_id: str, status: NodeExecStatus) -> None:
        for cb in self._on_status_changed:
            try:
                cb(node_id, status)
            except Exception:
                pass

    def _set_status(self, node_id: str, status: NodeExecStatus) -> None:
        self._statuses[node_id] = status
        self._fire_status_changed(node_id, status)

    # ── Shared context ────────────────────────────────────────────

    @property
    def shared_ctx(self) -> dict:
        return self._shared_ctx

    def reset_context(self) -> None:
        self._shared_ctx.clear()

    # ── Execution ─────────────────────────────────────────────────

    def has_code(self, node_id: str) -> bool:
        """Return True if the node's note contains non-empty text
        that looks like it could be code (not just whitespace)."""
        if not self.doc.has(node_id):
            return False
        note = self.doc.node(node_id).note
        return bool(note and note.strip())

    def run_node(self, node_id: str) -> NodeExecStatus:
        """Execute the code in a single node's note."""
        if not self.enabled:
            status = NodeExecStatus(state=ExecState.ERROR, error="Scripting is disabled")
            self._set_status(node_id, status)
            return status

        if not self.doc.has(node_id):
            return NodeExecStatus(state=ExecState.ERROR, error="Node not found")

        node = self.doc.node(node_id)
        code = node.note.strip()
        if not code:
            status = NodeExecStatus(state=ExecState.SKIPPED)
            self._set_status(node_id, status)
            return status

        # Mark running
        self._set_status(node_id, NodeExecStatus(state=ExecState.RUNNING))

        # Build context
        parent_data = self.doc.node(node.parent_id) if node.parent_id and self.doc.has(node.parent_id) else None
        children_data = [self.doc.node(cid) for cid in node.children if self.doc.has(cid)]

        output_buf = io.StringIO()
        script_ctx = ScriptContext(
            doc=self.doc,
            node=node,
            parent=parent_data,
            children=children_data,
            ctx=self._shared_ctx,
            bridge=self.bridge,
            output=output_buf,
        )

        local_ns: dict[str, Any] = {
            "doc": script_ctx.doc,
            "node": script_ctx.node,
            "parent": script_ctx.parent,
            "children": script_ctx.children,
            "ctx": script_ctx.ctx,
            "bridge": script_ctx.bridge,
            "print": lambda *args, **kwargs: print(*args, file=output_buf, **kwargs),
        }

        global_ns: dict[str, Any] = {"__builtins__": self._builtins or __builtins__}

        t0 = time.monotonic()
        try:
            exec(compile(code, f"<node:{node.title}>", "exec"), global_ns, local_ns)
            elapsed = (time.monotonic() - t0) * 1000.0

            # Check if the code set a special __result__ variable
            result = local_ns.get("__result__", None)

            status = NodeExecStatus(
                state=ExecState.SUCCESS,
                result=result,
                stdout=output_buf.getvalue(),
                duration_ms=elapsed,
            )
        except Exception as exc:
            elapsed = (time.monotonic() - t0) * 1000.0
            tb = traceback.format_exc()
            status = NodeExecStatus(
                state=ExecState.ERROR,
                error=f"{type(exc).__name__}: {exc}",
                stdout=output_buf.getvalue() + "\n" + tb,
                duration_ms=elapsed,
            )

        self._set_status(node_id, status)
        return status

    def run_subtree(self, node_id: str) -> dict[str, NodeExecStatus]:
        """Execute the node and all its descendants, depth-first,
        parent before children.  Returns a dict of all statuses."""
        results: dict[str, NodeExecStatus] = {}
        self._run_subtree_recursive(node_id, results)
        return results

    def _run_subtree_recursive(self, node_id: str, results: dict[str, NodeExecStatus]) -> bool:
        """Returns False if execution should stop (error in node)."""
        status = self.run_node(node_id)
        results[node_id] = status

        if status.state == ExecState.ERROR:
            # Stop propagation on error
            return False

        if not self.doc.has(node_id):
            return True

        node = self.doc.node(node_id)
        if node.collapsed:
            return True  # respect collapse — skip children

        for child_id in node.children:
            if not self._run_subtree_recursive(child_id, results):
                return False  # propagate stop

        return True

    def run_all(self) -> dict[str, NodeExecStatus]:
        """Execute all nodes from root, depth-first."""
        if self.doc.root_id is None:
            return {}
        self.reset_context()
        return self.run_subtree(self.doc.root_id)

    # ── Summary ───────────────────────────────────────────────────

    def summary(self) -> dict[str, int]:
        """Count nodes by execution state."""
        counts: dict[str, int] = {s.value: 0 for s in ExecState}
        for status in self._statuses.values():
            counts[status.state.value] = counts.get(status.state.value, 0) + 1
        return counts

    def last_output(self, node_id: str) -> str:
        """Return the captured stdout from the last execution of a node."""
        return self.status(node_id).stdout

    def all_outputs(self) -> str:
        """Concatenate all node outputs in document order."""
        if self.doc.root_id is None:
            return ""
        parts: list[str] = []
        for node_id in self._execution_order(self.doc.root_id):
            status = self.status(node_id)
            if status.stdout:
                title = self.doc.node(node_id).title if self.doc.has(node_id) else node_id
                parts.append(f"── {title} ──\n{status.stdout}")
        return "\n".join(parts)

    def _execution_order(self, node_id: str) -> list[str]:
        """Return node IDs in depth-first, parent-first order."""
        order: list[str] = [node_id]
        if self.doc.has(node_id):
            for child_id in self.doc.node(node_id).children:
                order.extend(self._execution_order(child_id))
        return order
