"""Extended widget set for ZUI.

Adds the interactive controls missing from the base widget set:
- ZCheckbox     — boolean toggle with label
- ZToggle       — iOS-style on/off switch
- ZSlider       — continuous value slider with track and thumb
- ZDropdown     — click-to-open option picker
- ZProgressBar  — determinate/indeterminate progress indicator
- ZSeparator    — horizontal or vertical divider line
- ZTooltip      — floating hover tooltip
- ZContextMenu  — right-click popup menu
"""

from __future__ import annotations

from typing import Callable, Optional

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QFontMetricsF, QPainter, QPainterPath, QPen

from .core import ZContext, ZNode
from .events import ZKey, ZPointer


def _rounded_rect(painter: QPainter, x: float, y: float, w: float, h: float, radius: float) -> None:
    painter.drawRoundedRect(QRectF(x, y, w, h), radius, radius)


# ── ZCheckbox ─────────────────────────────────────────────────────

class ZCheckbox(ZNode):
    """A checkbox with a text label."""

    BOX_SIZE = 16.0

    def __init__(
        self,
        x: float,
        y: float,
        w: float,
        h: float,
        label: str,
        checked: bool = False,
        on_changed: Callable[[bool], None] | None = None,
    ) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.label = label
        self.checked = checked
        self.on_changed = on_changed

    def set_checked(self, checked: bool, *, notify: bool = True) -> None:
        if self.checked == checked:
            return
        self.checked = checked
        if notify and self.on_changed is not None:
            self.on_changed(self.checked)

    def toggle(self) -> None:
        self.set_checked(not self.checked)

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        theme = ctx.theme
        bs = self.BOX_SIZE
        box_y = (self.h - bs) / 2.0

        # Box
        painter.setPen(QPen(theme.border, 1.0))
        painter.setBrush(theme.accent if self.checked else theme.surface)
        _rounded_rect(painter, 0.0, box_y, bs, bs, 3.0)

        # Checkmark
        if self.checked:
            painter.setPen(QPen(QColor(255, 255, 255), 2.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            path = QPainterPath()
            path.moveTo(3.5, box_y + bs * 0.5)
            path.lineTo(bs * 0.4, box_y + bs * 0.75)
            path.lineTo(bs - 3.5, box_y + bs * 0.28)
            painter.drawPath(path)

        # Label
        painter.setPen(theme.fg)
        text_rect = QRectF(bs + 8.0, 0.0, max(0.0, self.w - bs - 8.0), self.h)
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, self.label)

    def mouse_pressed(self, event: ZPointer) -> bool:
        if not self.enabled or not self.hit(event.x, event.y):
            return False
        self.toggle()
        return True


# ── ZToggle ───────────────────────────────────────────────────────

class ZToggle(ZNode):
    """An iOS-style toggle switch."""

    TRACK_W = 36.0
    TRACK_H = 20.0
    THUMB_R = 8.0

    def __init__(
        self,
        x: float,
        y: float,
        w: float,
        h: float,
        on: bool = False,
        label: str = "",
        on_changed: Callable[[bool], None] | None = None,
    ) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.on_state = on
        self.label = label
        self.on_changed = on_changed

    def set_on(self, on: bool, *, notify: bool = True) -> None:
        if self.on_state == on:
            return
        self.on_state = on
        if notify and self.on_changed is not None:
            self.on_changed(self.on_state)

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        theme = ctx.theme
        tw, th = self.TRACK_W, self.TRACK_H
        ty = (self.h - th) / 2.0

        # Track
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(theme.accent if self.on_state else theme.surface_down)
        painter.drawRoundedRect(QRectF(0, ty, tw, th), th / 2, th / 2)

        # Thumb
        thumb_x = tw - self.THUMB_R - 3.0 if self.on_state else self.THUMB_R + 3.0
        thumb_y = ty + th / 2.0
        painter.setBrush(QColor(255, 255, 255))
        painter.setPen(QPen(theme.border, 0.5))
        painter.drawEllipse(QPointF(thumb_x, thumb_y), self.THUMB_R, self.THUMB_R)

        # Label
        if self.label:
            painter.setPen(theme.fg)
            text_rect = QRectF(tw + 8.0, 0.0, max(0.0, self.w - tw - 8.0), self.h)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, self.label)

    def mouse_pressed(self, event: ZPointer) -> bool:
        if not self.enabled or not self.hit(event.x, event.y):
            return False
        self.set_on(not self.on_state)
        return True


# ── ZSlider ───────────────────────────────────────────────────────

class ZSlider(ZNode):
    """A horizontal slider with a draggable thumb."""

    TRACK_H = 4.0
    THUMB_R = 7.0

    def __init__(
        self,
        x: float,
        y: float,
        w: float,
        h: float,
        value: float = 0.0,
        min_val: float = 0.0,
        max_val: float = 1.0,
        on_changed: Callable[[float], None] | None = None,
    ) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.value = value
        self.min_val = min(min_val, max_val)
        self.max_val = max(min_val, max_val)
        self.on_changed = on_changed
        self._dragging = False

    def set_value(self, value: float, *, notify: bool = True) -> None:
        clamped = max(self.min_val, min(value, self.max_val))
        if clamped == self.value:
            return
        self.value = clamped
        if notify and self.on_changed is not None:
            self.on_changed(self.value)

    @property
    def _ratio(self) -> float:
        span = self.max_val - self.min_val
        if span <= 0:
            return 0.0
        return (self.value - self.min_val) / span

    def _thumb_x(self) -> float:
        pad = self.THUMB_R + 2.0
        return pad + self._ratio * (self.w - pad * 2.0)

    def _value_from_local_x(self, lx: float) -> float:
        pad = self.THUMB_R + 2.0
        usable = self.w - pad * 2.0
        ratio = max(0.0, min(1.0, (lx - pad) / max(1.0, usable)))
        return self.min_val + ratio * (self.max_val - self.min_val)

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        theme = ctx.theme
        cy = self.h / 2.0
        pad = self.THUMB_R + 2.0

        # Track background
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(theme.surface_down)
        painter.drawRoundedRect(
            QRectF(pad, cy - self.TRACK_H / 2, self.w - pad * 2, self.TRACK_H),
            self.TRACK_H / 2, self.TRACK_H / 2,
        )

        # Active portion
        tx = self._thumb_x()
        painter.setBrush(theme.accent)
        painter.drawRoundedRect(
            QRectF(pad, cy - self.TRACK_H / 2, tx - pad, self.TRACK_H),
            self.TRACK_H / 2, self.TRACK_H / 2,
        )

        # Thumb
        painter.setBrush(QColor(255, 255, 255))
        painter.setPen(QPen(theme.accent if self._dragging else theme.border, 1.5 if self._dragging else 1.0))
        painter.drawEllipse(QPointF(tx, cy), self.THUMB_R, self.THUMB_R)

    def mouse_pressed(self, event: ZPointer) -> bool:
        if not self.enabled or not self.hit(event.x, event.y):
            return False
        lp = self.screen_to_local(event.x, event.y)
        self._dragging = True
        self.set_value(self._value_from_local_x(lp.x()))
        return True

    def mouse_dragged(self, event: ZPointer) -> bool:
        if not self._dragging:
            return False
        lp = self.screen_to_local(event.x, event.y)
        self.set_value(self._value_from_local_x(lp.x()))
        return True

    def mouse_released(self, event: ZPointer) -> bool:
        was_dragging = self._dragging
        self._dragging = False
        return was_dragging


# ── ZDropdown ─────────────────────────────────────────────────────

class ZDropdown(ZNode):
    """A click-to-open dropdown list.

    The dropdown registers itself as a popup via the dispatcher when
    opened.  The dispatcher handles outside-click dismissal.  Escape
    also closes the dropdown because key events route to the popup.
    """

    ITEM_H = 24.0

    def __init__(
        self,
        x: float,
        y: float,
        w: float,
        h: float,
        options: list[str],
        selected: int = 0,
        on_changed: Callable[[int, str], None] | None = None,
        dispatcher: "ZEventDispatcher | None" = None,
    ) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.options = list(options)
        self.selected = max(0, min(selected, len(options) - 1)) if options else 0
        self.on_changed = on_changed
        self.dispatcher = dispatcher
        self.open = False
        self._hover_index = -1

    @property
    def selected_text(self) -> str:
        if 0 <= self.selected < len(self.options):
            return self.options[self.selected]
        return ""

    def set_selected(self, index: int, *, notify: bool = True) -> None:
        index = max(0, min(index, len(self.options) - 1))
        if index == self.selected:
            return
        self.selected = index
        if notify and self.on_changed is not None:
            self.on_changed(index, self.selected_text)

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        theme = ctx.theme

        # Main button
        painter.setPen(QPen(theme.border, 1.0))
        painter.setBrush(theme.surface)
        _rounded_rect(painter, 0, 0, self.w, self.h, theme.corner_radius)

        painter.setPen(theme.fg)
        text_rect = QRectF(8, 0, self.w - 28, self.h)
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, self.selected_text)

        # Arrow indicator
        arrow_x = self.w - 18.0
        arrow_y = self.h / 2.0
        painter.setPen(QPen(theme.fg_muted, 1.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        path = QPainterPath()
        if self.open:
            path.moveTo(arrow_x - 4, arrow_y + 2)
            path.lineTo(arrow_x, arrow_y - 2)
            path.lineTo(arrow_x + 4, arrow_y + 2)
        else:
            path.moveTo(arrow_x - 4, arrow_y - 2)
            path.lineTo(arrow_x, arrow_y + 2)
            path.lineTo(arrow_x + 4, arrow_y - 2)
        painter.drawPath(path)

        # Dropdown list
        if self.open and self.options:
            list_h = len(self.options) * self.ITEM_H
            list_y = self.h + 2.0

            # Shadow
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(theme.shadow)
            _rounded_rect(painter, 1, list_y + 1, self.w, list_h, theme.corner_radius)

            # Background
            painter.setPen(QPen(theme.border, 1.0))
            painter.setBrush(theme.surface)
            _rounded_rect(painter, 0, list_y, self.w, list_h, theme.corner_radius)

            for i, option in enumerate(self.options):
                item_y = list_y + i * self.ITEM_H
                item_rect = QRectF(0, item_y, self.w, self.ITEM_H)

                if i == self._hover_index:
                    painter.setPen(Qt.PenStyle.NoPen)
                    painter.setBrush(theme.surface_hover)
                    painter.drawRect(item_rect)

                if i == self.selected:
                    painter.setPen(theme.accent)
                else:
                    painter.setPen(theme.fg)
                painter.drawText(
                    QRectF(8, item_y, self.w - 16, self.ITEM_H),
                    Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                    option,
                )

    def hit(self, screen_x: float, screen_y: float) -> bool:
        lp = self.screen_to_local(screen_x, screen_y)
        if 0 <= lp.x() <= self.w:
            if 0 <= lp.y() <= self.h:
                return True
            if self.open:
                list_h = len(self.options) * self.ITEM_H
                if self.h <= lp.y() <= self.h + 2 + list_h:
                    return True
        return False

    def mouse_pressed(self, event: ZPointer) -> bool:
        if not self.enabled:
            return False
        if not self.hit(event.x, event.y):
            return False
        lp = self.screen_to_local(event.x, event.y)

        if self.open:
            # Check if clicking an option
            list_y = self.h + 2.0
            if lp.y() >= list_y:
                idx = int((lp.y() - list_y) / self.ITEM_H)
                if 0 <= idx < len(self.options):
                    self.set_selected(idx)
            self._close()
            return True

        # Open
        self.open = True
        self._hover_index = -1
        if self.dispatcher is not None:
            self.dispatcher.show_popup(self)
        return True

    def _close(self) -> None:
        self.open = False
        self._hover_index = -1
        if self.dispatcher is not None:
            self.dispatcher.release_popup(self)

    def on_blur(self) -> None:
        """Called by the dispatcher when the popup is dismissed."""
        self.open = False
        self._hover_index = -1

    def mouse_moved(self, event: ZPointer) -> bool:
        if self.open:
            lp = self.screen_to_local(event.x, event.y)
            list_y = self.h + 2.0
            if lp.y() >= list_y:
                self._hover_index = int((lp.y() - list_y) / self.ITEM_H)
                if self._hover_index >= len(self.options):
                    self._hover_index = -1
            else:
                self._hover_index = -1
            return True  # consume move when open
        return False

    def key_pressed(self, event: ZKey) -> None:
        if event.key == Qt.Key.Key_Escape and self.open:
            self._close()


# ── ZProgressBar ──────────────────────────────────────────────────

class ZProgressBar(ZNode):
    """A horizontal progress bar (0.0–1.0)."""

    def __init__(self, x: float, y: float, w: float, h: float, value: float = 0.0) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.value = max(0.0, min(1.0, value))
        self.indeterminate = False

    def set_value(self, value: float) -> None:
        self.value = max(0.0, min(1.0, value))
        self.indeterminate = False

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        theme = ctx.theme
        r = min(self.h / 2.0, 4.0)

        # Track
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(theme.surface_down)
        painter.drawRoundedRect(QRectF(0, 0, self.w, self.h), r, r)

        # Fill
        if self.indeterminate:
            phase = (ctx.millis % 2000) / 2000.0
            bar_w = self.w * 0.3
            bar_x = phase * (self.w + bar_w) - bar_w
            painter.setBrush(theme.accent)
            painter.setClipRect(QRectF(0, 0, self.w, self.h))
            painter.drawRoundedRect(QRectF(bar_x, 0, bar_w, self.h), r, r)
        else:
            fill_w = max(0.0, self.value * self.w)
            if fill_w > 0:
                painter.setBrush(theme.accent)
                painter.drawRoundedRect(QRectF(0, 0, fill_w, self.h), r, r)


# ── ZSeparator ────────────────────────────────────────────────────

class ZSeparator(ZNode):
    """A thin horizontal or vertical divider line."""

    def __init__(self, x: float, y: float, w: float, h: float, *, horizontal: bool = True) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.horizontal = horizontal

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        theme = ctx.theme
        painter.setPen(QPen(theme.border, 0.5))
        if self.horizontal:
            cy = self.h / 2.0
            painter.drawLine(QPointF(0, cy), QPointF(self.w, cy))
        else:
            cx = self.w / 2.0
            painter.drawLine(QPointF(cx, 0), QPointF(cx, self.h))

    def hit(self, screen_x: float, screen_y: float) -> bool:
        return False  # non-interactive


# ── ZContextMenu ──────────────────────────────────────────────────

class ZContextMenu(ZNode):
    """A floating context menu that appears on right-click.

    Uses the dispatcher's popup layer for proper outside-click
    dismissal and event routing.  Call ``show(x, y)`` to display
    and ``close()`` to dismiss.
    """

    ITEM_H = 26.0
    MIN_W = 120.0

    def __init__(self, items: list[tuple[str, Callable[[], None] | None]], dispatcher: "ZEventDispatcher | None" = None) -> None:
        super().__init__()
        self.items = items
        self.dispatcher = dispatcher
        self.visible = False
        self._hover_index = -1
        self.w = self.MIN_W
        self.h = self._compute_height()

    def show(self, screen_x: float, screen_y: float) -> None:
        self.x = screen_x
        self.y = screen_y
        self.h = self._compute_height()
        self.visible = True
        self._hover_index = -1
        if self.dispatcher is not None:
            self.dispatcher.show_popup(self)

    def close(self) -> None:
        self.visible = False
        self._hover_index = -1
        if self.dispatcher is not None:
            self.dispatcher.release_popup(self)

    def on_blur(self) -> None:
        """Called by the dispatcher when dismissed via outside click."""
        self.visible = False
        self._hover_index = -1

    def key_pressed(self, event: ZKey) -> None:
        if event.key == Qt.Key.Key_Escape and self.visible:
            self.close()

    def _compute_height(self) -> float:
        h = 4.0  # top padding
        for label, _ in self.items:
            h += 8.0 if label == "---" else self.ITEM_H
        h += 4.0  # bottom padding
        return h

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        if not self.visible:
            return
        theme = ctx.theme

        # Shadow
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(0, 0, 0, 30))
        _rounded_rect(painter, 2, 2, self.w, self.h, theme.corner_radius)

        # Background
        painter.setPen(QPen(theme.border, 0.5))
        painter.setBrush(theme.surface)
        _rounded_rect(painter, 0, 0, self.w, self.h, theme.corner_radius)

        y = 4.0
        for i, (label, callback) in enumerate(self.items):
            if label == "---":
                painter.setPen(QPen(theme.border, 0.5))
                painter.drawLine(QPointF(8, y + 4), QPointF(self.w - 8, y + 4))
                y += 8.0
                continue

            item_rect = QRectF(2, y, self.w - 4, self.ITEM_H)
            if i == self._hover_index:
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(theme.accent)
                painter.drawRoundedRect(item_rect, 4, 4)
                painter.setPen(QColor(255, 255, 255))
            else:
                enabled = callback is not None
                painter.setPen(theme.fg if enabled else theme.fg_muted)

            painter.drawText(
                QRectF(12, y, self.w - 24, self.ITEM_H),
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                label,
            )
            y += self.ITEM_H

    def mouse_pressed(self, event: ZPointer) -> bool:
        if not self.visible:
            return False
        lp = self.screen_to_local(event.x, event.y)
        idx = self._index_at(lp.y())
        if idx >= 0:
            label, callback = self.items[idx]
            if callback is not None and label != "---":
                self.close()
                callback()
                return True
        self.close()
        return True

    def mouse_moved(self, event: ZPointer) -> bool:
        if not self.visible:
            return False
        lp = self.screen_to_local(event.x, event.y)
        self._hover_index = self._index_at(lp.y())
        return True  # consume move when visible

    def _index_at(self, local_y: float) -> int:
        y = 4.0
        for i, (label, _) in enumerate(self.items):
            if label == "---":
                y += 8.0
                continue
            if y <= local_y < y + self.ITEM_H:
                return i
            y += self.ITEM_H
        return -1


# ── ZTooltip ──────────────────────────────────────────────────────

class ZTooltip(ZNode):
    """A floating tooltip label.  Managed by the app — show/hide on hover
    with a short delay.

    Usage::

        tooltip = ZTooltip()
        zui.add(tooltip)

        # On hover:
        tooltip.show_at(screen_x, screen_y + 20, "This is a button")
        # On unhover:
        tooltip.hide()
    """

    def __init__(self) -> None:
        super().__init__()
        self.visible = False
        self._text = ""
        self.w = 0.0
        self.h = 22.0

    def show_at(self, screen_x: float, screen_y: float, text: str) -> None:
        self._text = text
        self.x = screen_x
        self.y = screen_y
        self.w = max(40.0, len(text) * 7.0 + 16.0)  # approximate
        self.visible = True

    def hide(self) -> None:
        self.visible = False

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        if not self.visible or not self._text:
            return
        theme = ctx.theme

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(0, 0, 0, 25))
        _rounded_rect(painter, 1, 1, self.w, self.h, 4.0)

        painter.setPen(QPen(theme.border, 0.5))
        painter.setBrush(theme.title_bg)
        _rounded_rect(painter, 0, 0, self.w, self.h, 4.0)

        painter.setPen(theme.title_fg)
        font = painter.font()
        old_size = font.pointSizeF()
        font.setPointSizeF(10.0)
        painter.setFont(font)
        painter.drawText(
            QRectF(8, 0, self.w - 16, self.h),
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            self._text,
        )
        font.setPointSizeF(old_size)
        painter.setFont(font)

    def hit(self, screen_x: float, screen_y: float) -> bool:
        return False  # non-interactive, clicks pass through
