"""zui_qt — retained-mode scene-graph toolkit for zoomable 2D canvas apps.

Core imports are eager (always available).  Domain-specific modules
(mindmap, scripting, bridge, inspectors) are lazy — imported on first
access via __getattr__ — so ``from zui_qt import Zui`` does not pull
in the entire framework.
"""

# ── Core (always loaded) ──────────────────────────────────────────
from .camera import ZCamera
from .canvas import ZCanvas
from .core import ZContainer, ZContext, ZEventDispatcher, ZNode, Zui
from .events import ZEventHandler, ZKey, ZPointer
from .layout import ZHBox, ZSpacer, ZVBox
from .scroll import ZScrollView
from .signals import ZObservableList, ZObservableValue, ZSignalMixin
from .textarea import ZTextArea
from .theme import ZStyle, ZTheme
from .widgets import ZButton, ZLabel, ZPaletteGrid, ZStepper, ZTextField, ZWindow
from .widgets_ext import (
    ZCheckbox,
    ZContextMenu,
    ZDropdown,
    ZProgressBar,
    ZSeparator,
    ZSlider,
    ZTooltip,
    ZToggle,
)

# ── Lazy imports (loaded on first attribute access) ───────────────
_LAZY_MODULES = {
    # bridge
    "ZBridge": (".bridge", "ZBridge"),
    # mindmap
    "CommandStack": (".mindmap", "CommandStack"),
    "MindMapDocument": (".mindmap", "MindMapDocument"),
    "MindMapLayoutEngine": (".mindmap", "MindMapLayoutEngine"),
    "MindMapScene": (".mindmap", "MindMapScene"),
    "TopicNodeData": (".mindmap", "TopicNodeData"),
    # inspectors
    "SceneInspectorDock": (".inspector", "SceneInspectorDock"),
    "MindMapInspectorDock": (".mindmap_inspector", "MindMapInspectorDock"),
    # scripting
    "ScriptEngine": (".scripting", "ScriptEngine"),
    "ExecState": (".scripting", "ExecState"),
    "NodeExecStatus": (".scripting", "NodeExecStatus"),
}


def __getattr__(name: str):
    if name in _LAZY_MODULES:
        module_path, attr = _LAZY_MODULES[name]
        import importlib
        mod = importlib.import_module(module_path, __package__)
        value = getattr(mod, attr)
        globals()[name] = value  # cache so subsequent access is fast
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # Core
    "ZCamera",
    "ZCanvas",
    "ZCheckbox",
    "ZContainer",
    "ZContextMenu",
    "ZContext",
    "ZDropdown",
    "ZEventDispatcher",
    "ZEventHandler",
    "ZHBox",
    "ZKey",
    "ZNode",
    "ZObservableList",
    "ZObservableValue",
    "ZPaletteGrid",
    "ZPointer",
    "ZProgressBar",
    "ZScrollView",
    "ZSeparator",
    "ZSignalMixin",
    "ZSlider",
    "ZSpacer",
    "ZStyle",
    "ZStepper",
    "ZTextArea",
    "ZTextField",
    "ZTheme",
    "ZTooltip",
    "ZToggle",
    "ZVBox",
    "ZWindow",
    "ZButton",
    "ZLabel",
    "Zui",
    # Lazy
    "ZBridge",
    "ScriptEngine",
    "ExecState",
    "NodeExecStatus",
    "SceneInspectorDock",
    "CommandStack",
    "MindMapDocument",
    "MindMapLayoutEngine",
    "MindMapScene",
    "MindMapInspectorDock",
    "TopicNodeData",
]
