from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from PySide6.QtGui import QColor


@dataclass(slots=True)
class ZStyle:
    fill: Optional[QColor] = None
    stroke: Optional[QColor] = None
    stroke_width: float = 1.0


@dataclass(slots=True)
class ZTheme:
    bg: QColor
    surface: QColor
    surface_hover: QColor
    surface_down: QColor
    border: QColor
    title_bg: QColor
    title_fg: QColor
    fg: QColor
    fg_muted: QColor
    accent: QColor
    shadow: QColor
    corner_radius: int = 6
    title_height: int = 20
    font_size: float = 12.0

    @staticmethod
    def light() -> "ZTheme":
        return ZTheme(
            bg=QColor(220, 220, 220),
            surface=QColor(245, 245, 245),
            surface_hover=QColor(232, 232, 232),
            surface_down=QColor(195, 195, 195),
            border=QColor(70, 70, 70),
            title_bg=QColor(64, 64, 64),
            title_fg=QColor(255, 255, 255),
            fg=QColor(20, 20, 20),
            fg_muted=QColor(100, 100, 100),
            accent=QColor(70, 140, 255),
            shadow=QColor(0, 0, 0, 40),
        )

    @staticmethod
    def dark() -> "ZTheme":
        return ZTheme(
            bg=QColor(30, 30, 30),
            surface=QColor(48, 48, 48),
            surface_hover=QColor(60, 60, 60),
            surface_down=QColor(78, 78, 78),
            border=QColor(110, 110, 110),
            title_bg=QColor(24, 24, 24),
            title_fg=QColor(240, 240, 240),
            fg=QColor(235, 235, 235),
            fg_muted=QColor(170, 170, 170),
            accent=QColor(90, 170, 255),
            shadow=QColor(0, 0, 0, 65),
        )
