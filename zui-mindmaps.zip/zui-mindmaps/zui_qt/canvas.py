from __future__ import annotations

from typing import Callable, Optional

from PySide6.QtCore import QPointF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QKeyEvent, QMouseEvent, QPainter, QPaintEvent, QWheelEvent
from PySide6.QtWidgets import QWidget

from .core import ZNode, Zui
from .events import ZKey, ZPointer


class ZCanvas(QWidget):
    hoveredNodeChanged = Signal(object)
    focusedNodeChanged = Signal(object)

    def __init__(self, zui: Zui, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.zui = zui
        self.world_renderer: Optional[Callable[[QPainter, "ZCanvas"], None]] = None
        self.overlay_renderer: Optional[Callable[[QPainter, "ZCanvas"], None]] = None
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        # Continuous repaint timer — off by default.  Call
        # set_continuous(True) for animations or live data feeds.
        # In retained mode, self.update() after each event is enough.
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.update)
        self._continuous = False

    def set_continuous(self, enabled: bool, fps: int = 60) -> None:
        """Enable or disable continuous repaint at *fps* frames per second.

        When disabled (the default), the canvas only repaints in response
        to events.  Enable for cursor-blink, animations, or live data.
        """
        self._continuous = enabled
        if enabled:
            self._timer.start(max(1, 1000 // fps))
        else:
            self._timer.stop()

    def set_world_renderer(self, renderer: Callable[[QPainter, "ZCanvas"], None]) -> None:
        self.world_renderer = renderer

    def set_overlay_renderer(self, renderer: Callable[[QPainter, "ZCanvas"], None]) -> None:
        self.overlay_renderer = renderer

    def paintEvent(self, event: QPaintEvent) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.fillRect(self.rect(), self.zui.theme.bg)
        if self.world_renderer is not None:
            self.world_renderer(painter, self)
        self.zui.draw(painter, self.width(), self.height())
        if self.overlay_renderer is not None:
            self.overlay_renderer(painter, self)
        painter.end()

    def _pointer_from_mouse(self, event: QMouseEvent, *, button_override: Qt.MouseButton | None = None) -> ZPointer:
        pos = event.position()
        return ZPointer(
            x=pos.x(),
            y=pos.y(),
            button=button_override if button_override is not None else event.button(),
            buttons=event.buttons(),
            modifiers=event.modifiers(),
        )

    def mousePressEvent(self, event: QMouseEvent) -> None:
        self.setFocus(Qt.FocusReason.MouseFocusReason)
        self.zui.dispatcher.mouse_pressed(self._pointer_from_mouse(event))
        self.focusedNodeChanged.emit(self.zui.dispatcher.focused_node)
        self.update()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        pointer = self._pointer_from_mouse(event, button_override=Qt.MouseButton.NoButton)
        if event.buttons() != Qt.MouseButton.NoButton:
            self.zui.dispatcher.mouse_dragged(pointer)
        else:
            self.zui.dispatcher.mouse_moved(pointer)
            self.hoveredNodeChanged.emit(self.zui.dispatcher.hovered_node)
        self.update()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        self.zui.dispatcher.mouse_released(self._pointer_from_mouse(event))
        self.focusedNodeChanged.emit(self.zui.dispatcher.focused_node)
        self.update()

    def wheelEvent(self, event: QWheelEvent) -> None:
        pos = event.position()
        pointer = ZPointer(
            x=pos.x(),
            y=pos.y(),
            button=Qt.MouseButton.NoButton,
            buttons=Qt.MouseButton.NoButton,
            modifiers=event.modifiers(),
            delta_y=event.angleDelta().y(),
        )
        self.zui.dispatcher.mouse_wheel(event.angleDelta().y(), pointer)
        self.update()

    def keyPressEvent(self, event: QKeyEvent) -> None:
        zkey = ZKey(key=event.key(), text=event.text(), modifiers=event.modifiers())
        self.zui.dispatcher.key_pressed(zkey)
        if event.text():
            self.zui.dispatcher.key_typed(zkey)
        self.focusedNodeChanged.emit(self.zui.dispatcher.focused_node)
        self.update()

    def leaveEvent(self, event) -> None:  # type: ignore[override]
        self.zui.dispatcher.clear_hover()
        self.hoveredNodeChanged.emit(None)
        self.update()
        super().leaveEvent(event)
