from __future__ import annotations

from html import escape
from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDockWidget, QTextBrowser, QWidget

from .mindmap import MindMapDocument

try:
    from PySide6.QtWebEngineWidgets import QWebEngineView
except Exception:  # pragma: no cover
    QWebEngineView = None


class MindMapInspectorDock(QDockWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__("Mind Map Inspector", parent)
        self.doc: Optional[MindMapDocument] = None
        self.selected_id: Optional[str] = None
        self.hovered_id: Optional[str] = None
        self.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea)

        if QWebEngineView is not None:
            self.viewer = QWebEngineView(self)
            self._set_html = self.viewer.setHtml
        else:
            self.viewer = QTextBrowser(self)
            self._set_html = self.viewer.setHtml
        self.setWidget(self.viewer)
        self.refresh()

    def bind(self, doc: MindMapDocument, *, selected_id: str | None = None, hovered_id: str | None = None) -> None:
        self.doc = doc
        self.selected_id = selected_id
        self.hovered_id = hovered_id
        self.refresh()

    def set_selected(self, node_id: str | None) -> None:
        self.selected_id = node_id
        self.refresh()

    def set_hovered(self, node_id: str | None) -> None:
        self.hovered_id = node_id
        self.refresh()

    def refresh(self) -> None:
        self._set_html(self._render_html())

    def _render_html(self) -> str:
        if self.doc is None or self.doc.root_id is None:
            return "<html><body><p>No document loaded.</p></body></html>"
        stats = self._doc_stats()
        selected_html = self._node_detail(self.selected_id, "Selected")
        hovered_html = self._node_detail(self.hovered_id, "Hovered")
        tree_html = self._tree_html(self.doc.root_id)
        return f"""
        <html>
        <head>
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; padding: 12px; background: #1d1f24; color: #f0f2f4; }}
            h2 {{ margin: 0 0 8px 0; font-size: 15px; }}
            h3 {{ margin: 16px 0 6px 0; font-size: 13px; color: #9fd4ff; }}
            .meta {{ color: #bec6d1; font-size: 12px; }}
            .node {{ padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.06); }}
            .pill {{ display: inline-block; padding: 1px 6px; border-radius: 999px; font-size: 11px; margin-left: 6px; }}
            .sel {{ background: #2b6fff; color: white; }}
            .hov {{ background: #18a957; color: white; }}
            .chip {{ display: inline-block; padding: 3px 8px; border-radius: 999px; margin-right: 6px; background: #2c313a; font-size: 11px; }}
            .swatch {{ display: inline-block; width: 12px; height: 12px; border-radius: 99px; vertical-align: middle; margin-right: 6px; border: 1px solid rgba(255,255,255,0.2); }}
            .tree {{ padding: 2px 0; }}
        </style>
        </head>
        <body>
            <h2>Mind Map</h2>
            <div class='meta'>
                <span class='chip'>Nodes: {stats['nodes']}</span>
                <span class='chip'>Leaves: {stats['leaves']}</span>
                <span class='chip'>Depth: {stats['depth']}</span>
            </div>
            {selected_html}
            {hovered_html}
            <h3>Outline</h3>
            {tree_html}
        </body>
        </html>
        """

    def _doc_stats(self) -> dict[str, int]:
        assert self.doc is not None
        leaves = sum(1 for node in self.doc.nodes.values() if not node.children)
        depth = self._depth(self.doc.root_id)
        return {"nodes": len(self.doc.nodes), "leaves": leaves, "depth": depth}

    def _depth(self, node_id: str | None) -> int:
        if self.doc is None or node_id is None:
            return 0
        node = self.doc.node(node_id)
        if not node.children or node.collapsed:
            return 1
        return 1 + max(self._depth(child_id) for child_id in node.children)

    def _node_detail(self, node_id: Optional[str], title: str) -> str:
        if self.doc is None or node_id is None or node_id not in self.doc.nodes:
            return f"<h3>{escape(title)}</h3><div class='meta'>None</div>"
        node = self.doc.node(node_id)
        badges = ""
        if node_id == self.selected_id:
            badges += " <span class='pill sel'>selected</span>"
        if node_id == self.hovered_id:
            badges += " <span class='pill hov'>hover</span>"
        note = escape(node.note).replace("\n", "<br>") if node.note else "<em>None</em>"
        parent = escape(node.parent_id) if node.parent_id else "—"
        return (
            f"<h3>{escape(title)}</h3>"
            f"<div><span class='swatch' style='background:{escape(node.color)}'></span><strong>{escape(node.title)}</strong>{badges}</div>"
            f"<div class='meta'>id={escape(node.id)} parent={parent} children={len(node.children)} collapsed={node.collapsed}</div>"
            f"<div class='meta'>pos=({node.x:.1f}, {node.y:.1f}) size=({node.width:.1f}, {node.height:.1f})</div>"
            f"<div class='meta'>note={note}</div>"
        )

    def _tree_html(self, node_id: str, depth: int = 0) -> str:
        assert self.doc is not None
        node = self.doc.node(node_id)
        selected = " <span class='pill sel'>selected</span>" if node_id == self.selected_id else ""
        hovered = " <span class='pill hov'>hover</span>" if node_id == self.hovered_id else ""
        collapsed = " (collapsed)" if node.collapsed else ""
        html = (
            f"<div class='tree' style='margin-left:{depth * 14}px'>"
            f"<span class='swatch' style='background:{escape(node.color)}'></span>"
            f"<strong>{escape(node.title)}</strong>{selected}{hovered}"
            f" <span class='meta'>{collapsed}</span></div>"
        )
        if not node.collapsed:
            for child_id in node.children:
                html += self._tree_html(child_id, depth + 1)
        return html
