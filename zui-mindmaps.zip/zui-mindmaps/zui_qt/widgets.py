from __future__ import annotations

from math import floor
from typing import Callable, Optional

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QFontMetricsF, QGuiApplication, QPainter, QPen

from .core import ZContainer, ZContext, ZEventDispatcher, ZNode
from .events import ZKey, ZPointer


def _rounded_rect(painter: QPainter, x: float, y: float, w: float, h: float, radius: float) -> None:
    painter.drawRoundedRect(QRectF(x, y, w, h), radius, radius)


class ZWindow(ZNode):
    DEFAULT_TITLE_HEIGHT = 20

    def __init__(self, x: float, y: float, w: float, h: float, title: str) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.title = title or ""
        self.title_bar = True
        self.dragging = False
        self.drag_start_x = 0.0
        self.drag_start_y = 0.0
        self.window_start_x = 0.0
        self.window_start_y = 0.0
        self.content = ZContainer(0.0, self.DEFAULT_TITLE_HEIGHT, w, h - self.DEFAULT_TITLE_HEIGHT, clips=True)
        self.add_child(self.content)

    def add(self, child: ZNode) -> ZNode:
        self.content.add(child)
        return child

    def set_title_bar(self, enabled: bool) -> None:
        self.title_bar = enabled
        self._sync_content_layout(self._current_title_height())

    def _current_title_height(self) -> int:
        return self.DEFAULT_TITLE_HEIGHT if self.title_bar else 0

    def _sync_content_layout(self, title_height: int) -> None:
        content_y = title_height if self.title_bar else 0
        self.content.set_bounds(0.0, float(content_y), self.w, max(0.0, self.h - content_y))

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        theme = ctx.theme
        title_h = theme.title_height if self.title_bar else 0
        self._sync_content_layout(title_h)

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(theme.shadow)
        painter.drawRoundedRect(QRectF(2.0, 2.0, self.w, self.h), theme.corner_radius, theme.corner_radius)

        painter.setPen(QPen(theme.border, 1.0))
        painter.setBrush(self.style.fill or theme.surface)
        _rounded_rect(painter, 0.0, 0.0, self.w, self.h, theme.corner_radius)

        if self.title_bar:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(theme.title_bg)
            painter.drawRoundedRect(QRectF(0.0, 0.0, self.w, title_h), theme.corner_radius, theme.corner_radius)
            painter.fillRect(QRectF(0.0, title_h / 2.0, self.w, title_h / 2.0), theme.title_bg)
            painter.setPen(theme.title_fg)
            painter.drawText(QRectF(8.0, 0.0, self.w - 16.0, title_h), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, self.title)

    def mouse_pressed(self, event: ZPointer) -> bool:
        if not self.visible or not self.enabled:
            return False
        title_h = self._current_title_height()
        local = self.screen_to_local(event.x, event.y)
        if self.title_bar and 0 <= local.x() <= self.w and 0 <= local.y() < title_h:
            if self.parent is not None:
                parent_local = self.parent.screen_to_local(event.x, event.y)
                self.drag_start_x = parent_local.x()
                self.drag_start_y = parent_local.y()
            else:
                self.drag_start_x = event.x
                self.drag_start_y = event.y
            self.window_start_x = self.x
            self.window_start_y = self.y
            self.dragging = True
            self.bring_to_front()
            return True
        return self.hit(event.x, event.y)

    def mouse_dragged(self, event: ZPointer) -> bool:
        if not self.dragging:
            return False
        if self.parent is not None:
            parent_local = self.parent.screen_to_local(event.x, event.y)
            cur_x = parent_local.x()
            cur_y = parent_local.y()
        else:
            cur_x = event.x
            cur_y = event.y
        self.x = self.window_start_x + (cur_x - self.drag_start_x)
        self.y = self.window_start_y + (cur_y - self.drag_start_y)
        return True

    def mouse_released(self, event: ZPointer) -> bool:
        self.dragging = False
        return False


class ZButton(ZNode):
    def __init__(self, x: float, y: float, w: float, h: float, caption: str, on_click: Optional[Callable[[], None]]) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.caption = caption or ""
        self.on_click = on_click
        self.down = False

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        theme = ctx.theme
        painter.setPen(QPen(theme.border, 1.0))
        painter.setBrush(theme.surface_down if self.down else (self.style.fill or theme.surface))
        _rounded_rect(painter, 0.0, 0.0, self.w, self.h, theme.corner_radius)
        painter.setPen(theme.fg)
        painter.drawText(QRectF(0.0, 0.0, self.w, self.h), Qt.AlignmentFlag.AlignCenter, self.caption)

    def mouse_pressed(self, event: ZPointer) -> bool:
        if not self.enabled or not self.hit(event.x, event.y):
            return False
        self.down = True
        return True

    def mouse_released(self, event: ZPointer) -> bool:
        if not self.enabled:
            return False
        was_down = self.down
        self.down = False
        if was_down and self.hit(event.x, event.y) and self.on_click is not None:
            self.on_click()
        return was_down


class ZLabel(ZNode):
    def __init__(self, x: float, y: float, w: float, h: float, text: str | Callable[[], str]) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self._text = text

    def text(self) -> str:
        return self._text() if callable(self._text) else str(self._text)

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        painter.setPen(ctx.theme.fg)
        painter.drawText(QRectF(0.0, 0.0, self.w, self.h), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, self.text())


class ZTextField(ZNode):
    def __init__(self, x: float, y: float, w: float, h: float, getter: Callable[[], str], setter: Callable[[str], None], dispatcher: ZEventDispatcher) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.getter = getter
        self.setter = setter
        self.dispatcher = dispatcher
        self.editing = False
        self.buffer = ""
        self.caret = 0
        self.anchor = 0  # selection anchor
        self._dragging = False
        self._metrics: Optional[QFontMetricsF] = None

    @property
    def has_selection(self) -> bool:
        return self.caret != self.anchor

    @property
    def selection_range(self) -> tuple[int, int]:
        return (min(self.caret, self.anchor), max(self.caret, self.anchor))

    @property
    def selected_text(self) -> str:
        lo, hi = self.selection_range
        return self.buffer[lo:hi]

    def _delete_selection(self) -> None:
        if not self.has_selection:
            return
        lo, hi = self.selection_range
        self.buffer = self.buffer[:lo] + self.buffer[hi:]
        self.caret = lo
        self.anchor = lo

    def _pos_from_local_x(self, lx: float) -> int:
        """Find the buffer position closest to local x coordinate."""
        text = self.buffer
        target_x = lx - 8.0
        if self._metrics is None:
            return max(0, min(int(target_x / 7.5), len(text)))
        best = 0
        for i in range(len(text) + 1):
            advance = self._metrics.horizontalAdvance(text[:i])
            if advance > target_x:
                if i > 0:
                    prev = self._metrics.horizontalAdvance(text[:i - 1])
                    if target_x - prev < advance - target_x:
                        best = i - 1
                    else:
                        best = i
                break
            best = i
        return best

    @staticmethod
    def _word_left(text: str, pos: int) -> int:
        if pos <= 0:
            return 0
        i = pos - 1
        while i > 0 and not text[i].isalnum() and text[i] != "_":
            i -= 1
        while i > 0 and (text[i - 1].isalnum() or text[i - 1] == "_"):
            i -= 1
        return i

    @staticmethod
    def _word_right(text: str, pos: int) -> int:
        n = len(text)
        if pos >= n:
            return n
        i = pos
        while i < n and (text[i].isalnum() or text[i] == "_"):
            i += 1
        while i < n and not text[i].isalnum() and text[i] != "_":
            i += 1
        return i

    def on_focus(self) -> None:
        self.editing = True
        self.buffer = self.getter() or ""
        self.caret = len(self.buffer)
        self.anchor = self.caret

    def on_blur(self) -> None:
        if self.editing:
            self.setter(self.buffer)
        self.editing = False
        self._dragging = False

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        theme = ctx.theme
        text = self.buffer if self.editing else (self.getter() or "")
        self._metrics = QFontMetricsF(painter.font())

        painter.setPen(QPen(theme.accent if self.editing else theme.border, 1.0))
        painter.setBrush(theme.surface)
        _rounded_rect(painter, 0.0, 0.0, self.w, self.h, theme.corner_radius)

        # Selection highlight
        if self.editing and self.has_selection:
            lo, hi = self.selection_range
            x1 = 8.0 + self._metrics.horizontalAdvance(text[:lo])
            x2 = 8.0 + self._metrics.horizontalAdvance(text[:hi])
            sel_color = QColor(theme.accent)
            sel_color.setAlpha(60)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(sel_color)
            painter.drawRect(QRectF(x1, 3.0, x2 - x1, self.h - 6.0))

        painter.setPen(theme.fg)
        text_rect = QRectF(8.0, 0.0, max(0.0, self.w - 16.0), self.h)
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, text)

        if self.editing and ctx.cursor_blink():
            caret_x = 8.0 + self._metrics.horizontalAdvance(text[: self.caret])
            painter.setPen(QPen(theme.fg, 1.5))
            painter.drawLine(QPointF(caret_x, 5.0), QPointF(caret_x, self.h - 5.0))

    def mouse_pressed(self, event: ZPointer) -> bool:
        if not self.enabled or not self.hit(event.x, event.y):
            return False
        self.dispatcher.set_focus(self)
        self.buffer = self.getter() or ""
        lp = self.screen_to_local(event.x, event.y)
        pos = self._pos_from_local_x(lp.x())
        if event.modifiers & Qt.KeyboardModifier.ShiftModifier:
            self.caret = pos
        else:
            self.caret = pos
            self.anchor = pos
        self._dragging = True
        return True

    def mouse_dragged(self, event: ZPointer) -> bool:
        if not self._dragging:
            return False
        lp = self.screen_to_local(event.x, event.y)
        self.caret = self._pos_from_local_x(lp.x())
        return True

    def mouse_released(self, event: ZPointer) -> bool:
        was = self._dragging
        self._dragging = False
        return was

    def key_pressed(self, event: ZKey) -> None:
        if not self.editing:
            return
        cmd = event.is_command_key()
        shift = event.is_shift()
        key = event.key

        # Clipboard / select
        if cmd:
            if key == Qt.Key.Key_C:
                if self.has_selection:
                    cb = QGuiApplication.clipboard()
                    if cb:
                        cb.setText(self.selected_text)
                return
            if key == Qt.Key.Key_X:
                if self.has_selection:
                    cb = QGuiApplication.clipboard()
                    if cb:
                        cb.setText(self.selected_text)
                    self._delete_selection()
                    self.setter(self.buffer)
                return
            if key == Qt.Key.Key_V:
                cb = QGuiApplication.clipboard()
                if cb:
                    paste = cb.text() or ""
                    # Single line — strip newlines
                    paste = paste.replace("\n", " ").replace("\r", "")
                    if paste:
                        self._delete_selection()
                        self.buffer = self.buffer[:self.caret] + paste + self.buffer[self.caret:]
                        self.caret += len(paste)
                        self.anchor = self.caret
                        self.setter(self.buffer)
                return
            if key == Qt.Key.Key_A:
                self.anchor = 0
                self.caret = len(self.buffer)
                return

        if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self.setter(self.buffer)
            self.dispatcher.clear_focus()
            return
        if key == Qt.Key.Key_Escape:
            self.buffer = self.getter() or ""
            self.anchor = self.caret = len(self.buffer)
            self.dispatcher.clear_focus()
            return
        if key == Qt.Key.Key_Backspace:
            if self.has_selection:
                self._delete_selection()
            elif self.caret > 0:
                self.buffer = self.buffer[: self.caret - 1] + self.buffer[self.caret :]
                self.caret -= 1
                self.anchor = self.caret
            self.setter(self.buffer)
            return
        if key == Qt.Key.Key_Delete:
            if self.has_selection:
                self._delete_selection()
            elif self.caret < len(self.buffer):
                self.buffer = self.buffer[: self.caret] + self.buffer[self.caret + 1 :]
                self.anchor = self.caret
            self.setter(self.buffer)
            return
        if key == Qt.Key.Key_Left:
            target = self._word_left(self.buffer, self.caret) if cmd else max(0, self.caret - 1)
            if shift:
                self.caret = target
            else:
                self.caret = self.anchor = (min(self.caret, self.anchor) if self.has_selection else target)
            return
        if key == Qt.Key.Key_Right:
            target = self._word_right(self.buffer, self.caret) if cmd else min(len(self.buffer), self.caret + 1)
            if shift:
                self.caret = target
            else:
                self.caret = self.anchor = (max(self.caret, self.anchor) if self.has_selection else target)
            return
        if key == Qt.Key.Key_Home:
            if shift:
                self.caret = 0
            else:
                self.caret = self.anchor = 0
            return
        if key == Qt.Key.Key_End:
            if shift:
                self.caret = len(self.buffer)
            else:
                self.caret = self.anchor = len(self.buffer)
            return
        if event.text and event.text.isprintable() and not cmd:
            self._delete_selection()
            self.buffer = self.buffer[: self.caret] + event.text + self.buffer[self.caret :]
            self.caret += len(event.text)
            self.anchor = self.caret
            self.setter(self.buffer)


class ZStepper(ZNode):
    def __init__(self, x: float, y: float, w: float, h: float, initial: float, min_val: float, max_val: float, step: float, on_change: Optional[Callable[[float], None]]) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.value = initial
        self.min_val = min(min_val, max_val)
        self.max_val = max(min_val, max_val)
        self.step = abs(step)
        self.on_change = on_change

    def set_value(self, value: float) -> None:
        self.value = max(self.min_val, min(value, self.max_val))
        if self.on_change is not None:
            self.on_change(self.value)

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        theme = ctx.theme
        painter.setPen(QPen(theme.border, 1.0))
        painter.setBrush(theme.surface)
        _rounded_rect(painter, 0.0, 0.0, self.w, self.h, theme.corner_radius)

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(theme.surface_hover)
        left_rect = QRectF(0.0, 0.0, min(24.0, self.w / 3.0), self.h)
        right_rect = QRectF(max(0.0, self.w - min(24.0, self.w / 3.0)), 0.0, min(24.0, self.w / 3.0), self.h)
        painter.drawRoundedRect(left_rect, theme.corner_radius, theme.corner_radius)
        painter.drawRoundedRect(right_rect, theme.corner_radius, theme.corner_radius)

        painter.setPen(theme.fg)
        painter.drawText(QRectF(0.0, 0.0, self.w, self.h), Qt.AlignmentFlag.AlignCenter, f"{self.value:.0f}")
        painter.drawText(left_rect, Qt.AlignmentFlag.AlignCenter, "−")
        painter.drawText(right_rect, Qt.AlignmentFlag.AlignCenter, "+")

    def mouse_pressed(self, event: ZPointer) -> bool:
        if not self.enabled or not self.hit(event.x, event.y):
            return False
        lp = self.screen_to_local(event.x, event.y)
        edge = min(24.0, self.w / 3.0)
        if lp.x() < edge:
            self.set_value(self.value - self.step)
        elif lp.x() > self.w - edge:
            self.set_value(self.value + self.step)
        return True


class ZPaletteGrid(ZNode):
    def __init__(self, x: float, y: float, w: float, h: float, colors: list, cols: int, on_pick: Optional[Callable[[QColor], None]]) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.colors = [QColor(c) for c in colors]
        self.cols = max(1, cols)
        self.on_pick = on_pick
        self.selected: Optional[int] = None

    def _cell_metrics(self) -> tuple[float, float]:
        rows = max(1, (len(self.colors) + self.cols - 1) // self.cols)
        return self.w / self.cols, self.h / rows

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        cell_w, cell_h = self._cell_metrics()
        theme = ctx.theme
        for i, color in enumerate(self.colors):
            col = i % self.cols
            row = i // self.cols
            rect = QRectF(col * cell_w, row * cell_h, cell_w, cell_h)
            painter.setPen(QPen(theme.border, 1.0))
            painter.setBrush(color)
            painter.drawRect(rect)
            if self.selected == i:
                painter.setPen(QPen(theme.accent, 2.0))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawRect(rect.adjusted(1.0, 1.0, -1.0, -1.0))

    def mouse_pressed(self, event: ZPointer) -> bool:
        if not self.enabled or not self.hit(event.x, event.y):
            return False
        lp = self.screen_to_local(event.x, event.y)
        cell_w, cell_h = self._cell_metrics()
        col = min(self.cols - 1, max(0, int(floor(lp.x() / max(1.0, cell_w)))))
        row = max(0, int(floor(lp.y() / max(1.0, cell_h))))
        idx = row * self.cols + col
        if 0 <= idx < len(self.colors):
            self.selected = idx
            if self.on_pick is not None:
                self.on_pick(self.colors[idx])
        return True
