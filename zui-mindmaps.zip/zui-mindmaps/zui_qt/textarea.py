"""Multi-line text editing for ZUI.

ZTextArea — a retained-mode multi-line text editor rendered via QPainter.
Supports selection, clipboard, word navigation, undo, scroll, and optional
line numbers.  Lines are split on hard newlines only (no word wrap).
"""

from __future__ import annotations

from typing import Callable, Optional

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import (
    QColor,
    QFontMetricsF,
    QGuiApplication,
    QPainter,
    QPainterPath,
    QPen,
    QTextOption,
)

from .core import ZContext, ZEventDispatcher, ZNode
from .events import ZKey, ZPointer


def _rounded_rect(painter: QPainter, x: float, y: float, w: float, h: float, r: float) -> None:
    painter.drawRoundedRect(QRectF(x, y, w, h), r, r)


def _word_boundary_left(text: str, pos: int) -> int:
    """Find the start of the word to the left of *pos*."""
    if pos <= 0:
        return 0
    i = pos - 1
    # skip whitespace
    while i > 0 and not text[i].isalnum() and text[i] != "_":
        i -= 1
    # skip word chars
    while i > 0 and (text[i - 1].isalnum() or text[i - 1] == "_"):
        i -= 1
    return i


def _word_boundary_right(text: str, pos: int) -> int:
    """Find the end of the word to the right of *pos*."""
    n = len(text)
    if pos >= n:
        return n
    i = pos
    # skip word chars
    while i < n and (text[i].isalnum() or text[i] == "_"):
        i += 1
    # skip whitespace
    while i < n and not text[i].isalnum() and text[i] != "_":
        i += 1
    return i


# ── ZTextArea ─────────────────────────────────────────────────────

class ZTextArea(ZNode):
    """A multi-line text editor widget.

    Parameters
    ----------
    x, y, w, h : float
        Position and size in parent coordinates.
    text : str
        Initial text content.
    dispatcher : ZEventDispatcher
        The event dispatcher (needed for focus management).
    on_changed : callable, optional
        Called with the new text whenever content changes.
    line_numbers : bool
        Show line number gutter.
    read_only : bool
        If True, text cannot be edited but can be selected/copied.
    placeholder : str
        Gray text shown when the buffer is empty.
    """

    LINE_H = 18.0
    GUTTER_W = 36.0
    PAD_X = 8.0
    PAD_Y = 6.0
    TAB_SPACES = 4

    def __init__(
        self,
        x: float,
        y: float,
        w: float,
        h: float,
        text: str = "",
        dispatcher: ZEventDispatcher | None = None,
        on_changed: Callable[[str], None] | None = None,
        *,
        line_numbers: bool = False,
        read_only: bool = False,
        placeholder: str = "",
    ) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.dispatcher = dispatcher
        self.on_changed = on_changed
        self.line_numbers = line_numbers
        self.read_only = read_only
        self.placeholder = placeholder

        # Text state
        self.buffer = text
        self.caret = len(text)
        self.anchor = self.caret  # selection anchor (anchor != caret → selection)
        self.editing = False

        # Scroll
        self._scroll_y = 0.0
        self._scroll_x = 0.0

        # Undo
        self._undo_stack: list[tuple[str, int]] = []  # (text, caret)
        self._redo_stack: list[tuple[str, int]] = []

        # Cached line layout (computed during draw)
        self._lines: list[str] = []
        self._line_offsets: list[int] = []  # char offset where each line starts
        self._metrics: QFontMetricsF | None = None

        self._dragging = False
        self._recalc_lines()

    # ── Properties ────────────────────────────────────────────────

    @property
    def text(self) -> str:
        return self.buffer

    @text.setter
    def text(self, value: str) -> None:
        self.buffer = value
        self.caret = min(self.caret, len(value))
        self.anchor = self.caret
        self._recalc_lines()

    @property
    def has_selection(self) -> bool:
        return self.caret != self.anchor

    @property
    def selection_range(self) -> tuple[int, int]:
        return (min(self.caret, self.anchor), max(self.caret, self.anchor))

    @property
    def selected_text(self) -> str:
        lo, hi = self.selection_range
        return self.buffer[lo:hi]

    @property
    def line_count(self) -> int:
        return len(self._lines)

    # ── Text content geometry ─────────────────────────────────────

    def _gutter_width(self) -> float:
        return self.GUTTER_W if self.line_numbers else 0.0

    def _text_origin_x(self) -> float:
        return self._gutter_width() + self.PAD_X

    def _text_area_w(self) -> float:
        return max(1.0, self.w - self._text_origin_x() - self.PAD_X)

    def _content_height(self) -> float:
        return max(self.LINE_H, len(self._lines) * self.LINE_H + self.PAD_Y * 2)

    def _max_scroll_y(self) -> float:
        return max(0.0, self._content_height() - self.h)

    def _clamp_scroll(self) -> None:
        self._scroll_y = max(0.0, min(self._scroll_y, self._max_scroll_y()))

    def _recalc_lines(self) -> None:
        """Split buffer into display lines (hard newlines only — no word wrap
        without metrics).  Word-wrap is done at draw time when metrics are
        available."""
        self._lines = self.buffer.split("\n")
        # Build offset table
        self._line_offsets = []
        offset = 0
        for line in self._lines:
            self._line_offsets.append(offset)
            offset += len(line) + 1  # +1 for the \n

    # ── Coordinate ↔ position mapping ─────────────────────────────

    def _pos_to_line_col(self, pos: int) -> tuple[int, int]:
        """Convert a buffer position to (line_index, column)."""
        pos = max(0, min(pos, len(self.buffer)))
        for i in range(len(self._line_offsets) - 1, -1, -1):
            if pos >= self._line_offsets[i]:
                return (i, pos - self._line_offsets[i])
        return (0, 0)

    def _line_col_to_pos(self, line: int, col: int) -> int:
        line = max(0, min(line, len(self._lines) - 1))
        col = max(0, min(col, len(self._lines[line])))
        return self._line_offsets[line] + col

    def _local_to_pos(self, lx: float, ly: float) -> int:
        """Convert local widget coordinates to a buffer position."""
        text_x = lx - self._text_origin_x() + self._scroll_x
        text_y = ly - self.PAD_Y + self._scroll_y
        line_idx = max(0, min(int(text_y / self.LINE_H), len(self._lines) - 1))
        line_text = self._lines[line_idx]

        # Find closest character
        if self._metrics is None:
            # Rough approximation
            col = max(0, min(int(text_x / 7.5), len(line_text)))
        else:
            col = 0
            for c in range(len(line_text) + 1):
                advance = self._metrics.horizontalAdvance(line_text[:c])
                if advance >= text_x:
                    # Check if closer to c or c-1
                    if c > 0:
                        prev = self._metrics.horizontalAdvance(line_text[: c - 1])
                        if text_x - prev < advance - text_x:
                            col = c - 1
                        else:
                            col = c
                    break
                col = c

        return self._line_col_to_pos(line_idx, col)

    def _pos_to_local(self, pos: int) -> QPointF:
        """Convert a buffer position to local widget coordinates."""
        line_idx, col = self._pos_to_line_col(pos)
        y = self.PAD_Y + line_idx * self.LINE_H - self._scroll_y
        line_text = self._lines[line_idx] if line_idx < len(self._lines) else ""
        if self._metrics is not None:
            x = self._text_origin_x() + self._metrics.horizontalAdvance(line_text[:col]) - self._scroll_x
        else:
            x = self._text_origin_x() + col * 7.5 - self._scroll_x
        return QPointF(x, y)

    # ── Scroll to keep caret visible ──────────────────────────────

    def _ensure_caret_visible(self) -> None:
        caret_pt = self._pos_to_local(self.caret)
        # Vertical
        caret_screen_y = caret_pt.y()
        if caret_screen_y < self.PAD_Y:
            self._scroll_y += caret_screen_y - self.PAD_Y
        elif caret_screen_y + self.LINE_H > self.h - self.PAD_Y:
            self._scroll_y += (caret_screen_y + self.LINE_H) - (self.h - self.PAD_Y)
        self._clamp_scroll()

    # ── Editing operations ────────────────────────────────────────

    def _push_undo(self) -> None:
        self._undo_stack.append((self.buffer, self.caret))
        self._redo_stack.clear()
        if len(self._undo_stack) > 200:
            self._undo_stack = self._undo_stack[-200:]

    def _notify_changed(self) -> None:
        self._recalc_lines()
        if self.on_changed is not None:
            self.on_changed(self.buffer)

    def _delete_selection(self) -> None:
        if not self.has_selection:
            return
        lo, hi = self.selection_range
        self.buffer = self.buffer[:lo] + self.buffer[hi:]
        self.caret = lo
        self.anchor = lo

    def _insert(self, text: str) -> None:
        if self.read_only:
            return
        self._push_undo()
        self._delete_selection()
        self.buffer = self.buffer[: self.caret] + text + self.buffer[self.caret :]
        self.caret += len(text)
        self.anchor = self.caret
        self._notify_changed()

    def _backspace(self) -> None:
        if self.read_only:
            return
        self._push_undo()
        if self.has_selection:
            self._delete_selection()
        elif self.caret > 0:
            self.buffer = self.buffer[: self.caret - 1] + self.buffer[self.caret :]
            self.caret -= 1
            self.anchor = self.caret
        self._notify_changed()

    def _delete(self) -> None:
        if self.read_only:
            return
        self._push_undo()
        if self.has_selection:
            self._delete_selection()
        elif self.caret < len(self.buffer):
            self.buffer = self.buffer[: self.caret] + self.buffer[self.caret + 1 :]
            self.anchor = self.caret
        self._notify_changed()

    def _undo(self) -> None:
        if not self._undo_stack:
            return
        self._redo_stack.append((self.buffer, self.caret))
        self.buffer, self.caret = self._undo_stack.pop()
        self.anchor = self.caret
        self._notify_changed()

    def _redo(self) -> None:
        if not self._redo_stack:
            return
        self._undo_stack.append((self.buffer, self.caret))
        self.buffer, self.caret = self._redo_stack.pop()
        self.anchor = self.caret
        self._notify_changed()

    def _copy(self) -> None:
        if self.has_selection:
            clipboard = QGuiApplication.clipboard()
            if clipboard is not None:
                clipboard.setText(self.selected_text)

    def _cut(self) -> None:
        if self.read_only:
            return
        self._copy()
        if self.has_selection:
            self._push_undo()
            self._delete_selection()
            self._notify_changed()

    def _paste(self) -> None:
        if self.read_only:
            return
        clipboard = QGuiApplication.clipboard()
        if clipboard is not None:
            text = clipboard.text() or ""
            if text:
                self._insert(text)

    def select_all(self) -> None:
        self.anchor = 0
        self.caret = len(self.buffer)

    # ── Focus ─────────────────────────────────────────────────────

    def on_focus(self) -> None:
        self.editing = True

    def on_blur(self) -> None:
        self.editing = False
        self._dragging = False

    # ── Drawing ───────────────────────────────────────────────────

    def draw(self, painter: QPainter, ctx: ZContext) -> None:
        if not self.visible:
            return
        painter.save()
        painter.translate(self.x, self.y)
        painter.scale(self.sx, self.sy)

        theme = ctx.theme
        self._metrics = QFontMetricsF(painter.font())
        self._recalc_lines()

        # Background
        painter.setPen(QPen(theme.accent if self.editing else theme.border, 1.0))
        painter.setBrush(theme.surface)
        _rounded_rect(painter, 0, 0, self.w, self.h, theme.corner_radius)

        # Clip to widget
        painter.setClipRect(QRectF(1, 1, self.w - 2, self.h - 2))

        # Line number gutter
        gutter_w = self._gutter_width()
        if self.line_numbers and gutter_w > 0:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(theme.surface_hover)
            painter.drawRect(QRectF(0, 0, gutter_w, self.h))

            painter.setPen(QPen(theme.border, 0.5))
            painter.drawLine(QPointF(gutter_w, 0), QPointF(gutter_w, self.h))

            painter.setPen(theme.fg_muted)
            font = painter.font()
            old_size = font.pointSizeF()
            font.setPointSizeF(max(8.0, old_size - 1.0))
            painter.setFont(font)
            for i in range(len(self._lines)):
                ly = self.PAD_Y + i * self.LINE_H - self._scroll_y
                if ly + self.LINE_H < 0 or ly > self.h:
                    continue
                painter.drawText(
                    QRectF(2, ly, gutter_w - 6, self.LINE_H),
                    Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                    str(i + 1),
                )
            font.setPointSizeF(old_size)
            painter.setFont(font)

        # Clip to text area
        text_x0 = self._text_origin_x()
        painter.setClipRect(QRectF(text_x0 - 2, 1, self.w - text_x0, self.h - 2))

        # Selection highlight
        if self.editing and self.has_selection:
            self._draw_selection(painter, ctx)

        # Text lines
        painter.setPen(theme.fg)
        for i, line_text in enumerate(self._lines):
            ly = self.PAD_Y + i * self.LINE_H - self._scroll_y
            if ly + self.LINE_H < 0:
                continue
            if ly > self.h:
                break
            lx = text_x0 - self._scroll_x
            painter.drawText(
                QPointF(lx, ly + self.LINE_H * 0.78),  # baseline offset
                line_text,
            )

        # Placeholder
        if not self.buffer and not self.editing and self.placeholder:
            painter.setPen(theme.fg_muted)
            painter.drawText(
                QPointF(text_x0, self.PAD_Y + self.LINE_H * 0.78),
                self.placeholder,
            )

        # Caret
        if self.editing and ctx.cursor_blink():
            cp = self._pos_to_local(self.caret)
            painter.setPen(QPen(theme.fg, 1.5))
            painter.drawLine(
                QPointF(cp.x(), cp.y() + 2),
                QPointF(cp.x(), cp.y() + self.LINE_H - 2),
            )

        # Scrollbar
        if self._content_height() > self.h:
            self._draw_scrollbar(painter, ctx)

        painter.restore()

    def _draw_selection(self, painter: QPainter, ctx: ZContext) -> None:
        lo, hi = self.selection_range
        lo_line, lo_col = self._pos_to_line_col(lo)
        hi_line, hi_col = self._pos_to_line_col(hi)
        sel_color = QColor(ctx.theme.accent)
        sel_color.setAlpha(60)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(sel_color)
        text_x0 = self._text_origin_x()

        for line_idx in range(lo_line, hi_line + 1):
            if line_idx >= len(self._lines):
                break
            ly = self.PAD_Y + line_idx * self.LINE_H - self._scroll_y
            line_text = self._lines[line_idx]

            if line_idx == lo_line and line_idx == hi_line:
                # Single line selection
                x1 = text_x0 + self._char_x(line_text, lo_col)
                x2 = text_x0 + self._char_x(line_text, hi_col)
            elif line_idx == lo_line:
                x1 = text_x0 + self._char_x(line_text, lo_col)
                x2 = text_x0 + self._char_x(line_text, len(line_text)) + 6
            elif line_idx == hi_line:
                x1 = text_x0
                x2 = text_x0 + self._char_x(line_text, hi_col)
            else:
                x1 = text_x0
                x2 = text_x0 + self._char_x(line_text, len(line_text)) + 6

            painter.drawRect(QRectF(x1 - self._scroll_x, ly, x2 - x1, self.LINE_H))

    def _char_x(self, line_text: str, col: int) -> float:
        if self._metrics is not None:
            return self._metrics.horizontalAdvance(line_text[:col])
        return col * 7.5

    def _draw_scrollbar(self, painter: QPainter, ctx: ZContext) -> None:
        bar_w = 5.0
        track_h = self.h - 4
        content_h = self._content_height()
        ratio = min(1.0, self.h / max(1.0, content_h))
        thumb_h = max(16.0, track_h * ratio)
        scroll_ratio = self._scroll_y / max(1.0, self._max_scroll_y()) if self._max_scroll_y() > 0 else 0.0
        thumb_y = 2 + scroll_ratio * (track_h - thumb_h)

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(0, 0, 0, 40))
        painter.drawRoundedRect(QRectF(self.w - bar_w - 2, thumb_y, bar_w, thumb_h), 2.5, 2.5)

    # ── Input handling ────────────────────────────────────────────

    def mouse_pressed(self, event: ZPointer) -> bool:
        if not self.enabled or not self.hit(event.x, event.y):
            return False
        if self.dispatcher is not None:
            self.dispatcher.set_focus(self)
        lp = self.screen_to_local(event.x, event.y)
        pos = self._local_to_pos(lp.x(), lp.y())
        if event.modifiers & Qt.KeyboardModifier.ShiftModifier:
            self.caret = pos
        else:
            self.caret = pos
            self.anchor = pos
        self._dragging = True
        self._ensure_caret_visible()
        return True

    def mouse_dragged(self, event: ZPointer) -> bool:
        if not self._dragging:
            return False
        lp = self.screen_to_local(event.x, event.y)
        self.caret = self._local_to_pos(lp.x(), lp.y())
        self._ensure_caret_visible()
        return True

    def mouse_released(self, event: ZPointer) -> bool:
        was = self._dragging
        self._dragging = False
        return was

    def mouse_wheel(self, delta: float, event: ZPointer | None = None) -> bool:
        step = self.LINE_H * 3
        if delta > 0:
            self._scroll_y = max(0.0, self._scroll_y - step)
        else:
            self._scroll_y = min(self._max_scroll_y(), self._scroll_y + step)
        return True

    def key_pressed(self, event: ZKey) -> None:
        if not self.editing:
            return
        cmd = event.is_command_key()
        shift = event.is_shift()
        key = event.key

        # ── Clipboard / undo shortcuts ──
        if cmd:
            if key == Qt.Key.Key_C:
                self._copy()
                return
            if key == Qt.Key.Key_X:
                self._cut()
                return
            if key == Qt.Key.Key_V:
                self._paste()
                return
            if key == Qt.Key.Key_A:
                self.select_all()
                return
            if key == Qt.Key.Key_Z:
                if shift:
                    self._redo()
                else:
                    self._undo()
                return

        # ── Navigation ──
        if key == Qt.Key.Key_Left:
            target = _word_boundary_left(self.buffer, self.caret) if cmd else max(0, self.caret - 1)
            if shift:
                self.caret = target
            else:
                if self.has_selection:
                    self.caret = self.anchor = min(self.caret, self.anchor)
                else:
                    self.caret = self.anchor = target
            self._ensure_caret_visible()
            return
        if key == Qt.Key.Key_Right:
            target = _word_boundary_right(self.buffer, self.caret) if cmd else min(len(self.buffer), self.caret + 1)
            if shift:
                self.caret = target
            else:
                if self.has_selection:
                    self.caret = self.anchor = max(self.caret, self.anchor)
                else:
                    self.caret = self.anchor = target
            self._ensure_caret_visible()
            return
        if key == Qt.Key.Key_Up:
            line_idx, col = self._pos_to_line_col(self.caret)
            if line_idx > 0:
                target = self._line_col_to_pos(line_idx - 1, col)
            else:
                target = 0
            if shift:
                self.caret = target
            else:
                self.caret = self.anchor = target
            self._ensure_caret_visible()
            return
        if key == Qt.Key.Key_Down:
            line_idx, col = self._pos_to_line_col(self.caret)
            if line_idx < len(self._lines) - 1:
                target = self._line_col_to_pos(line_idx + 1, col)
            else:
                target = len(self.buffer)
            if shift:
                self.caret = target
            else:
                self.caret = self.anchor = target
            self._ensure_caret_visible()
            return
        if key == Qt.Key.Key_Home:
            line_idx, _ = self._pos_to_line_col(self.caret)
            target = self._line_offsets[line_idx]
            if shift:
                self.caret = target
            else:
                self.caret = self.anchor = target
            self._ensure_caret_visible()
            return
        if key == Qt.Key.Key_End:
            line_idx, _ = self._pos_to_line_col(self.caret)
            target = self._line_offsets[line_idx] + len(self._lines[line_idx])
            if shift:
                self.caret = target
            else:
                self.caret = self.anchor = target
            self._ensure_caret_visible()
            return

        # ── Editing keys ──
        if key == Qt.Key.Key_Backspace:
            self._backspace()
            self._ensure_caret_visible()
            return
        if key == Qt.Key.Key_Delete:
            self._delete()
            self._ensure_caret_visible()
            return
        if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self._insert("\n")
            self._ensure_caret_visible()
            return
        if key == Qt.Key.Key_Tab:
            self._insert(" " * self.TAB_SPACES)
            self._ensure_caret_visible()
            return
        if key == Qt.Key.Key_Escape:
            if self.dispatcher is not None:
                self.dispatcher.clear_focus()
            return

        # ── Printable text ──
        if event.text and event.text.isprintable() and not cmd:
            self._insert(event.text)
            self._ensure_caret_visible()

    def clips_pointer_to_bounds(self) -> bool:
        return True
