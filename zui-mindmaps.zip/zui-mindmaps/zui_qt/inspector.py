from __future__ import annotations

from html import escape
from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDockWidget, QTextBrowser, QWidget

from .core import ZNode, Zui

try:
    from PySide6.QtWebEngineWidgets import QWebEngineView
except Exception:  # pragma: no cover - optional dependency at runtime
    QWebEngineView = None


class SceneInspectorDock(QDockWidget):
    def __init__(self, zui: Zui, parent: QWidget | None = None) -> None:
        super().__init__("Scene Inspector", parent)
        self.zui = zui
        self.hovered: Optional[ZNode] = None
        self.focused: Optional[ZNode] = None
        self.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea)

        if QWebEngineView is not None:
            self.viewer = QWebEngineView(self)
            self._set_html = self.viewer.setHtml
        else:
            self.viewer = QTextBrowser(self)
            self._set_html = self.viewer.setHtml

        self.setWidget(self.viewer)
        self.refresh()

    def set_hovered(self, node: Optional[ZNode]) -> None:
        self.hovered = node
        self.refresh()

    def set_focused(self, node: Optional[ZNode]) -> None:
        self.focused = node
        self.refresh()

    def refresh(self) -> None:
        self._set_html(self._render_html())

    def _render_html(self) -> str:
        def render_node(node: ZNode, depth: int = 0) -> str:
            label = escape(node.__class__.__name__)
            ident = escape(node.id) if node.id else "—"
            selected = ""
            if node is self.focused:
                selected += " <span class='pill focus'>focus</span>"
            if node is self.hovered:
                selected += " <span class='pill hover'>hover</span>"
            header = (
                f"<div class='node' style='margin-left:{depth * 14}px'>"
                f"<div><strong>{label}</strong>{selected}</div>"
                f"<div class='meta'>id={ident} bounds=({node.x:.0f}, {node.y:.0f}, {node.w:.0f}, {node.h:.0f}) visible={node.visible} enabled={node.enabled}</div>"
                f"</div>"
            )
            children = "".join(render_node(child, depth + 1) for child in node.children)
            return header + children

        roots_html = "".join(render_node(root) for root in self.zui.dispatcher.roots) or "<p>No roots.</p>"
        focused_html = self._node_detail(self.focused, "Focused")
        hovered_html = self._node_detail(self.hovered, "Hovered")
        return f"""
        <html>
        <head>
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; padding: 12px; background: #1e1e1e; color: #efefef; }}
            h2 {{ margin: 0 0 8px 0; font-size: 15px; }}
            h3 {{ margin: 16px 0 6px 0; font-size: 13px; color: #9fd4ff; }}
            .meta {{ color: #b7b7b7; font-size: 12px; }}
            .node {{ padding: 4px 0; border-bottom: 1px solid rgba(255,255,255,0.06); }}
            .pill {{ display: inline-block; padding: 1px 6px; border-radius: 999px; font-size: 11px; margin-left: 6px; }}
            .focus {{ background: #2b6fff; color: white; }}
            .hover {{ background: #2fa36b; color: white; }}
            code {{ color: #ffd479; }}
        </style>
        </head>
        <body>
            <h2>Retained Scene Graph</h2>
            {focused_html}
            {hovered_html}
            <h3>Roots</h3>
            {roots_html}
        </body>
        </html>
        """

    def _node_detail(self, node: Optional[ZNode], title: str) -> str:
        if node is None:
            return f"<h3>{escape(title)}</h3><div class='meta'>None</div>"
        return (
            f"<h3>{escape(title)}</h3>"
            f"<div><strong>{escape(node.__class__.__name__)}</strong></div>"
            f"<div class='meta'>id={escape(node.id) if node.id else '—'}</div>"
            f"<div class='meta'>position=({node.x:.1f}, {node.y:.1f}) size=({node.w:.1f}, {node.h:.1f}) scale=({node.sx:.2f}, {node.sy:.2f})</div>"
        )
