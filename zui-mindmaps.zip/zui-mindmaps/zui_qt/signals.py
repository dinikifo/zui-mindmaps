"""Lightweight signal/slot system for ZUI.

Any object can mix in ``ZSignalMixin`` to gain the ability to emit named
signals that observers can subscribe to.  This is intentionally simpler
than Qt's signal/slot mechanism — no compile-time declarations, no
thread marshalling, just plain Python callables.

Usage
-----
    class Counter(ZNode, ZSignalMixin):
        def __init__(self):
            ZNode.__init__(self)
            ZSignalMixin.__init__(self)
            self._count = 0

        @property
        def count(self):
            return self._count

        @count.setter
        def count(self, value):
            old = self._count
            self._count = value
            self.notify("count_changed", value=value, old=old)

    counter = Counter()
    counter.connect("count_changed", lambda value, old: print(f"{old} → {value}"))
    counter.count = 5  # prints "0 → 5"
"""

from __future__ import annotations

from typing import Any, Callable, Optional


class ZSignalMixin:
    """Mixin that adds signal emission and subscription to any class."""

    def __init__(self) -> None:
        self._z_listeners: dict[str, list[Callable]] = {}

    def connect(self, signal_name: str, callback: Callable) -> Callable:
        """Subscribe *callback* to *signal_name*.  Returns the callback
        (convenient for use as a decorator)."""
        self._z_listeners.setdefault(signal_name, []).append(callback)
        return callback

    def disconnect(self, signal_name: str, callback: Callable | None = None) -> None:
        """Remove one or all callbacks for *signal_name*."""
        if callback is None:
            self._z_listeners.pop(signal_name, None)
        elif signal_name in self._z_listeners:
            self._z_listeners[signal_name] = [
                cb for cb in self._z_listeners[signal_name] if cb is not callback
            ]

    def notify(self, signal_name: str, **kwargs: Any) -> None:
        """Emit *signal_name*, calling all registered callbacks with **kwargs."""
        for cb in self._z_listeners.get(signal_name, []):
            try:
                cb(**kwargs)
            except Exception:
                pass  # don't let a bad listener crash the emitter

    def has_listeners(self, signal_name: str) -> bool:
        return bool(self._z_listeners.get(signal_name))


class ZObservableValue:
    """A single observable value that emits ``changed`` when set.

    Usage::

        name = ZObservableValue("Alice")
        name.on_changed(lambda value, old: print(f"Now: {value}"))
        name.set("Bob")  # prints "Now: Bob"
        print(name.get())  # "Bob"
    """

    def __init__(self, initial: Any = None) -> None:
        self._value = initial
        self._callbacks: list[Callable] = []

    def get(self) -> Any:
        return self._value

    def set(self, value: Any) -> None:
        if value == self._value:
            return
        old = self._value
        self._value = value
        for cb in self._callbacks:
            try:
                cb(value=value, old=old)
            except Exception:
                pass

    def on_changed(self, callback: Callable) -> Callable:
        """Register a callback: ``fn(value=..., old=...)``."""
        self._callbacks.append(callback)
        return callback

    def off_changed(self, callback: Callable | None = None) -> None:
        if callback is None:
            self._callbacks.clear()
        else:
            self._callbacks = [cb for cb in self._callbacks if cb is not callback]

    def __repr__(self) -> str:
        return f"ZObservableValue({self._value!r})"


class ZObservableList:
    """An observable list that notifies on mutations.

    Signals: ``item_added(index, item)``, ``item_removed(index, item)``,
    ``changed()`` (catch-all after any mutation).
    """

    def __init__(self, initial: list | None = None) -> None:
        self._items: list = list(initial or [])
        self._on_added: list[Callable] = []
        self._on_removed: list[Callable] = []
        self._on_changed: list[Callable] = []

    def __len__(self) -> int:
        return len(self._items)

    def __iter__(self):
        return iter(self._items)

    def __getitem__(self, index: int) -> Any:
        return self._items[index]

    @property
    def items(self) -> list:
        return list(self._items)

    def append(self, item: Any) -> None:
        idx = len(self._items)
        self._items.append(item)
        self._fire_added(idx, item)
        self._fire_changed()

    def insert(self, index: int, item: Any) -> None:
        self._items.insert(index, item)
        self._fire_added(index, item)
        self._fire_changed()

    def remove(self, item: Any) -> None:
        idx = self._items.index(item)
        self._items.pop(idx)
        self._fire_removed(idx, item)
        self._fire_changed()

    def pop(self, index: int = -1) -> Any:
        item = self._items.pop(index)
        real_idx = index if index >= 0 else len(self._items)
        self._fire_removed(real_idx, item)
        self._fire_changed()
        return item

    def clear(self) -> None:
        old = list(self._items)
        self._items.clear()
        for i, item in reversed(list(enumerate(old))):
            self._fire_removed(i, item)
        self._fire_changed()

    def on_added(self, callback: Callable) -> Callable:
        """``fn(index=..., item=...)``"""
        self._on_added.append(callback)
        return callback

    def on_removed(self, callback: Callable) -> Callable:
        """``fn(index=..., item=...)``"""
        self._on_removed.append(callback)
        return callback

    def on_changed(self, callback: Callable) -> Callable:
        """``fn()`` — fires after any mutation."""
        self._on_changed.append(callback)
        return callback

    def _fire_added(self, index: int, item: Any) -> None:
        for cb in self._on_added:
            try:
                cb(index=index, item=item)
            except Exception:
                pass

    def _fire_removed(self, index: int, item: Any) -> None:
        for cb in self._on_removed:
            try:
                cb(index=index, item=item)
            except Exception:
                pass

    def _fire_changed(self) -> None:
        for cb in self._on_changed:
            try:
                cb()
            except Exception:
                pass
