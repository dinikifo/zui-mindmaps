from __future__ import annotations

from dataclasses import dataclass
from time import monotonic
from typing import Callable, Iterable, Optional

from PySide6.QtCore import QPointF, QRectF, QSizeF
from PySide6.QtGui import QPainter

from .camera import ZCamera
from .events import ZEventHandler, ZKey, ZPointer
from .theme import ZStyle, ZTheme


@dataclass(slots=True)
class ClipRect:
    x: float
    y: float
    w: float
    h: float


class ZContext:
    def __init__(self, theme: ZTheme) -> None:
        self.theme = theme
        self.camera: Optional[ZCamera] = None
        self.frame_count = 0
        self.millis = 0
        self.delta_seconds = 0.0
        self.active_clip: Optional[ClipRect] = None
        self._last_time = monotonic()
        self.canvas_size = QSizeF(0.0, 0.0)

    def update(self, width: float, height: float) -> None:
        now = monotonic()
        self.delta_seconds = max(0.0, now - self._last_time)
        self._last_time = now
        self.frame_count += 1
        self.millis = int(now * 1000)
        self.active_clip = None
        self.canvas_size = QSizeF(width, height)

    def cursor_blink(self) -> bool:
        return (self.millis // 500) % 2 == 0


class ZNode:
    def __init__(self) -> None:
        self.parent: Optional["ZNode"] = None
        self.children: list[ZNode] = []
        self.x = 0.0
        self.y = 0.0
        self.sx = 1.0
        self.sy = 1.0
        self.w = 0.0
        self.h = 0.0
        self.visible = True
        self.enabled = True
        self.style = ZStyle()
        self.id = ""

    def add_child(self, child: "ZNode") -> None:
        if child is None:
            return
        if child.parent is self and child in self.children:
            return
        if child.parent is not None and child.parent is not self:
            child.parent.remove_child(child)
        child.parent = self
        self.children.append(child)

    def remove_child(self, child: "ZNode") -> None:
        if child in self.children:
            self.children.remove(child)
        if child is not None and child.parent is self:
            child.parent = None

    def clear_children(self) -> None:
        for child in list(self.children):
            self.remove_child(child)

    def bring_to_front(self) -> None:
        if self.parent is None:
            return
        if self in self.parent.children:
            self.parent.children.remove(self)
            self.parent.children.append(self)

    def set_position(self, x: float, y: float) -> None:
        self.x, self.y = x, y

    def set_size(self, w: float, h: float) -> None:
        self.w, self.h = w, h

    def set_bounds(self, x: float, y: float, w: float, h: float) -> None:
        self.x, self.y, self.w, self.h = x, y, w, h

    def set_scale(self, sx: float, sy: Optional[float] = None) -> None:
        self.sx = sx
        self.sy = sx if sy is None else sy

    def global_transform(self) -> tuple[float, float, float, float]:
        if self.parent is None:
            return (self.x, self.y, self.sx, self.sy)
        px, py, psx, psy = self.parent.global_transform()
        return (px + self.x * psx, py + self.y * psy, psx * self.sx, psy * self.sy)

    def screen_to_local(self, screen_x: float, screen_y: float) -> QPointF:
        gx, gy, gsx, gsy = self.global_transform()
        sx = gsx if gsx else 1.0
        sy = gsy if gsy else 1.0
        return QPointF((screen_x - gx) / sx, (screen_y - gy) / sy)

    def local_to_screen(self, lx: float, ly: float) -> QPointF:
        gx, gy, gsx, gsy = self.global_transform()
        return QPointF(gx + lx * gsx, gy + ly * gsy)

    def hit(self, screen_x: float, screen_y: float) -> bool:
        lp = self.screen_to_local(screen_x, screen_y)
        return 0.0 <= lp.x() <= self.w and 0.0 <= lp.y() <= self.h

    def draw(self, painter: QPainter, ctx: ZContext) -> None:
        if not self.visible:
            return
        painter.save()
        painter.translate(self.x, self.y)
        painter.scale(self.sx, self.sy)
        self.draw_self(painter, ctx)
        for child in list(self.children):
            child.draw(painter, ctx)
        painter.restore()

    def draw_self(self, painter: QPainter, ctx: ZContext) -> None:
        pass

    def mouse_pressed(self, event: ZPointer) -> bool:
        return False

    def mouse_dragged(self, event: ZPointer) -> bool:
        return False

    def mouse_released(self, event: ZPointer) -> bool:
        return False

    def mouse_moved(self, event: ZPointer) -> bool:
        return False

    def mouse_wheel(self, delta: float, event: ZPointer | None = None) -> bool:
        return False

    def key_typed(self, event: ZKey) -> None:
        pass

    def key_pressed(self, event: ZKey) -> None:
        pass

    def clips_pointer_to_bounds(self) -> bool:
        return False

    def on_focus(self) -> None:
        pass

    def on_blur(self) -> None:
        pass


class ZContainer(ZNode):
    def __init__(self, x: float, y: float, w: float, h: float, *, clips: bool = True) -> None:
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.clips = clips

    def draw(self, painter: QPainter, ctx: ZContext) -> None:
        if not self.visible:
            return
        painter.save()
        painter.translate(self.x, self.y)
        painter.scale(self.sx, self.sy)
        self.draw_self(painter, ctx)
        if self.clips:
            painter.setClipRect(QRectF(0.0, 0.0, self.w, self.h), Qt.ClipOperation.IntersectClip)
        for child in list(self.children):
            child.draw(painter, ctx)
        painter.restore()

    def clips_pointer_to_bounds(self) -> bool:
        return self.clips

    def add(self, child: ZNode) -> ZNode:
        self.add_child(child)
        return child


# Late import to keep the top section readable.
from PySide6.QtCore import Qt  # noqa: E402


class ZEventDispatcher:
    def __init__(self) -> None:
        self.roots: list[ZNode] = []
        self.captured_node: Optional[ZNode] = None
        self.focused_node: Optional[ZNode] = None
        self.hovered_node: Optional[ZNode] = None
        self.fallback: Optional[ZEventHandler] = None
        self._popup: Optional[ZNode] = None

    def add(self, node: ZNode) -> None:
        if node is None or node in self.roots:
            return
        self.roots.append(node)

    def remove(self, node: ZNode) -> None:
        if node in self.roots:
            self.roots.remove(node)
        if self.captured_node is node:
            self.captured_node = None
        if self.focused_node is node:
            self.focused_node = None
        if self.hovered_node is node:
            self.hovered_node = None
        if self._popup is node:
            self._popup = None

    def set_fallback(self, handler: Optional[ZEventHandler]) -> None:
        self.fallback = handler

    # ── Popup layer ───────────────────────────────────────────────

    def show_popup(self, node: ZNode) -> None:
        """Set *node* as the active popup overlay.  It gets first shot
        at all events.  A press outside it calls dismiss_popup()."""
        if self._popup is not None and self._popup is not node:
            self.dismiss_popup()
        self._popup = node

    def dismiss_popup(self) -> None:
        """Close the active popup, calling its on_blur().
        Clears focus and hover if they point inside the popup."""
        if self._popup is not None:
            popup = self._popup
            self._popup = None
            self._clear_popup_refs(popup)
            popup.on_blur()

    def release_popup(self, node: ZNode) -> None:
        """Unregister *node* as the active popup WITHOUT calling on_blur().
        Clears focus and hover if they point inside the closing popup."""
        if self._popup is node:
            self._popup = None
            self._clear_popup_refs(node)

    def _clear_popup_refs(self, popup: ZNode) -> None:
        """Clear focused_node and hovered_node if they belong to *popup*.

        If the focused node is a *descendant* of the popup, blur it.
        If the focused node is the popup root itself, just clear the
        pointer — the caller (dismiss_popup) handles the root's on_blur.
        """
        if self.focused_node is not None and self._is_descendant_or_self(self.focused_node, popup):
            if self.focused_node is not popup:
                self.focused_node.on_blur()
            self.focused_node = None
        if self.hovered_node is not None and self._is_descendant_or_self(self.hovered_node, popup):
            self.hovered_node = None

    @staticmethod
    def _is_descendant_or_self(node: ZNode, ancestor: ZNode) -> bool:
        current: Optional[ZNode] = node
        while current is not None:
            if current is ancestor:
                return True
            current = current.parent
        return False

    @property
    def active_popup(self) -> Optional[ZNode]:
        return self._popup

    # ── Drawing ───────────────────────────────────────────────────

    def draw(self, painter: QPainter, ctx: ZContext) -> None:
        popup = self._popup
        if popup is not None and popup.visible:
            popup.visible = False
            try:
                for node in list(self.roots):
                    node.draw(painter, ctx)
            finally:
                popup.visible = True
            popup.draw(painter, ctx)
        else:
            for node in list(self.roots):
                node.draw(painter, ctx)

    def set_focus(self, node: Optional[ZNode]) -> None:
        if self.focused_node is node:
            return
        if self.focused_node is not None:
            self.focused_node.on_blur()
        self.focused_node = node
        if self.focused_node is not None:
            self.focused_node.on_focus()

    def clear_focus(self) -> None:
        self.set_focus(None)

    def pick_deepest(self, sx: float, sy: float) -> Optional[ZNode]:
        if self._popup is not None and self._popup.visible:
            result = self._pick_recursive(self._popup, sx, sy)
            if result is not None:
                return result
        for node in reversed(self.roots):
            result = self._pick_recursive(node, sx, sy)
            if result is not None:
                return result
        return None

    def _pick_recursive(self, node: ZNode, sx: float, sy: float) -> Optional[ZNode]:
        if not node.visible or not node.enabled:
            return None
        inside = node.hit(sx, sy)
        if node.clips_pointer_to_bounds() and not inside:
            return None
        for child in reversed(node.children):
            result = self._pick_recursive(child, sx, sy)
            if result is not None:
                return result
        return node if inside else None

    def _move_root_to_front(self, node: Optional[ZNode]) -> None:
        if node is None:
            return
        root = node
        while root.parent is not None:
            root = root.parent
        if root in self.roots and self.roots[-1] is not root:
            self.roots.remove(root)
            self.roots.append(root)

    def _bubble_pressed(self, node: Optional[ZNode], event: ZPointer) -> Optional[ZNode]:
        current = node
        while current is not None:
            if current.mouse_pressed(event):
                return current
            current = current.parent
        return None

    def mouse_pressed(self, event: ZPointer) -> None:
        # If a popup is active, check whether the press lands inside it.
        # Use pick_deepest (which checks popup first) so composite popups
        # with child controls get proper pick→bubble behavior.
        if self._popup is not None:
            picked = self.pick_deepest(event.x, event.y)
            if picked is not None and self._is_inside_popup(picked):
                consumer = self._bubble_pressed(picked, event)
                if consumer is not None:
                    self.captured_node = consumer
                    return
                # Press inside popup but not consumed — still block fallthrough
                return
            else:
                self.dismiss_popup()

        picked = self.pick_deepest(event.x, event.y)
        consumer = self._bubble_pressed(picked, event)
        if consumer is not None:
            self.captured_node = consumer
            self._move_root_to_front(consumer)
            if self.focused_node is not None and self.focused_node is not consumer:
                self.clear_focus()
            return
        self.captured_node = None
        self.clear_focus()
        if self.fallback is not None:
            self.fallback.mouse_pressed(event)

    def _is_inside_popup(self, node: ZNode) -> bool:
        """Return True if *node* is the popup or a descendant of it."""
        return self._popup is not None and self._is_descendant_or_self(node, self._popup)

    def mouse_dragged(self, event: ZPointer) -> None:
        if self.captured_node is not None:
            self.captured_node.mouse_dragged(event)
            return
        if self.fallback is not None:
            self.fallback.mouse_dragged(event)

    def mouse_released(self, event: ZPointer) -> None:
        if self.captured_node is not None:
            self.captured_node.mouse_released(event)
            self.captured_node = None
            return
        if self.fallback is not None:
            self.fallback.mouse_released(event)

    def mouse_moved(self, event: ZPointer) -> None:
        if self._popup is not None and self._popup.visible:
            picked = self.pick_deepest(event.x, event.y)
            if picked is not None and self._is_inside_popup(picked):
                self.hovered_node = picked
                self._bubble_moved(picked, event)
            else:
                # Cursor outside popup — no background hover while popup active
                self.hovered_node = None
                self._popup.mouse_moved(event)
            if self.fallback is not None:
                self.fallback.mouse_moved(event)
            return

        new_hovered = self.pick_deepest(event.x, event.y)
        if new_hovered is not self.hovered_node:
            self.hovered_node = new_hovered
        if self.hovered_node is not None:
            self._bubble_moved(self.hovered_node, event)
        if self.fallback is not None:
            self.fallback.mouse_moved(event)

    def _bubble_moved(self, node: Optional[ZNode], event: ZPointer) -> None:
        current = node
        while current is not None:
            if current.mouse_moved(event):
                return
            current = current.parent

    def mouse_wheel(self, delta: float, event: ZPointer | None = None) -> None:
        if event is not None:
            target = self.pick_deepest(event.x, event.y)
            current = target
            while current is not None:
                if current.mouse_wheel(delta, event):
                    return
                current = current.parent
        if self.fallback is not None:
            self.fallback.mouse_wheel(delta, event)

    def clear_hover(self) -> None:
        """Clear hovered node state (call on mouse-leave)."""
        self.hovered_node = None

    def key_typed(self, event: ZKey) -> None:
        if self._popup is not None:
            # If a node inside the popup has focus, deliver to it.
            # Otherwise deliver to the popup root.
            if self.focused_node is not None and self._is_inside_popup(self.focused_node):
                self.focused_node.key_typed(event)
            else:
                self._popup.key_typed(event)
            return
        if self.focused_node is not None:
            self.focused_node.key_typed(event)
            return
        if self.fallback is not None:
            self.fallback.key_typed(event)

    def key_pressed(self, event: ZKey) -> None:
        if self._popup is not None:
            if self.focused_node is not None and self._is_inside_popup(self.focused_node):
                self.focused_node.key_pressed(event)
            else:
                self._popup.key_pressed(event)
            return
        if self.focused_node is not None:
            self.focused_node.key_pressed(event)
            return
        if self.fallback is not None:
            self.fallback.key_pressed(event)


class Zui:
    def __init__(self, theme: Optional[ZTheme] = None) -> None:
        self.context = ZContext(theme or ZTheme.light())
        self.dispatcher = ZEventDispatcher()

    @property
    def theme(self) -> ZTheme:
        return self.context.theme

    def add(self, node: ZNode) -> None:
        self.dispatcher.add(node)

    def remove(self, node: ZNode) -> None:
        self.dispatcher.remove(node)

    def add_all(self, *nodes: ZNode) -> None:
        for node in nodes:
            if node is not None:
                self.add(node)

    def set_canvas_handler(self, handler: Optional[ZEventHandler]) -> None:
        self.dispatcher.set_fallback(handler)

    def draw(self, painter: QPainter, width: float, height: float) -> None:
        self.context.update(width, height)
        self.dispatcher.draw(painter, self.context)

    def window(self, x: float, y: float, w: float, h: float, title: str) -> "ZWindow":
        from .widgets import ZWindow

        return ZWindow(x, y, w, h, title)

    def button(self, x: float, y: float, w: float, h: float, caption: str, on_click: Optional[Callable[[], None]]) -> "ZButton":
        from .widgets import ZButton

        return ZButton(x, y, w, h, caption, on_click)

    def label(self, x: float, y: float, w: float, h: float, text: str | Callable[[], str]) -> "ZLabel":
        from .widgets import ZLabel

        return ZLabel(x, y, w, h, text)

    def text_field(self, x: float, y: float, w: float, h: float, getter: Callable[[], str], setter: Callable[[str], None]) -> "ZTextField":
        from .widgets import ZTextField

        return ZTextField(x, y, w, h, getter, setter, self.dispatcher)

    def stepper(self, x: float, y: float, w: float, h: float, initial: float, min_val: float, max_val: float, step: float, on_change: Optional[Callable[[float], None]]) -> "ZStepper":
        from .widgets import ZStepper

        return ZStepper(x, y, w, h, initial, min_val, max_val, step, on_change)

    def palette_grid(self, x: float, y: float, w: float, h: float, colors: list, cols: int, on_pick: Optional[Callable[[object], None]]) -> "ZPaletteGrid":
        from .widgets import ZPaletteGrid

        return ZPaletteGrid(x, y, w, h, colors, cols, on_pick)

    def vbox(self, x: float, y: float, w: float, h: float = 0.0, *, spacing: float = 4.0, padding: float = 0.0, clips: bool = True) -> "ZVBox":
        from .layout import ZVBox

        return ZVBox(x, y, w, h, spacing=spacing, padding=padding, clips=clips)

    def hbox(self, x: float, y: float, w: float, h: float = 0.0, *, spacing: float = 4.0, padding: float = 0.0, clips: bool = True) -> "ZHBox":
        from .layout import ZHBox

        return ZHBox(x, y, w, h, spacing=spacing, padding=padding, clips=clips)

    def spacer(self) -> "ZSpacer":
        from .layout import ZSpacer

        return ZSpacer()

    def scroll_view(self, x: float, y: float, w: float, h: float) -> "ZScrollView":
        from .scroll import ZScrollView

        return ZScrollView(x, y, w, h)

    def checkbox(self, x: float, y: float, w: float, h: float, label: str, checked: bool = False, on_changed: Optional[Callable] = None) -> "ZCheckbox":
        from .widgets_ext import ZCheckbox

        return ZCheckbox(x, y, w, h, label, checked, on_changed)

    def toggle(self, x: float, y: float, w: float, h: float, on: bool = False, label: str = "", on_changed: Optional[Callable] = None) -> "ZToggle":
        from .widgets_ext import ZToggle

        return ZToggle(x, y, w, h, on, label, on_changed)

    def slider(self, x: float, y: float, w: float, h: float, value: float = 0.0, min_val: float = 0.0, max_val: float = 1.0, on_changed: Optional[Callable] = None) -> "ZSlider":
        from .widgets_ext import ZSlider

        return ZSlider(x, y, w, h, value, min_val, max_val, on_changed)

    def dropdown(self, x: float, y: float, w: float, h: float, options: list, selected: int = 0, on_changed: Optional[Callable] = None) -> "ZDropdown":
        from .widgets_ext import ZDropdown

        return ZDropdown(x, y, w, h, options, selected, on_changed, dispatcher=self.dispatcher)

    def progress_bar(self, x: float, y: float, w: float, h: float, value: float = 0.0) -> "ZProgressBar":
        from .widgets_ext import ZProgressBar

        return ZProgressBar(x, y, w, h, value)

    def separator(self, x: float, y: float, w: float, h: float, *, horizontal: bool = True) -> "ZSeparator":
        from .widgets_ext import ZSeparator

        return ZSeparator(x, y, w, h, horizontal=horizontal)

    def context_menu(self, items: list) -> "ZContextMenu":
        from .widgets_ext import ZContextMenu

        return ZContextMenu(items, dispatcher=self.dispatcher)

    def tooltip(self) -> "ZTooltip":
        from .widgets_ext import ZTooltip

        return ZTooltip()

    def text_area(
        self,
        x: float,
        y: float,
        w: float,
        h: float,
        text: str = "",
        on_changed: Optional[Callable] = None,
        *,
        line_numbers: bool = False,
        read_only: bool = False,
        placeholder: str = "",
    ) -> "ZTextArea":
        from .textarea import ZTextArea

        return ZTextArea(
            x, y, w, h, text, self.dispatcher, on_changed,
            line_numbers=line_numbers, read_only=read_only, placeholder=placeholder,
        )
