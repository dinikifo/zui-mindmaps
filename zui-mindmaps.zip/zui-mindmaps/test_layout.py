"""Unit tests for the layout system — runs headless (no display needed)."""
from __future__ import annotations

import sys, os

# Ensure we can import the local package
sys.path.insert(0, os.path.dirname(__file__))

from zui_qt.core import ZNode
from zui_qt.layout import ZVBox, ZHBox, ZSpacer


def make_node(w: float, h: float) -> ZNode:
    n = ZNode()
    n.w = w
    n.h = h
    return n


def test_vbox_basic():
    """Three fixed-height children in a VBox with padding and spacing."""
    box = ZVBox(10, 20, 200, 0, spacing=6, padding=8)
    c1 = make_node(0, 24)
    c2 = make_node(0, 24)
    c3 = make_node(0, 24)
    box.add(c1)
    box.add(c2)
    box.add(c3)
    box.do_layout()

    # Auto-height: 8 + 24 + 6 + 24 + 6 + 24 + 8 = 100
    assert box.h == 100.0, f"Expected h=100, got {box.h}"
    # Cross axis (width) stretches to fill: 200 - 8 - 8 = 184
    assert c1.w == 184.0, f"Expected c1.w=184, got {c1.w}"
    assert c2.w == 184.0
    # Positions
    assert c1.y == 8.0, f"Expected c1.y=8, got {c1.y}"
    assert c2.y == 38.0, f"Expected c2.y=38, got {c2.y}"  # 8 + 24 + 6
    assert c3.y == 68.0, f"Expected c3.y=68, got {c3.y}"  # 38 + 24 + 6
    assert c1.x == 8.0
    print("  PASS test_vbox_basic")


def test_hbox_basic():
    """Two fixed-width children in an HBox."""
    box = ZHBox(0, 0, 300, 50, spacing=10, padding=5)
    c1 = make_node(80, 0)
    c2 = make_node(120, 0)
    box.add(c1)
    box.add(c2)
    box.do_layout()

    # Cross axis (height) stretches: 50 - 5 - 5 = 40
    assert c1.h == 40.0, f"Expected c1.h=40, got {c1.h}"
    assert c2.h == 40.0
    # Positions
    assert c1.x == 5.0
    assert c2.x == 95.0  # 5 + 80 + 10
    assert c1.y == 5.0
    print("  PASS test_hbox_basic")


def test_stretch():
    """A stretch child fills remaining space."""
    box = ZVBox(0, 0, 100, 200, spacing=0, padding=0)
    fixed = make_node(0, 30)
    stretchy = make_node(0, 0)
    box.add(fixed)
    box.add(stretchy, stretch=1)
    box.do_layout()

    assert stretchy.h == 170.0, f"Expected stretchy.h=170, got {stretchy.h}"
    assert stretchy.y == 30.0
    print("  PASS test_stretch")


def test_two_stretch():
    """Two stretch children split remaining space proportionally."""
    box = ZVBox(0, 0, 100, 200, spacing=0, padding=0)
    s1 = make_node(0, 0)
    s2 = make_node(0, 0)
    box.add(s1, stretch=1)
    box.add(s2, stretch=3)
    box.do_layout()

    assert abs(s1.h - 50.0) < 0.01, f"Expected s1.h=50, got {s1.h}"
    assert abs(s2.h - 150.0) < 0.01, f"Expected s2.h=150, got {s2.h}"
    print("  PASS test_two_stretch")


def test_spacer():
    """Spacer pushes last child to the bottom."""
    box = ZVBox(0, 0, 100, 200, spacing=0, padding=0)
    top = make_node(0, 30)
    spacer = ZSpacer()
    bottom = make_node(0, 30)
    box.add(top)
    box.add(spacer, stretch=1)
    box.add(bottom)
    box.do_layout()

    assert top.y == 0.0
    assert bottom.y == 170.0, f"Expected bottom.y=170, got {bottom.y}"
    print("  PASS test_spacer")


def test_nested_vbox_in_hbox():
    """A VBox nested inside an HBox auto-sizes."""
    inner = ZVBox(0, 0, 0, 0, spacing=4, padding=4)
    inner.add(make_node(80, 20))
    inner.add(make_node(80, 20))

    outer = ZHBox(0, 0, 300, 0, spacing=10, padding=5)
    left = make_node(100, 50)
    outer.add(left)
    outer.add(inner)
    outer.do_layout()

    # Inner preferred: w = 80 + 4*2 = 88, h = 4 + 20 + 4 + 20 + 4 = 52
    assert inner.h == 52.0, f"Expected inner.h=52, got {inner.h}"
    # inner.w was auto (0), should have been set by preferred_size
    assert inner.w == 88.0, f"Expected inner.w=88, got {inner.w}"
    print("  PASS test_nested_vbox_in_hbox")


def test_preferred_size():
    """preferred_size returns tight-fit dimensions."""
    box = ZVBox(0, 0, 200, 0, spacing=6, padding=10)
    box.add(make_node(0, 24))
    box.add(make_node(0, 24))
    pw, ph = box.preferred_size()
    # h = 10 + 24 + 6 + 24 + 10 = 74
    assert ph == 74.0, f"Expected ph=74, got {ph}"
    print("  PASS test_preferred_size")


def test_fixed_cross():
    """fixed_cross prevents cross-axis stretching."""
    box = ZVBox(0, 0, 200, 100, spacing=0, padding=0)
    c = make_node(60, 30)
    box.add(c, fixed_cross=60)
    box.do_layout()

    assert c.w == 60.0, f"Expected c.w=60, got {c.w}"
    print("  PASS test_fixed_cross")


def test_invisible_child_skipped():
    """Invisible children don't consume space."""
    box = ZVBox(0, 0, 100, 0, spacing=10, padding=0)
    c1 = make_node(0, 20)
    c2 = make_node(0, 20)
    c2.visible = False
    c3 = make_node(0, 20)
    box.add(c1)
    box.add(c2)
    box.add(c3)
    box.do_layout()

    # Only c1 and c3 are visible: 20 + 10 + 20 = 50
    assert box.h == 50.0, f"Expected h=50, got {box.h}"
    assert c3.y == 30.0, f"Expected c3.y=30, got {c3.y}"
    print("  PASS test_invisible_child_skipped")


if __name__ == "__main__":
    print("Running layout tests...")
    test_vbox_basic()
    test_hbox_basic()
    test_stretch()
    test_two_stretch()
    test_spacer()
    test_nested_vbox_in_hbox()
    test_preferred_size()
    test_fixed_cross()
    test_invisible_child_skipped()
    print("\nAll tests passed!")
