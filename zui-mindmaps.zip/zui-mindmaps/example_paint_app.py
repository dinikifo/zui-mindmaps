from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QAction, QColor, QImage, QMouseEvent, QPainter, QPen
from PySide6.QtWidgets import QApplication, QFileDialog, QMainWindow

from zui_qt import SceneInspectorDock, ZCamera, ZCanvas, ZEventHandler, ZKey, ZPointer, ZTheme, Zui


PANEL_W = 192
DOC_W = 800
DOC_H = 560


def color_hex(color: QColor) -> str:
    return color.name(QColor.NameFormat.HexRgb)


class PaintDocument:
    def __init__(self, width: int, height: int) -> None:
        self.width = width
        self.height = height
        self.paint = QImage(width, height, QImage.Format.Format_ARGB32_Premultiplied)
        self.paint.fill(Qt.GlobalColor.white)
        self.undo_stack: list[QImage] = []
        self.redo_stack: list[QImage] = []
        self.push_undo()

    def snapshot(self) -> QImage:
        return self.paint.copy()

    def push_undo(self) -> None:
        self.undo_stack.append(self.snapshot())
        self.redo_stack.clear()
        if len(self.undo_stack) > 30:
            self.undo_stack = self.undo_stack[-30:]

    def undo(self) -> None:
        if len(self.undo_stack) <= 1:
            return
        self.redo_stack.append(self.undo_stack.pop())
        self.paint = self.undo_stack[-1].copy()

    def redo(self) -> None:
        if not self.redo_stack:
            return
        img = self.redo_stack.pop()
        self.undo_stack.append(img.copy())
        self.paint = img.copy()

    def clear(self) -> None:
        self.paint.fill(Qt.GlobalColor.white)
        self.push_undo()

    def load_from(self, path: str) -> None:
        loaded = QImage(path)
        if loaded.isNull():
            return
        canvas = QImage(self.width, self.height, QImage.Format.Format_ARGB32_Premultiplied)
        canvas.fill(Qt.GlobalColor.white)
        p = QPainter(canvas)
        p.drawImage(QRectF(0, 0, self.width, self.height), loaded)
        p.end()
        self.paint = canvas
        self.push_undo()

    def save_to(self, path: str) -> None:
        out = path if path.lower().endswith(".png") else f"{path}.png"
        self.paint.save(out, "PNG")


class PaintTool:
    name = "Tool"
    active = False

    def on_press(self, doc: PaintDocument, x: float, y: float, color: QColor, weight: float) -> None:
        self.active = True

    def on_drag(self, doc: PaintDocument, x: float, y: float, color: QColor, weight: float) -> None:
        pass

    def on_release(self, doc: PaintDocument, x: float, y: float, color: QColor, weight: float) -> None:
        self.active = False

    def on_cancel(self, doc: PaintDocument) -> None:
        self.active = False

    def draw_preview(self, painter: QPainter) -> None:
        pass


class PencilTool(PaintTool):
    name = "Pencil"

    def __init__(self) -> None:
        self.last_point: Optional[QPointF] = None

    def on_press(self, doc: PaintDocument, x: float, y: float, color: QColor, weight: float) -> None:
        super().on_press(doc, x, y, color, weight)
        doc.push_undo()
        self.last_point = QPointF(x, y)

    def on_drag(self, doc: PaintDocument, x: float, y: float, color: QColor, weight: float) -> None:
        if self.last_point is None:
            self.last_point = QPointF(x, y)
        p = QPainter(doc.paint)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(QPen(color, weight, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        cur = QPointF(x, y)
        p.drawLine(self.last_point, cur)
        p.end()
        self.last_point = cur

    def on_release(self, doc: PaintDocument, x: float, y: float, color: QColor, weight: float) -> None:
        self.last_point = None
        super().on_release(doc, x, y, color, weight)


class EraserTool(PencilTool):
    name = "Eraser"

    def on_drag(self, doc: PaintDocument, x: float, y: float, color: QColor, weight: float) -> None:
        super().on_drag(doc, x, y, QColor(Qt.GlobalColor.white), weight * 1.8)


class ShapeTool(PaintTool):
    def __init__(self) -> None:
        self.start = QPointF(0, 0)
        self.end = QPointF(0, 0)

    def on_press(self, doc: PaintDocument, x: float, y: float, color: QColor, weight: float) -> None:
        super().on_press(doc, x, y, color, weight)
        self.start = QPointF(x, y)
        self.end = QPointF(x, y)

    def on_drag(self, doc: PaintDocument, x: float, y: float, color: QColor, weight: float) -> None:
        self.end = QPointF(x, y)

    def on_release(self, doc: PaintDocument, x: float, y: float, color: QColor, weight: float) -> None:
        self.end = QPointF(x, y)
        doc.push_undo()
        p = QPainter(doc.paint)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(QPen(color, weight, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        self.commit_shape(p)
        p.end()
        super().on_release(doc, x, y, color, weight)

    def preview_rect(self) -> QRectF:
        left = min(self.start.x(), self.end.x())
        top = min(self.start.y(), self.end.y())
        right = max(self.start.x(), self.end.x())
        bottom = max(self.start.y(), self.end.y())
        return QRectF(left, top, right - left, bottom - top)

    def draw_preview(self, painter: QPainter) -> None:
        if self.active:
            self.commit_shape(painter)

    def commit_shape(self, painter: QPainter) -> None:
        raise NotImplementedError


class LineTool(ShapeTool):
    name = "Line"

    def commit_shape(self, painter: QPainter) -> None:
        painter.drawLine(self.start, self.end)


class RectTool(ShapeTool):
    name = "Rectangle"

    def commit_shape(self, painter: QPainter) -> None:
        painter.drawRect(self.preview_rect())


class EllipseTool(ShapeTool):
    name = "Ellipse"

    def commit_shape(self, painter: QPainter) -> None:
        painter.drawEllipse(self.preview_rect())


class CanvasHandler(ZEventHandler):
    def __init__(self, window: "PaintWindow") -> None:
        self.window = window

    def mouse_pressed(self, event: ZPointer) -> None:
        cam = self.window.camera
        if not cam.over_viewport(event.x, event.y):
            return
        if event.is_middle() or bool(event.modifiers & Qt.KeyboardModifier.ControlModifier):
            cam.begin_pan(event.x, event.y)
            return
        if event.button == Qt.MouseButton.LeftButton:
            world = cam.screen_to_world(event.x, event.y)
            self.window.current_tool.on_press(
                self.window.doc,
                world.x(),
                world.y(),
                self.window.draw_color,
                self.window.draw_weight,
            )

    def mouse_dragged(self, event: ZPointer) -> None:
        cam = self.window.camera
        if cam.panning:
            cam.update_pan(event.x, event.y)
            return
        if not cam.over_viewport(event.x, event.y):
            return
        world = cam.screen_to_world(event.x, event.y)
        self.window.current_tool.on_drag(
            self.window.doc,
            world.x(),
            world.y(),
            self.window.draw_color,
            self.window.draw_weight,
        )

    def mouse_released(self, event: ZPointer) -> None:
        cam = self.window.camera
        if cam.panning:
            cam.end_pan()
            return
        if not cam.over_viewport(event.x, event.y):
            return
        world = cam.screen_to_world(event.x, event.y)
        self.window.current_tool.on_release(
            self.window.doc,
            world.x(),
            world.y(),
            self.window.draw_color,
            self.window.draw_weight,
        )

    def mouse_moved(self, event: ZPointer) -> None:
        self.window.update_status(event.x, event.y)

    def mouse_wheel(self, delta: float, event: ZPointer | None = None) -> None:
        if event is None:
            return
        self.window.camera.on_mouse_wheel(delta, event.x, event.y)
        self.window.update_status(event.x, event.y)

    def key_pressed(self, event: ZKey) -> None:
        if event.is_command_key() and event.text.lower() == "z":
            self.window.doc.undo()
            return
        if event.is_command_key() and event.text.lower() == "y":
            self.window.doc.redo()
            return
        if event.is_command_key() and event.text.lower() == "s":
            self.window.save_png()
            return
        if event.is_command_key() and event.text.lower() == "o":
            self.window.open_png()
            return
        if event.key == Qt.Key.Key_Equal:
            self.window.camera.zoom_at(self.window.width() / 2.0, self.window.height() / 2.0, 1.2)
        if event.key == Qt.Key.Key_Minus:
            self.window.camera.zoom_at(self.window.width() / 2.0, self.window.height() / 2.0, 1.0 / 1.2)
        if event.key == Qt.Key.Key_0:
            self.window.camera.fit_world(DOC_W, DOC_H, 24)


class PaintWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("ZUI Qt Paint Demo")
        self.resize(1080, 680)

        self.zui = Zui(ZTheme.light())
        self.canvas = ZCanvas(self.zui)
        self.setCentralWidget(self.canvas)

        self.doc = PaintDocument(DOC_W, DOC_H)
        self.draw_color = QColor(0, 0, 0)
        self.draw_weight = 2.0
        self.save_name = "my_drawing.png"

        self.pencil_tool = PencilTool()
        self.line_tool = LineTool()
        self.rect_tool = RectTool()
        self.ellipse_tool = EllipseTool()
        self.eraser_tool = EraserTool()
        self.current_tool: PaintTool = self.pencil_tool

        self.camera = ZCamera(PANEL_W + 12, 12, self.width() - PANEL_W - 24, self.height() - 24)
        self.camera.fit_world(DOC_W, DOC_H, 24)
        self.zui.context.camera = self.camera
        self.zui.set_canvas_handler(CanvasHandler(self))

        self._build_scene()

        self.inspector = SceneInspectorDock(self.zui, self)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.inspector)
        self.canvas.hoveredNodeChanged.connect(self.inspector.set_hovered)
        self.canvas.focusedNodeChanged.connect(self.inspector.set_focused)

        self._build_menu()

        self.canvas.set_world_renderer(self.draw_world)
        self.canvas.set_continuous(True)  # live brush cursor
        self.statusBar().showMessage("Ready")

    def resizeEvent(self, event) -> None:  # type: ignore[override]
        super().resizeEvent(event)
        self.camera.set_viewport(PANEL_W + 12, 12, self.width() - PANEL_W - 36, self.height() - 32)

    def _build_menu(self) -> None:
        file_menu = self.menuBar().addMenu("&File")
        open_action = QAction("Open PNG", self)
        open_action.triggered.connect(self.open_png)
        save_action = QAction("Save PNG", self)
        save_action.triggered.connect(self.save_png)
        file_menu.addAction(open_action)
        file_menu.addAction(save_action)

        view_menu = self.menuBar().addMenu("&View")
        self.inspector_action = QAction("Toggle Inspector", self, checkable=True, checked=self.inspector.isVisible())
        self.inspector_action.toggled.connect(self.inspector.setVisible)
        self.inspector.visibilityChanged.connect(self.inspector_action.setChecked)
        view_menu.addAction(self.inspector_action)

    def _build_scene(self) -> None:
        z = self.zui
        tool_win = z.window(8, 12, PANEL_W - 16, 230, "Tools")
        tool_win.add(z.label(8, 6, 160, 18, "Select Tool"))
        tool_win.add(z.button(8, 30, 160, 24, "Pencil", lambda: self.select_tool(self.pencil_tool)))
        tool_win.add(z.button(8, 58, 160, 24, "Line", lambda: self.select_tool(self.line_tool)))
        tool_win.add(z.button(8, 86, 160, 24, "Rectangle", lambda: self.select_tool(self.rect_tool)))
        tool_win.add(z.button(8, 114, 160, 24, "Ellipse", lambda: self.select_tool(self.ellipse_tool)))
        tool_win.add(z.button(8, 142, 160, 24, "Eraser", lambda: self.select_tool(self.eraser_tool)))
        tool_win.add(z.button(8, 176, 76, 24, "Undo", self.doc.undo))
        tool_win.add(z.button(92, 176, 76, 24, "Redo", self.doc.redo))
        z.add(tool_win)

        color_win = z.window(8, 252, PANEL_W - 16, 176, "Colors")
        color_win.add(z.label(8, 6, 160, 18, "Palette"))
        palette = [
            QColor("#000000"), QColor("#404040"), QColor("#808080"), QColor("#c0c0c0"),
            QColor("#ffffff"), QColor("#ff0000"), QColor("#ff8000"), QColor("#ffd000"),
            QColor("#00a000"), QColor("#00d0ff"), QColor("#0000ff"), QColor("#8000ff"),
            QColor("#ff00d0"), QColor("#ffb0b0"), QColor("#b0ffb0"), QColor("#b0d0ff"),
        ]
        color_win.add(z.palette_grid(8, 28, 160, 72, palette, 4, self.set_draw_color))
        color_win.add(z.label(8, 112, 72, 18, "Weight"))
        color_win.add(z.stepper(88, 108, 80, 28, self.draw_weight, 1, 64, 1, self.set_draw_weight))
        z.add(color_win)

        file_win = z.window(8, 438, PANEL_W - 16, 194, "File")
        file_win.add(z.button(8, 8, 160, 24, "New", self.new_document))
        file_win.add(z.button(8, 36, 160, 24, "Open PNG", self.open_png))
        file_win.add(z.button(8, 64, 160, 24, "Save PNG", self.save_png))
        file_win.add(z.label(8, 98, 44, 18, "Name"))
        file_win.add(z.text_field(8, 120, 160, 26, lambda: self.save_name, self.set_save_name))
        file_win.add(z.button(8, 154, 76, 24, "Fit", lambda: self.camera.fit_world(DOC_W, DOC_H, 24)))
        file_win.add(z.button(92, 154, 76, 24, "1:1", lambda: self.camera.reset(DOC_W, DOC_H)))
        z.add(file_win)

    def select_tool(self, tool: PaintTool) -> None:
        self.current_tool.on_cancel(self.doc)
        self.current_tool = tool
        self.statusBar().showMessage(f"Tool: {tool.name}")

    def set_draw_color(self, color: QColor) -> None:
        self.draw_color = QColor(color)

    def set_draw_weight(self, value: float) -> None:
        self.draw_weight = value

    def set_save_name(self, name: str) -> None:
        self.save_name = name

    def new_document(self) -> None:
        self.doc.clear()

    def open_png(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Open PNG", str(Path.cwd()), "PNG Images (*.png)")
        if path:
            self.doc.load_from(path)

    def save_png(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Save PNG", self.save_name, "PNG Images (*.png)")
        if path:
            self.doc.save_to(path)
            self.save_name = Path(path).name if path.lower().endswith(".png") else f"{Path(path).name}.png"

    def draw_world(self, painter: QPainter, canvas: ZCanvas) -> None:
        cam = self.camera
        painter.save()
        painter.setPen(QPen(QColor(180, 180, 180), 1.0))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(cam.viewport_rect())
        painter.setClipRect(cam.viewport_rect())
        cam.apply_to_painter(painter)

        painter.setPen(QPen(QColor(160, 160, 160), 1.0 / cam.zoom))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(QRectF(-1, -1, DOC_W + 2, DOC_H + 2))
        painter.drawImage(QPointF(0, 0), self.doc.paint)

        painter.setPen(QPen(self.draw_color, self.draw_weight / cam.zoom))
        self.current_tool.draw_preview(painter)

        cam.restore_painter(painter)
        painter.restore()

    def update_status(self, sx: float, sy: float) -> None:
        world = self.camera.screen_to_world(sx, sy)
        self.statusBar().showMessage(
            f"Tool: {self.current_tool.name} | Color: {color_hex(self.draw_color)} | Weight: {self.draw_weight:.0f} | Zoom: {self.camera.zoom * 100:.0f}% | Canvas: ({world.x():.0f}, {world.y():.0f})"
        )


def main() -> int:
    app = QApplication(sys.argv)
    window = PaintWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
