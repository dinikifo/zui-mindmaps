"""Tests for the risky parts of the framework.

Covers: picking/bubbling, scroll hit-testing, popup dismissal,
focus transitions, wheel propagation, and leaveEvent.

Runs headless with QT_QPA_PLATFORM=offscreen.
"""
from __future__ import annotations

import os
import sys

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.dirname(__file__))

from PySide6.QtWidgets import QApplication

app = QApplication.instance() or QApplication([])

from zui_qt.core import ZEventDispatcher, ZNode, Zui
from zui_qt.events import ZKey, ZPointer
from zui_qt.scroll import ZScrollView
from zui_qt.theme import ZTheme
from zui_qt.widgets_ext import ZContextMenu, ZDropdown


# ── Helpers ───────────────────────────────────────────────────────

def ptr(x: float, y: float, **kw) -> ZPointer:
    from PySide6.QtCore import Qt
    return ZPointer(x=x, y=y, button=kw.get("button", Qt.MouseButton.LeftButton),
                    modifiers=kw.get("modifiers", Qt.KeyboardModifier.NoModifier))


class HitNode(ZNode):
    """A node that records which events it received."""
    def __init__(self, x, y, w, h, name=""):
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.id = name
        self.pressed = 0
        self.moved = 0
        self.wheel_count = 0
        self.focused = False
        self.blurred = False

    def mouse_pressed(self, event):
        self.pressed += 1
        return True

    def mouse_moved(self, event):
        self.moved += 1
        return True

    def mouse_wheel(self, delta, event=None):
        self.wheel_count += 1
        return True

    def on_focus(self):
        self.focused = True

    def on_blur(self):
        self.blurred = True


class PassthroughNode(ZNode):
    """Does not consume press — bubbles to parent."""
    def __init__(self, x, y, w, h, name=""):
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.id = name


class WheelPassthrough(ZNode):
    """Has a mouse_wheel override but returns False (does not consume)."""
    def __init__(self, x, y, w, h):
        super().__init__()
        self.set_bounds(x, y, w, h)
        self.wheel_seen = 0

    def mouse_wheel(self, delta, event=None):
        self.wheel_seen += 1
        return False  # explicitly not consumed


# ── 1. Picking and bubbling ───────────────────────────────────────

def test_pick_deepest():
    d = ZEventDispatcher()
    a = HitNode(0, 0, 200, 200, "parent")
    b = HitNode(10, 10, 50, 50, "child")
    a.add_child(b)
    d.add(a)

    picked = d.pick_deepest(25, 25)
    assert picked is b, f"Expected child, got {picked}"
    picked2 = d.pick_deepest(150, 150)
    assert picked2 is a, f"Expected parent, got {picked2}"
    picked3 = d.pick_deepest(300, 300)
    assert picked3 is None
    print("  PASS test_pick_deepest")


def test_bubble_pressed():
    d = ZEventDispatcher()
    parent = HitNode(0, 0, 200, 200, "parent")
    child = PassthroughNode(10, 10, 50, 50, "child")
    parent.add_child(child)
    d.add(parent)

    d.mouse_pressed(ptr(25, 25))
    assert parent.pressed == 1, "Press should bubble to parent"
    assert d.captured_node is parent
    print("  PASS test_bubble_pressed")


def test_mouse_moved_routes_to_hovered():
    d = ZEventDispatcher()
    a = HitNode(0, 0, 100, 100, "A")
    d.add(a)

    d.mouse_moved(ptr(50, 50))
    assert d.hovered_node is a
    assert a.moved >= 1
    print("  PASS test_mouse_moved_routes_to_hovered")


# ── 2. Wheel propagation ─────────────────────────────────────────

def test_wheel_consumed():
    d = ZEventDispatcher()
    node = HitNode(0, 0, 100, 100, "wheel")
    d.add(node)

    d.mouse_wheel(120.0, ptr(50, 50))
    assert node.wheel_count == 1
    print("  PASS test_wheel_consumed")


def test_wheel_bubbles_when_not_consumed():
    d = ZEventDispatcher()
    parent = HitNode(0, 0, 200, 200, "parent")
    child = WheelPassthrough(10, 10, 80, 80)
    parent.add_child(child)
    d.add(parent)

    d.mouse_wheel(120.0, ptr(30, 30))
    assert child.wheel_seen == 1, "Child should see the wheel event"
    assert parent.wheel_count == 1, "Parent should receive bubbled wheel"
    print("  PASS test_wheel_bubbles_when_not_consumed")


def test_wheel_stops_when_consumed():
    d = ZEventDispatcher()
    parent = HitNode(0, 0, 200, 200, "parent")
    child = HitNode(10, 10, 80, 80, "child")  # HitNode returns True
    parent.add_child(child)
    d.add(parent)

    d.mouse_wheel(120.0, ptr(30, 30))
    assert child.wheel_count == 1
    assert parent.wheel_count == 0, "Parent should NOT receive wheel (child consumed it)"
    print("  PASS test_wheel_stops_when_consumed")


# ── 3. Focus transitions ─────────────────────────────────────────

def test_focus_blur_cycle():
    d = ZEventDispatcher()
    a = HitNode(0, 0, 100, 100, "A")
    b = HitNode(120, 0, 100, 100, "B")
    d.add(a)
    d.add(b)

    d.set_focus(a)
    assert a.focused
    assert d.focused_node is a

    d.set_focus(b)
    assert a.blurred, "A should receive on_blur when focus moves to B"
    assert b.focused
    assert d.focused_node is b

    d.clear_focus()
    assert b.blurred
    assert d.focused_node is None
    print("  PASS test_focus_blur_cycle")


def test_press_clears_focus_on_miss():
    d = ZEventDispatcher()
    a = HitNode(0, 0, 100, 100, "A")
    d.add(a)
    d.set_focus(a)

    # Click empty space
    d.mouse_pressed(ptr(500, 500))
    assert a.blurred
    assert d.focused_node is None
    print("  PASS test_press_clears_focus_on_miss")


# ── 4. Popup management ──────────────────────────────────────────

def test_popup_outside_click_dismisses():
    d = ZEventDispatcher()
    bg = HitNode(0, 0, 500, 500, "bg")
    d.add(bg)

    popup = HitNode(100, 100, 80, 80, "popup")
    d.show_popup(popup)
    assert d.active_popup is popup

    # Click outside popup
    d.mouse_pressed(ptr(10, 10))
    assert d.active_popup is None, "Popup should be dismissed"
    assert popup.blurred, "Popup should receive on_blur"
    print("  PASS test_popup_outside_click_dismisses")


def test_popup_inside_click_handled():
    d = ZEventDispatcher()
    popup = HitNode(100, 100, 80, 80, "popup")
    d.show_popup(popup)

    d.mouse_pressed(ptr(130, 130))
    assert popup.pressed == 1
    assert d.active_popup is popup, "Inside click should NOT dismiss"
    print("  PASS test_popup_inside_click_handled")


def test_popup_receives_key_events():
    d = ZEventDispatcher()
    from PySide6.QtCore import Qt

    class KeyPopup(ZNode):
        def __init__(self):
            super().__init__()
            self.set_bounds(0, 0, 100, 100)
            self.key_seen = False
        def key_pressed(self, event):
            self.key_seen = True

    popup = KeyPopup()
    d.show_popup(popup)

    d.key_pressed(ZKey(key=Qt.Key.Key_Escape, text="", modifiers=Qt.KeyboardModifier.NoModifier))
    assert popup.key_seen, "Popup should receive key events"
    print("  PASS test_popup_receives_key_events")


def test_popup_receives_move_events():
    d = ZEventDispatcher()
    popup = HitNode(100, 100, 80, 80, "popup")
    d.show_popup(popup)

    d.mouse_moved(ptr(130, 130))
    assert popup.moved >= 1, "Popup should receive mouse_moved"
    print("  PASS test_popup_receives_move_events")


def test_popup_receives_wheel():
    d = ZEventDispatcher()
    popup = HitNode(100, 100, 80, 80, "popup")
    d.show_popup(popup)

    d.mouse_wheel(120.0, ptr(130, 130))
    assert popup.wheel_count == 1
    print("  PASS test_popup_receives_wheel")


def test_dropdown_popup_lifecycle():
    d = ZEventDispatcher()
    dd = ZDropdown(50, 50, 120, 28, ["A", "B", "C"], dispatcher=d)
    dd.set_bounds(50, 50, 120, 28)
    d.add(dd)

    # Open dropdown
    d.mouse_pressed(ptr(100, 60))
    assert dd.open, "Dropdown should be open"
    assert d.active_popup is dd, "Dropdown should be the active popup"

    # Click outside → dismiss
    d.mouse_pressed(ptr(400, 400))
    assert not dd.open, "Dropdown should be closed"
    assert d.active_popup is None
    print("  PASS test_dropdown_popup_lifecycle")


def test_context_menu_popup_lifecycle():
    d = ZEventDispatcher()
    menu = ZContextMenu([("Cut", lambda: None), ("Paste", lambda: None)], dispatcher=d)

    menu.show(200, 200)
    assert menu.visible
    assert d.active_popup is menu

    # Click outside
    d.mouse_pressed(ptr(10, 10))
    assert not menu.visible, "Menu should be dismissed"
    assert d.active_popup is None
    print("  PASS test_context_menu_popup_lifecycle")


# ── 5. Scroll hit-testing ────────────────────────────────────────

def test_scroll_hit_offset():
    """Scroll offset is reflected in content node position, so the
    scene graph's coordinate chain is consistent with rendering."""
    scroll = ZScrollView(0, 0, 200, 100)
    content = ZNode()
    content.set_size(200, 500)

    child = HitNode(10, 250, 80, 30, "deep_child")
    content.add_child(child)
    scroll.set_content(content)

    # Before scrolling: content.y = 0, child is at y=250 — below viewport
    assert content.y == 0.0

    # Scroll down
    scroll.scroll_y = 230.0
    # Content position should now be -230 (synced with scroll)
    assert content.y == -230.0, f"Expected content.y=-230, got {content.y}"

    # Child's global y = scroll.y + content.y + child.y = 0 + (-230) + 250 = 20
    # That puts it visually at y=20 inside the 100px viewport — visible and hittable
    gx, gy, _, _ = child.global_transform()
    assert 15 < gy < 25, f"Expected child global y≈20, got {gy}"
    print("  PASS test_scroll_hit_offset")


def test_scroll_wheel_consumed():
    d = ZEventDispatcher()
    scroll = ZScrollView(0, 0, 200, 100)
    content = ZNode()
    content.set_size(200, 500)
    scroll.set_content(content)
    d.add(scroll)

    old_scroll = scroll.scroll_y
    d.mouse_wheel(-120.0, ptr(100, 50))
    assert scroll.scroll_y > old_scroll, "Scroll should have moved"
    print("  PASS test_scroll_wheel_consumed")


# ── 6. Clear hover on leave ──────────────────────────────────────

def test_clear_hover():
    d = ZEventDispatcher()
    a = HitNode(0, 0, 100, 100, "A")
    d.add(a)

    d.mouse_moved(ptr(50, 50))
    assert d.hovered_node is a

    d.clear_hover()
    assert d.hovered_node is None
    print("  PASS test_clear_hover")


def test_dropdown_escape_clears_popup():
    from PySide6.QtCore import Qt as _Qt

    d = ZEventDispatcher()
    dd = ZDropdown(50, 50, 120, 28, ["A", "B", "C"], dispatcher=d)
    d.add(dd)

    # Open
    d.mouse_pressed(ptr(100, 60))
    assert dd.open
    assert d.active_popup is dd

    # Escape
    d.key_pressed(ZKey(key=_Qt.Key.Key_Escape, text="", modifiers=_Qt.KeyboardModifier.NoModifier))
    assert not dd.open, "Dropdown should be closed after Escape"
    assert d.active_popup is None, "active_popup should be None after Escape"
    print("  PASS test_dropdown_escape_clears_popup")


def test_popup_not_drawn_twice():
    """When a node is the active popup, it should be drawn exactly once."""
    from PySide6.QtGui import QImage, QPainter
    from zui_qt.core import ZContext
    from zui_qt.theme import ZTheme

    class CountingNode(ZNode):
        def __init__(self):
            super().__init__()
            self.set_bounds(0, 0, 100, 100)
            self.draw_count = 0
        def draw_self(self, painter, ctx):
            self.draw_count += 1

    d = ZEventDispatcher()
    node = CountingNode()
    d.add(node)

    ctx = ZContext(ZTheme.light())
    img = QImage(200, 200, QImage.Format.Format_ARGB32_Premultiplied)
    painter = QPainter(img)

    # Without popup: drawn once in root pass
    node.draw_count = 0
    d.draw(painter, ctx)
    assert node.draw_count == 1, f"Expected 1, got {node.draw_count}"

    # As popup: still drawn exactly once
    d.show_popup(node)
    node.draw_count = 0
    d.draw(painter, ctx)
    assert node.draw_count == 1, f"Expected 1 as popup, got {node.draw_count}"

    painter.end()
    print("  PASS test_popup_not_drawn_twice")


def test_popup_move_not_double_delivered():
    """mouse_moved to popup should be delivered exactly once."""
    d = ZEventDispatcher()
    tracker = HitNode(0, 0, 100, 100, "popup")
    d.show_popup(tracker)

    d.mouse_moved(ptr(50, 50))
    assert tracker.moved == 1, f"Expected 1 move delivery, got {tracker.moved}"
    print("  PASS test_popup_move_not_double_delivered")


def test_scroll_pick_through_dispatcher():
    """End-to-end: dispatcher picks a child inside a scrolled ZScrollView
    at its visual (scrolled) position."""
    d = ZEventDispatcher()
    scroll = ZScrollView(0, 0, 200, 100)
    content = ZNode()
    content.set_size(200, 500)

    # Child at content y=300 — below the 100px viewport
    child = HitNode(10, 300, 80, 30, "scrolled_child")
    content.add_child(child)
    scroll.set_content(content)
    d.add(scroll)

    # Before scrolling: click at screen y=50 should NOT hit the child
    d.mouse_pressed(ptr(50, 50))
    assert child.pressed == 0, "Child should not be hit before scrolling"
    d.mouse_released(ptr(50, 50))

    # Scroll down by 280 so child (at content y=300) appears at screen y≈20
    scroll.scroll_y = 280.0

    # Now click at screen y=30 → content y = 30+280 = 310, inside child (300..330)
    d.mouse_pressed(ptr(50, 30))
    assert child.pressed == 1, f"Child should be hit after scrolling, pressed={child.pressed}"
    print("  PASS test_scroll_pick_through_dispatcher")


def test_composite_popup_move_to_child():
    """mouse_moved inside a composite popup delivers to the deepest child,
    not just the popup root."""
    d = ZEventDispatcher()

    popup = ZNode()
    popup.set_bounds(100, 100, 200, 200)
    popup.visible = True
    child = HitNode(10, 10, 80, 80, "popup_child")
    popup.add_child(child)

    d.show_popup(popup)
    d.mouse_moved(ptr(140, 140))  # inside child (110..190 screen coords via parent offset)

    assert child.moved >= 1, f"Child inside popup should get mouse_moved, got {child.moved}"
    print("  PASS test_composite_popup_move_to_child")


def test_popup_focus_key_routing():
    """When a node inside the popup has focus, key events go to it,
    not to the popup root."""
    from PySide6.QtCore import Qt as _Qt

    d = ZEventDispatcher()

    class KeyTracker(ZNode):
        def __init__(self):
            super().__init__()
            self.set_bounds(0, 0, 80, 30)
            self.keys = []
        def key_pressed(self, event):
            self.keys.append(event.key)

    popup_root = KeyTracker()
    popup_root.set_bounds(100, 100, 200, 200)
    inner_field = KeyTracker()
    inner_field.set_bounds(10, 10, 80, 30)
    popup_root.add_child(inner_field)

    d.show_popup(popup_root)
    d.set_focus(inner_field)

    d.key_pressed(ZKey(key=_Qt.Key.Key_A, text="a", modifiers=_Qt.KeyboardModifier.NoModifier))

    assert len(inner_field.keys) == 1, f"Focused child should get key, got {inner_field.keys}"
    assert len(popup_root.keys) == 0, f"Popup root should NOT get key when child is focused, got {popup_root.keys}"
    print("  PASS test_popup_focus_key_routing")


def test_popup_dismiss_clears_focused_child():
    """When a popup with a focused child is dismissed, focused_node
    should be cleared so keys don't go to a hidden node."""
    d = ZEventDispatcher()
    popup = ZNode()
    popup.set_bounds(100, 100, 200, 200)
    child = HitNode(10, 10, 80, 30, "child")
    popup.add_child(child)

    d.show_popup(popup)
    d.set_focus(child)
    assert d.focused_node is child

    d.dismiss_popup()
    assert d.focused_node is None, "Focus should be cleared when popup dismissed"
    assert d.active_popup is None
    print("  PASS test_popup_dismiss_clears_focused_child")


def test_popup_release_clears_focused_child():
    """release_popup also clears focused_node inside the popup."""
    d = ZEventDispatcher()
    popup = ZNode()
    popup.set_bounds(100, 100, 200, 200)
    child = HitNode(10, 10, 80, 30, "child")
    popup.add_child(child)

    d.show_popup(popup)
    d.set_focus(child)

    d.release_popup(popup)
    assert d.focused_node is None, "Focus should be cleared on release_popup"
    print("  PASS test_popup_release_clears_focused_child")


def test_no_background_hover_while_popup_active():
    """When a popup is active, moving the cursor outside the popup
    should not set hovered_node to a background scene node."""
    d = ZEventDispatcher()
    bg = HitNode(0, 0, 500, 500, "background")
    d.add(bg)

    popup = HitNode(200, 200, 80, 80, "popup")
    d.show_popup(popup)

    # Move cursor over background (outside popup)
    d.mouse_moved(ptr(50, 50))
    assert d.hovered_node is None, f"hovered_node should be None when cursor outside popup, got {d.hovered_node}"

    # Move cursor over popup
    d.mouse_moved(ptr(230, 230))
    assert d.hovered_node is popup, "hovered_node should be the popup when cursor inside"
    print("  PASS test_no_background_hover_while_popup_active")


def test_dismiss_popup_root_focused_no_double_blur():
    """If the popup root itself is focused, dismiss_popup should call
    on_blur exactly once, not twice."""
    d = ZEventDispatcher()

    class BlurCounter(ZNode):
        def __init__(self):
            super().__init__()
            self.set_bounds(100, 100, 80, 80)
            self.blur_count = 0
        def on_blur(self):
            self.blur_count += 1

    popup = BlurCounter()
    d.show_popup(popup)
    d.set_focus(popup)  # focus on the popup root itself
    assert d.focused_node is popup

    d.dismiss_popup()
    assert popup.blur_count == 1, f"on_blur should run exactly once, got {popup.blur_count}"
    assert d.focused_node is None
    assert d.active_popup is None
    print("  PASS test_dismiss_popup_root_focused_no_double_blur")


# ── Run all ───────────────────────────────────────────────────────

if __name__ == "__main__":
    print("Running dispatcher/popup/input tests...")
    print()
    print("Picking and bubbling:")
    test_pick_deepest()
    test_bubble_pressed()
    test_mouse_moved_routes_to_hovered()

    print()
    print("Wheel propagation:")
    test_wheel_consumed()
    test_wheel_bubbles_when_not_consumed()
    test_wheel_stops_when_consumed()

    print()
    print("Focus transitions:")
    test_focus_blur_cycle()
    test_press_clears_focus_on_miss()

    print()
    print("Popup management:")
    test_popup_outside_click_dismisses()
    test_popup_inside_click_handled()
    test_popup_receives_key_events()
    test_popup_receives_move_events()
    test_popup_receives_wheel()
    test_dropdown_popup_lifecycle()
    test_context_menu_popup_lifecycle()

    print()
    print("Scroll hit-testing:")
    test_scroll_hit_offset()
    test_scroll_wheel_consumed()
    test_scroll_pick_through_dispatcher()

    print()
    print("Hover state:")
    test_clear_hover()

    print()
    print("Popup correctness:")
    test_dropdown_escape_clears_popup()
    test_popup_not_drawn_twice()
    test_popup_move_not_double_delivered()
    test_composite_popup_move_to_child()
    test_popup_focus_key_routing()

    print()
    print("Popup lifecycle:")
    test_popup_dismiss_clears_focused_child()
    test_popup_release_clears_focused_child()
    test_no_background_hover_while_popup_active()
    test_dismiss_popup_root_focused_no_double_blur()

    print()
    print(f"All tests passed!")
