"""Demo: building a panel with ZVBox/ZHBox vs manual coordinates.

This shows how the same mind-map sidebar would look using the layout
system.  Run with: python demo_layout.py
"""
from __future__ import annotations

import sys

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QApplication

from zui_qt import ZCanvas, ZTheme, Zui
from zui_qt.layout import ZHBox, ZSpacer, ZVBox

PANEL_W = 214
PALETTE = [
    "#7aa2ff", "#75c77e", "#ffba59", "#f0847d",
    "#8c76ff", "#ff8fd1", "#58c8d6", "#7b8594",
    "#4c9aff", "#4caf6e", "#e6a23c", "#d66a61",
]


def build_old_style(z: Zui) -> None:
    """Original approach: every widget has hand-computed x, y."""
    actions = z.window(8, 12, PANEL_W - 16, 278, "Actions (manual)")
    actions.add(z.label(8, 6, 180, 18, "Selected: Central Topic"))
    actions.add(z.button(8, 30, 180, 24, "Add Child (Tab)", None))
    actions.add(z.button(8, 58, 180, 24, "Add Sibling (Shift+Enter)", None))
    actions.add(z.button(8, 86, 180, 24, "Rename (F2)", None))
    actions.add(z.button(8, 114, 180, 24, "Edit Note (N)", None))
    actions.add(z.button(8, 142, 86, 24, "Collapse", None))
    actions.add(z.button(102, 142, 86, 24, "Delete", None))
    actions.add(z.button(8, 176, 86, 24, "Undo", None))
    actions.add(z.button(102, 176, 86, 24, "Redo", None))
    actions.add(z.button(8, 210, 86, 24, "Layout", None))
    actions.add(z.button(102, 210, 86, 24, "Fit", None))
    actions.add(z.label(8, 244, 180, 20, "Shift-drag to reparent"))
    z.add(actions)


def build_new_style(z: Zui) -> None:
    """Layout approach: just add children, let VBox/HBox handle positioning."""

    # Actions panel
    actions = z.window(PANEL_W + 8, 12, PANEL_W - 16, 0, "Actions (layout)")
    panel = z.vbox(0, 0, PANEL_W - 32, spacing=6, padding=8)
    panel.add(z.label(0, 0, 0, 18, "Selected: Central Topic"))
    panel.add(z.button(0, 0, 0, 24, "Add Child (Tab)", None))
    panel.add(z.button(0, 0, 0, 24, "Add Sibling (Shift+Enter)", None))
    panel.add(z.button(0, 0, 0, 24, "Rename (F2)", None))
    panel.add(z.button(0, 0, 0, 24, "Edit Note (N)", None))

    # Two-column rows — just use HBox
    row1 = z.hbox(0, 0, 0, 24, spacing=6)
    row1.add(z.button(0, 0, 0, 24, "Collapse", None), stretch=1)
    row1.add(z.button(0, 0, 0, 24, "Delete", None), stretch=1)
    panel.add(row1)

    row2 = z.hbox(0, 0, 0, 24, spacing=6)
    row2.add(z.button(0, 0, 0, 24, "Undo", None), stretch=1)
    row2.add(z.button(0, 0, 0, 24, "Redo", None), stretch=1)
    panel.add(row2)

    row3 = z.hbox(0, 0, 0, 24, spacing=6)
    row3.add(z.button(0, 0, 0, 24, "Layout", None), stretch=1)
    row3.add(z.button(0, 0, 0, 24, "Fit", None), stretch=1)
    panel.add(row3)

    panel.add(z.label(0, 0, 0, 20, "Shift-drag to reparent"))
    panel.do_layout()

    # Auto-size the window height to fit
    actions.content.set_size(panel.w, panel.h)
    actions.h = panel.h + actions.DEFAULT_TITLE_HEIGHT
    actions.add(panel)
    z.add(actions)

    # Style panel
    style_win = z.window(PANEL_W + 8, actions.y + actions.h + 12, PANEL_W - 16, 0, "Style (layout)")
    style_panel = z.vbox(0, 0, PANEL_W - 32, spacing=6, padding=8)
    style_panel.add(z.label(0, 0, 0, 18, "Apply color to selected topic"))
    style_panel.add(z.palette_grid(0, 0, 0, 84, [QColor(c) for c in PALETTE], 4, None))

    branch_row = z.hbox(0, 0, 0, 24, spacing=6)
    branch_row.add(z.button(0, 0, 0, 24, "Left Branch", None), stretch=1)
    branch_row.add(z.button(0, 0, 0, 24, "Right Branch", None), stretch=1)
    style_panel.add(branch_row)

    style_panel.do_layout()
    style_win.content.set_size(style_panel.w, style_panel.h)
    style_win.h = style_panel.h + style_win.DEFAULT_TITLE_HEIGHT
    style_win.add(style_panel)
    z.add(style_win)

    # Document panel
    doc_y = style_win.y + style_win.h + 12
    doc_win = z.window(PANEL_W + 8, doc_y, PANEL_W - 16, 0, "Document (layout)")
    doc_panel = z.vbox(0, 0, PANEL_W - 32, spacing=6, padding=8)
    doc_panel.add(z.button(0, 0, 0, 24, "New", None))
    doc_panel.add(z.button(0, 0, 0, 24, "Open JSON", None))
    doc_panel.add(z.button(0, 0, 0, 24, "Save JSON", None))
    doc_panel.add(z.button(0, 0, 0, 24, "Export PNG", None))
    doc_panel.add(z.label(0, 0, 0, 18, "Nodes: 11 | Depth: 3"))
    doc_panel.add(z.label(0, 0, 0, 18, "Untitled mind map"))
    doc_panel.do_layout()
    doc_win.content.set_size(doc_panel.w, doc_panel.h)
    doc_win.h = doc_panel.h + doc_win.DEFAULT_TITLE_HEIGHT
    doc_win.add(doc_panel)
    z.add(doc_win)


def main() -> int:
    app = QApplication(sys.argv)
    zui = Zui(ZTheme.light())
    build_old_style(zui)
    build_new_style(zui)

    canvas = ZCanvas(zui)
    canvas.setWindowTitle("Layout Demo — Left: manual | Right: ZVBox/ZHBox")
    canvas.resize(460, 720)
    canvas.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
