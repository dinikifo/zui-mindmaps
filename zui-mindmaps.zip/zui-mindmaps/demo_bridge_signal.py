"""ZUI ↔ external process demo — live signal plotter.

The ZUI app provides the interface: a zoomable canvas with a waveform
display, control panels for frequency/amplitude/waveform, and live stats.
The actual signal computation runs in a separate Python process
(worker_signal_gen.py) that communicates via the ZBridge JSON-line protocol.

Run:
    python demo_bridge_signal.py
"""

from __future__ import annotations

import sys
from collections import deque
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QApplication, QMainWindow

from zui_qt import ZCamera, ZCanvas, ZEventHandler, ZKey, ZPointer, ZTheme, Zui
from zui_qt.bridge import ZBridge
from zui_qt.layout import ZHBox, ZVBox


PANEL_W = 210
MAX_POINTS = 600  # ~10 seconds at 60 Hz


class WaveformState:
    """Holds the time-series data received from the worker."""

    def __init__(self) -> None:
        self.points: deque[tuple[float, float]] = deque(maxlen=MAX_POINTS)
        self.running = False
        self.freq = 2.0
        self.amplitude = 1.0
        self.waveform = "sine"
        self.stats_min = 0.0
        self.stats_max = 0.0
        self.stats_rms = 0.0
        self.total_samples = 0

    def push(self, t: float, y: float) -> None:
        self.points.append((t, y))

    def clear(self) -> None:
        self.points.clear()
        self.total_samples = 0


class SignalPlotterWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("ZUI Bridge Demo — Signal Plotter")
        self.resize(1100, 640)

        self.zui = Zui(ZTheme.light())
        self.canvas = ZCanvas(self.zui, self)
        self.setCentralWidget(self.canvas)

        self.state = WaveformState()

        # Camera for the waveform area
        self.camera = ZCamera(PANEL_W + 12, 12, 800, 580)
        self.camera.set_zoom_limits(0.2, 8.0)
        self.zui.context.camera = self.camera

        # Event handler for pan/zoom
        self.handler = CanvasHandler(self)
        self.zui.set_canvas_handler(self.handler)

        # Build the UI panels using the layout system
        self._build_panels()

        # Set up the bridge
        self.bridge = ZBridge(self.zui)
        self._bind_bridge()

        # Renderer
        self.canvas.set_world_renderer(self.draw_waveform)
        self.canvas.set_continuous(True)  # live data feed

        # Launch the worker subprocess
        worker_path = str(Path(__file__).parent / "worker_signal_gen.py")
        self.bridge.connect_process([sys.executable, worker_path])

        self.statusBar().showMessage("Connecting to worker…")

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self.camera.set_viewport(
            PANEL_W + 12, 12,
            self.width() - PANEL_W - 36,
            self.height() - 56,
        )

    # ── UI construction ───────────────────────────────────────────

    def _build_panels(self) -> None:
        z = self.zui

        # Controls panel
        ctrl_win = z.window(8, 12, PANEL_W - 16, 0, "Signal Controls")
        panel = z.vbox(0, 0, PANEL_W - 32, spacing=6, padding=8)

        panel.add(z.label(0, 0, 0, 16, lambda: f"Waveform: {self.state.waveform}"))

        # Waveform selector row
        wave_row = z.hbox(0, 0, 0, 26, spacing=4)
        self.btn_sine = z.button(0, 0, 0, 26, "Sine", lambda: self._set_waveform("sine"))
        self.btn_square = z.button(0, 0, 0, 26, "Square", lambda: self._set_waveform("square"))
        wave_row.add(self.btn_sine, stretch=1)
        wave_row.add(self.btn_square, stretch=1)
        panel.add(wave_row)

        wave_row2 = z.hbox(0, 0, 0, 26, spacing=4)
        self.btn_tri = z.button(0, 0, 0, 26, "Triangle", lambda: self._set_waveform("triangle"))
        self.btn_saw = z.button(0, 0, 0, 26, "Saw", lambda: self._set_waveform("sawtooth"))
        wave_row2.add(self.btn_tri, stretch=1)
        wave_row2.add(self.btn_saw, stretch=1)
        panel.add(wave_row2)

        # Frequency control
        panel.add(z.label(0, 0, 0, 16, lambda: f"Frequency: {self.state.freq:.1f} Hz"))
        self.freq_stepper = z.stepper(0, 0, 0, 28, 2.0, 0.1, 20.0, 0.5, self._on_freq_changed)
        panel.add(self.freq_stepper)

        # Amplitude control
        panel.add(z.label(0, 0, 0, 16, lambda: f"Amplitude: {self.state.amplitude:.1f}"))
        self.amp_stepper = z.stepper(0, 0, 0, 28, 1.0, 0.1, 5.0, 0.1, self._on_amp_changed)
        panel.add(self.amp_stepper)

        # Start / Stop
        action_row = z.hbox(0, 0, 0, 30, spacing=6)
        self.btn_start = z.button(0, 0, 0, 30, "▶ Start", self._start)
        self.btn_stop = z.button(0, 0, 0, 30, "■ Stop", self._stop)
        action_row.add(self.btn_start, stretch=1)
        action_row.add(self.btn_stop, stretch=1)
        panel.add(action_row)

        panel.add(z.button(0, 0, 0, 26, "Clear Plot", self._clear))

        panel.do_layout()
        ctrl_win.content.set_size(panel.w, panel.h)
        ctrl_win.h = panel.h + ctrl_win.DEFAULT_TITLE_HEIGHT
        ctrl_win.add(panel)
        z.add(ctrl_win)

        # Stats panel
        stats_y = ctrl_win.y + ctrl_win.h + 12
        stats_win = z.window(8, stats_y, PANEL_W - 16, 0, "Live Stats")
        sp = z.vbox(0, 0, PANEL_W - 32, spacing=4, padding=8)
        sp.add(z.label(0, 0, 0, 16, lambda: f"Status: {'Running' if self.state.running else 'Stopped'}"))
        sp.add(z.label(0, 0, 0, 16, lambda: f"Samples: {self.state.total_samples}"))
        sp.add(z.label(0, 0, 0, 16, lambda: f"Min: {self.state.stats_min:.4f}"))
        sp.add(z.label(0, 0, 0, 16, lambda: f"Max: {self.state.stats_max:.4f}"))
        sp.add(z.label(0, 0, 0, 16, lambda: f"RMS: {self.state.stats_rms:.4f}"))
        sp.add(z.label(0, 0, 0, 16, lambda: f"Points in view: {len(self.state.points)}"))
        sp.do_layout()
        stats_win.content.set_size(sp.w, sp.h)
        stats_win.h = sp.h + stats_win.DEFAULT_TITLE_HEIGHT
        stats_win.add(sp)
        z.add(stats_win)

        # IPC debug panel
        debug_y = stats_win.y + stats_win.h + 12
        debug_win = z.window(8, debug_y, PANEL_W - 16, 0, "IPC Debug")
        dp = z.vbox(0, 0, PANEL_W - 32, spacing=4, padding=8)
        self._last_inbound = "—"
        self._last_outbound = "—"
        self._msg_count_in = 0
        self._msg_count_out = 0
        dp.add(z.label(0, 0, 0, 16, lambda: f"Connected: {self.bridge.is_connected}"))
        dp.add(z.label(0, 0, 0, 16, lambda: f"Messages in: {self._msg_count_in}"))
        dp.add(z.label(0, 0, 0, 16, lambda: f"Messages out: {self._msg_count_out}"))
        dp.add(z.label(0, 0, 0, 14, lambda: f"Last in: {self._last_inbound[:30]}"))
        dp.add(z.label(0, 0, 0, 14, lambda: f"Last out: {self._last_outbound[:30]}"))
        dp.do_layout()
        debug_win.content.set_size(dp.w, dp.h)
        debug_win.h = dp.h + debug_win.DEFAULT_TITLE_HEIGHT
        debug_win.add(dp)
        z.add(debug_win)

    # ── Bridge wiring ─────────────────────────────────────────────

    def _bind_bridge(self) -> None:
        bridge = self.bridge

        @bridge.on("worker.ready")
        def on_worker_ready(payload: dict) -> None:
            pid = payload.get("pid", "?")
            self.statusBar().showMessage(f"Worker ready (PID {pid})")
            # Send initial config
            bridge.emit("signal.configure", {
                "freq": self.state.freq,
                "amplitude": self.state.amplitude,
                "waveform": self.state.waveform,
            })

        @bridge.on("signal.data")
        def on_data(payload: dict) -> None:
            self.state.push(payload["t"], payload["y"])
            self.state.total_samples = payload.get("sample", self.state.total_samples)

        @bridge.on("signal.stats")
        def on_stats(payload: dict) -> None:
            self.state.stats_min = payload.get("min", 0.0)
            self.state.stats_max = payload.get("max", 0.0)
            self.state.stats_rms = payload.get("rms", 0.0)
            self.state.total_samples = payload.get("samples", self.state.total_samples)

        @bridge.on("signal.started")
        def on_started(payload: dict) -> None:
            self.state.running = True
            self.statusBar().showMessage("Signal generation started")

        @bridge.on("signal.stopped")
        def on_stopped(payload: dict) -> None:
            self.state.running = False
            self.statusBar().showMessage("Signal generation stopped")

        @bridge.on("signal.configured")
        def on_configured(payload: dict) -> None:
            self.state.freq = payload.get("freq", self.state.freq)
            self.state.amplitude = payload.get("amplitude", self.state.amplitude)
            self.state.waveform = payload.get("waveform", self.state.waveform)

        # Debug tracking
        bridge.inbound.connect(self._track_inbound)
        bridge.outbound.connect(self._track_outbound)

    def _track_inbound(self, topic: str, payload: dict) -> None:
        self._msg_count_in += 1
        self._last_inbound = topic

    def _track_outbound(self, topic: str, payload: dict) -> None:
        self._msg_count_out += 1
        self._last_outbound = topic

    # ── Actions → bridge messages ─────────────────────────────────

    def _set_waveform(self, waveform: str) -> None:
        self.state.waveform = waveform
        self.bridge.emit("signal.configure", {
            "freq": self.state.freq,
            "amplitude": self.state.amplitude,
            "waveform": waveform,
        })

    def _on_freq_changed(self, value: float) -> None:
        self.state.freq = value
        self.bridge.emit("signal.configure", {
            "freq": value,
            "amplitude": self.state.amplitude,
            "waveform": self.state.waveform,
        })

    def _on_amp_changed(self, value: float) -> None:
        self.state.amplitude = value
        self.bridge.emit("signal.configure", {
            "freq": self.state.freq,
            "amplitude": value,
            "waveform": self.state.waveform,
        })

    def _start(self) -> None:
        self.bridge.emit("signal.start")

    def _stop(self) -> None:
        self.bridge.emit("signal.stop")

    def _clear(self) -> None:
        self.state.clear()

    # ── Waveform rendering ────────────────────────────────────────

    def draw_waveform(self, painter: QPainter, canvas: ZCanvas) -> None:
        cam = self.camera
        vp = cam.viewport_rect()

        painter.save()
        painter.setClipRect(vp)

        # Background
        painter.fillRect(vp, QColor(248, 249, 252))

        # Grid
        cam.apply_to_painter(painter)
        self._draw_grid(painter, cam)
        self._draw_axes(painter, cam)
        self._draw_signal(painter, cam)
        cam.restore_painter(painter)

        # Overlay label
        painter.setPen(QColor(100, 100, 100))
        font = painter.font()
        font.setPointSizeF(10)
        painter.setFont(font)
        painter.drawText(
            int(vp.right() - 200), int(vp.top() + 16),
            f"Zoom: {cam.zoom * 100:.0f}%  |  {self.state.waveform}"
        )

        painter.restore()

    def _draw_grid(self, painter: QPainter, cam: ZCamera) -> None:
        painter.setPen(QPen(QColor(220, 224, 230), 0.5 / cam.zoom))
        # Vertical lines every 1 second
        for t in range(-5, 60):
            x = t * 60.0  # 60px per second in world space
            painter.drawLine(QPointF(x, -300), QPointF(x, 300))
        # Horizontal lines every 0.5 amplitude
        for i in range(-20, 21):
            y = i * 30.0  # 60px per unit in world space
            painter.drawLine(QPointF(-300, y), QPointF(3600, y))

    def _draw_axes(self, painter: QPainter, cam: ZCamera) -> None:
        painter.setPen(QPen(QColor(80, 80, 80), 1.5 / cam.zoom))
        # X axis (y=0)
        painter.drawLine(QPointF(-300, 0), QPointF(3600, 0))
        # Y axis (t=0)
        painter.drawLine(QPointF(0, -300), QPointF(0, 300))

        # Axis labels
        painter.setPen(QColor(100, 100, 100))
        font = painter.font()
        font.setPointSizeF(max(6.0, 9.0 / cam.zoom))
        painter.setFont(font)
        for t in range(0, 50, 2):
            x = t * 60.0
            painter.drawText(QPointF(x - 4, 16 / cam.zoom), f"{t}s")
        for i in range(-4, 5):
            if i == 0:
                continue
            y = -i * 60.0
            painter.drawText(QPointF(-30 / cam.zoom, y + 4 / cam.zoom), f"{i:.0f}")

    def _draw_signal(self, painter: QPainter, cam: ZCamera) -> None:
        points = self.state.points
        if len(points) < 2:
            return

        # Build the path in world coordinates
        # x = t * 60  (60 world-px per second)
        # y = -value * 60  (60 world-px per unit, inverted for screen)
        path = QPainterPath()
        pts = list(points)
        path.moveTo(pts[0][0] * 60.0, -pts[0][1] * 60.0)
        for t, y in pts[1:]:
            path.lineTo(t * 60.0, -y * 60.0)

        # Signal stroke
        pen = QPen(QColor("#4c9aff"), 2.0 / cam.zoom)
        pen.setCosmetic(False)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPath(path)

        # Filled area under curve
        fill_path = QPainterPath(path)
        fill_path.lineTo(pts[-1][0] * 60.0, 0.0)
        fill_path.lineTo(pts[0][0] * 60.0, 0.0)
        fill_path.closeSubpath()
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(76, 154, 255, 30))
        painter.drawPath(fill_path)

        # Current point marker
        last_t, last_y = pts[-1]
        marker_x = last_t * 60.0
        marker_y = -last_y * 60.0
        r = 4.0 / cam.zoom
        painter.setPen(QPen(QColor("#185FA5"), 1.5 / cam.zoom))
        painter.setBrush(QColor("#4c9aff"))
        painter.drawEllipse(QPointF(marker_x, marker_y), r, r)

    def closeEvent(self, event) -> None:
        self.bridge.emit("signal.stop")
        self.bridge.disconnect()
        super().closeEvent(event)


class CanvasHandler(ZEventHandler):
    def __init__(self, window: SignalPlotterWindow) -> None:
        self.window = window

    def mouse_pressed(self, event: ZPointer) -> None:
        cam = self.window.camera
        if cam.over_viewport(event.x, event.y) and (
            event.is_middle()
            or bool(event.modifiers & Qt.KeyboardModifier.ControlModifier)
        ):
            cam.begin_pan(event.x, event.y)

    def mouse_dragged(self, event: ZPointer) -> None:
        cam = self.window.camera
        if cam.panning:
            cam.update_pan(event.x, event.y)

    def mouse_released(self, event: ZPointer) -> None:
        self.window.camera.end_pan()

    def mouse_wheel(self, delta: float, event: ZPointer | None = None) -> None:
        if event is not None:
            self.window.camera.on_mouse_wheel(delta, event.x, event.y)

    def key_pressed(self, event: ZKey) -> None:
        if event.key == Qt.Key.Key_Space:
            if self.window.state.running:
                self.window._stop()
            else:
                self.window._start()
        elif event.key == Qt.Key.Key_0:
            self.window.camera.fit_world(600, 300, 40)


def main() -> int:
    app = QApplication(sys.argv)
    window = SignalPlotterWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
