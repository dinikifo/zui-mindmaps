"""External worker process — signal generator.

This runs as a standalone subprocess.  It reads JSON-line commands
from stdin and writes data back to stdout.

Protocol:
    → {"topic": "signal.configure", "payload": {"freq": 2.0, "amplitude": 1.0, "waveform": "sine"}}
    → {"topic": "signal.start", "payload": {}}
    → {"topic": "signal.stop", "payload": {}}
    ← {"topic": "signal.data", "payload": {"t": 0.016, "y": 0.42, "sample": 1}}
    ← {"topic": "signal.stats", "payload": {"min": -1.0, "max": 1.0, "rms": 0.707}}
"""

from __future__ import annotations

import json
import math
import select
import sys
import time
from threading import Event, Thread


class SignalGenerator:
    def __init__(self) -> None:
        self.freq = 2.0
        self.amplitude = 1.0
        self.waveform = "sine"  # sine, square, triangle, sawtooth
        self.running = False
        self.sample_rate = 60  # samples per second
        self._stop_event = Event()
        self._thread: Thread | None = None
        self._sample = 0
        self._t0 = 0.0
        self._y_min = 0.0
        self._y_max = 0.0
        self._y_sum_sq = 0.0

    def configure(self, freq: float = 2.0, amplitude: float = 1.0, waveform: str = "sine") -> None:
        self.freq = max(0.1, min(freq, 20.0))
        self.amplitude = max(0.0, min(amplitude, 5.0))
        self.waveform = waveform if waveform in ("sine", "square", "triangle", "sawtooth") else "sine"
        self._reset_stats()

    def _reset_stats(self) -> None:
        self._y_min = float("inf")
        self._y_max = float("-inf")
        self._y_sum_sq = 0.0
        self._sample = 0

    def _compute(self, t: float) -> float:
        phase = (t * self.freq) % 1.0
        if self.waveform == "sine":
            return self.amplitude * math.sin(2.0 * math.pi * phase)
        elif self.waveform == "square":
            return self.amplitude * (1.0 if phase < 0.5 else -1.0)
        elif self.waveform == "triangle":
            return self.amplitude * (4.0 * abs(phase - 0.5) - 1.0)
        elif self.waveform == "sawtooth":
            return self.amplitude * (2.0 * phase - 1.0)
        return 0.0

    def start(self) -> None:
        if self.running:
            return
        self.running = True
        self._stop_event.clear()
        self._t0 = time.monotonic()
        self._reset_stats()
        self._thread = Thread(target=self._generate_loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self.running = False
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None

    def _generate_loop(self) -> None:
        interval = 1.0 / self.sample_rate
        while not self._stop_event.is_set():
            t = time.monotonic() - self._t0
            y = self._compute(t)
            self._sample += 1
            self._y_min = min(self._y_min, y)
            self._y_max = max(self._y_max, y)
            self._y_sum_sq += y * y

            send_msg({
                "topic": "signal.data",
                "payload": {
                    "t": round(t, 4),
                    "y": round(y, 6),
                    "sample": self._sample,
                },
            })

            # Emit stats every 30 samples
            if self._sample % 30 == 0:
                rms = math.sqrt(self._y_sum_sq / self._sample) if self._sample > 0 else 0.0
                send_msg({
                    "topic": "signal.stats",
                    "payload": {
                        "min": round(self._y_min, 4),
                        "max": round(self._y_max, 4),
                        "rms": round(rms, 4),
                        "samples": self._sample,
                    },
                })

            self._stop_event.wait(interval)


def send_msg(msg: dict) -> None:
    try:
        sys.stdout.write(json.dumps(msg, separators=(",", ":")) + "\n")
        sys.stdout.flush()
    except BrokenPipeError:
        sys.exit(0)


def main() -> None:
    gen = SignalGenerator()

    # Announce we're alive
    send_msg({"topic": "worker.ready", "payload": {"pid": __import__("os").getpid()}})

    while True:
        try:
            if select.select([sys.stdin], [], [], 0.05)[0]:
                line = sys.stdin.readline()
                if not line:
                    break
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    continue

                topic = msg.get("topic", "")
                payload = msg.get("payload", {})

                if topic == "signal.configure":
                    gen.configure(
                        freq=payload.get("freq", gen.freq),
                        amplitude=payload.get("amplitude", gen.amplitude),
                        waveform=payload.get("waveform", gen.waveform),
                    )
                    send_msg({"topic": "signal.configured", "payload": {
                        "freq": gen.freq,
                        "amplitude": gen.amplitude,
                        "waveform": gen.waveform,
                    }})

                elif topic == "signal.start":
                    gen.start()
                    send_msg({"topic": "signal.started", "payload": {}})

                elif topic == "signal.stop":
                    gen.stop()
                    send_msg({"topic": "signal.stopped", "payload": {}})

                elif topic == "signal.ping":
                    send_msg({"topic": "signal.pong", "payload": {"running": gen.running}})

        except KeyboardInterrupt:
            break

    gen.stop()


if __name__ == "__main__":
    main()
